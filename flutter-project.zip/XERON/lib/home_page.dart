import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';
import 'srv.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;
  FixedExtentScrollController? _wheelController;

  String _selectedBugMode = "number";
  String _senderMode = "private";
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _isSending = false;

  // --- TEMA PUTIH + OCEAN PURPLE ---
  static const Color bgMain = Color(0xFF0A0A0F);
  static const Color bgSurface = Color(0xFF14141A);
  static const Color bgCard = Color(0xFF1A1A22);
  static const Color textMain = const Color(0xFFEDE7F6);
  static const Color textSub = const Color(0xFFB0A8C0);
  static const Color accentColor = Color(0xFFE53935); // ocean blue
  static const Color borderLight = Color(0xFFFF8A80);
  static const Color neonRed = Color(0xFFFF1744); // merah neon (pengganti hijau)

  @override
  void initState() {
    super.initState();

    _initBannerVideo();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
        _wheelController = FixedExtentScrollController(initialItem: 0);
      }
    }

    _fetchSenderStats();
  }

  Future<void> _initBannerVideo() async {
    try {
      final ctrl = VideoPlayerController.asset('assets/videos/bug.mp4');
      await ctrl.initialize();
      if (!mounted) {
        await ctrl.dispose();
        return;
      }
      await ctrl.setLooping(true);
      await ctrl.setVolume(1.0);
      await ctrl.seekTo(Duration.zero);
      await ctrl.play();
      setState(() => _videoController = ctrl);
    } catch (e) {
      debugPrint('home banner video: $e');
    }
  }

  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug
          .where((b) => b['bug_id'].contains('_group'))
          .toList();
    } else {
      return widget.listBug
          .where((b) => !b['bug_id'].contains('_group'))
          .toList();
    }
  }

  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "${Srv.baseUrl}/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    try { _videoController?.pause(); } catch (_) {}
    _videoController?.dispose();
    _videoController = null;
    _pulseController.dispose();
    _wheelController?.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number",
            "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link",
            "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() => _isSending = true);

    // Moderator tidak punya akses global — selalu private
    final effectiveSenderMode = (widget.role == 'moderator')
        ? 'private'
        : ((widget.role == 'developer' ||
                widget.role == 'owner' ||
                widget.role == 'vip')
            ? _senderMode
            : 'private');

    try {
      final res = await http.get(Uri.parse(
          "${Srv.baseUrl}/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert(
            "⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert(
            "❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert(
            "⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert(
          "❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    final isSuccess = title.contains("✅") ||
        title.toLowerCase().contains('berhasil') ||
        msg.toLowerCase().contains('sukses') ||
        msg.toLowerCase().contains('berhasil');

    if (isSuccess) {
      showDialog(
        context: context,
        barrierDismissible: true,
        builder: (ctx) {
          return Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.symmetric(horizontal: 28),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(22, 28, 22, 22),
              decoration: BoxDecoration(
                color: const Color(0xFF1A2433),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: neonRed.withOpacity(0.55),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: neonRed.withOpacity(0.18),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: neonRed,
                      boxShadow: [
                        BoxShadow(
                          color: neonRed.withOpacity(0.45),
                          blurRadius: 18,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.check_rounded,
                      color: Color(0xFF2196F3), // centang biru
                      size: 42,
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Success',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    msg.replaceAll('✅', '').trim().isEmpty
                        ? 'Bug berhasil dikirim ke target!'
                        : msg.replaceAll('✅', '').trim(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.75),
                      fontSize: 13.5,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: Text(
                        'OK',
                        style: TextStyle(
                          color: neonRed.withOpacity(0.95),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
      return;
    }

    CustomPopup.show(
      context,
      title: title,
      message: msg,
      icon: Icons.error_outline,
      iconColor: Colors.redAccent,
      confirmText: "Close",
    );
  }

  Widget _buildAccountOverlay() {
    // Hanya video — tanpa teks/info di atas video
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return Container(color: const Color(0xFF0A0A0F));
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: FittedBox(
        fit: BoxFit.cover,
        clipBehavior: Clip.hardEdge,
        child: SizedBox(
          width: _videoController!.value.size.width,
          height: _videoController!.value.size.height,
          child: VideoPlayer(_videoController!),
        ),
      ),
    );
  }

  /// Widget info di atas video — gaya Mauldev / Justin Official
  Widget _buildUserInfoBar() {
    final roleLower = widget.role.toLowerCase();
    final isDev = roleLower == 'developer' || roleLower == 'owner';
    // Developer/owner: centang biru; role lain: oranye/merah
    final badgeColor = isDev ? const Color(0xFF1E88E5) : const Color(0xFFE53935);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C24).withOpacity(0.95),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          // Avatar + badge centang
          SizedBox(
            width: 48,
            height: 48,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFE65100).withOpacity(0.25),
                    border: Border.all(
                      color: const Color(0xFFFF6D00).withOpacity(0.7),
                      width: 1.5,
                    ),
                  ),
                  child: const Icon(
                    Icons.person_rounded,
                    color: Color(0xFFFF8A65),
                    size: 26,
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: badgeColor,
                      border: Border.all(color: const Color(0xFF1C1C24), width: 1.5),
                    ),
                    child: const Icon(Icons.check, color: Colors.white, size: 10),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: badgeColor.withOpacity(0.95),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
              ],
            ),
          ),
          // EXP di kanan
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'EXP',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.4),
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                widget.expiredDate.isEmpty ? '-' : widget.expiredDate,
                style: const TextStyle(
                  color: Color(0xFFFF6D00),
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _cleanBugName(String bugName) {
    return bugName
        .replaceAll(RegExp(r'^bug_|_group$'), '')
        .replaceAll('_', ' ')
        .toUpperCase();
  }

  Widget _buildSelectionButton({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return _PressableScale(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: bgCard.withOpacity(0.95),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.black, width: 1.2),
          boxShadow: [
            const BoxShadow(
                color: Colors.black, blurRadius: 0, offset: Offset(2, 2)),
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                    color: accentColor.withOpacity(0.3), width: 0.8),
              ),
              child: Icon(icon, color: accentColor, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: textSub,
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.8,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: accentColor, size: 20),
          ],
        ),
      ),
    );
  }

  void _showTargetTypePopup() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("PILIH MODE TARGET"),
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildPopupOption(
              label: "BUG NOMOR",
              isSelected: _selectedBugMode == "number",
              onTap: () {
                setState(() {
                  _selectedBugMode = "number";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) {
                    selectedBugId = newBugs[0]['bug_id'];
                  }
                });
                Navigator.pop(ctx);
                _wheelController?.animateToItem(
                  0,
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutCubic,
                );
              },
            ),
            const SizedBox(height: 10),
            _buildPopupOption(
              label: "BUG GROUP",
              isSelected: _selectedBugMode == "group",
              onTap: () {
                setState(() {
                  _selectedBugMode = "group";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) {
                    selectedBugId = newBugs[0]['bug_id'];
                  }
                });
                Navigator.pop(ctx);
                _wheelController?.animateToItem(
                  0,
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutCubic,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPopupOption({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? accentColor.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? accentColor : Colors.black.withOpacity(0.2),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? accentColor : textMain,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                fontSize: 13,
              ),
            ),
            const Spacer(),
            if (isSelected)
              Icon(Icons.check_circle, color: accentColor, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildModernWheelPicker(List<Map<String, dynamic>> availableBugs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            "SELECT PAYLOAD",
            style: TextStyle(
              color: textMain,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        Container(
          height: 112,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: bgCard.withOpacity(0.95),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.black, width: 1.2),
            boxShadow: [
              const BoxShadow(
                  color: Colors.black, blurRadius: 0, offset: Offset(2, 2)),
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Stack(
            children: [
              ListWheelScrollView.useDelegate(
                controller: _wheelController,
                itemExtent: 32,
                diameterRatio: 6.0,
                perspective: 0.001,
                offAxisFraction: 0,
                physics: const BouncingScrollPhysics(),
                useMagnifier: false,
                magnification: 1.0,
                onSelectedItemChanged: (index) {
                  setState(() {
                    selectedBugId = availableBugs[index]['bug_id'];
                  });
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: availableBugs.length,
                  builder: (context, index) {
                    final bug = availableBugs[index];
                    final isSelected = bug['bug_id'] == selectedBugId;

                    return Padding(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _cleanBugName(bug['bug_name'] ?? 'Unknown'),
                          textAlign: TextAlign.left,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: isSelected
                                ? neonRed
                                : textSub.withOpacity(0.45),
                            fontSize: isSelected ? 14 : 11,
                            fontWeight:
                                isSelected ? FontWeight.w800 : FontWeight.w400,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: 26,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.0),
                          Colors.black.withOpacity(0.35),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (widget.role == 'developer' ||
            widget.role == 'owner' ||
            widget.role == 'vip' ||
            widget.role == 'moderator') ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(
              "SENDER MODE",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.w900,
                fontSize: 12,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: _buildSenderModeButton(
                  label: "PRIVATE",
                  icon: Icons.person_outline,
                  count: _privateSenderCount,
                  isSelected: _senderMode == 'private',
                  onTap: () => setState(() => _senderMode = 'private'),
                ),
              ),
              if (widget.role != 'moderator') ...[
                const SizedBox(width: 12),
                Expanded(
                  child: _buildSenderModeButton(
                    label: "GLOBAL",
                    icon: Icons.public,
                    count: _globalSenderCount,
                    isSelected: _senderMode == 'global',
                    onTap: () => setState(() => _senderMode = 'global'),
                  ),
                ),
              ],
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildSenderModeButton({
    required String label,
    required IconData icon,
    required int count,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final color = label == 'GLOBAL'
        ? const Color(0xFFFF5252)
        : neonRed;
    return _PressableScale(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    color.withOpacity(0.28),
                    color.withOpacity(0.10),
                  ],
                )
              : null,
          color: isSelected ? null : bgCard.withOpacity(0.95),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? color : Colors.white.withOpacity(0.12),
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: color.withOpacity(0.35),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: isSelected
                      ? [color, color.withOpacity(0.7)]
                      : [
                          Colors.white.withOpacity(0.08),
                          Colors.white.withOpacity(0.04),
                        ],
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: color.withOpacity(0.45),
                          blurRadius: 10,
                        ),
                      ]
                    : null,
              ),
              child: Icon(icon,
                  color: isSelected ? Colors.white : textSub, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: isSelected ? color : textSub,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '$count sender aktif',
                    style: TextStyle(
                      color: isSelected
                          ? color.withOpacity(0.9)
                          : textSub.withOpacity(0.7),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Icon(Icons.check_circle, color: color, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Mode: Nomor | Group (persegi panjang side by side)
        _buildTargetModeTabs(),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            _selectedBugMode == "number"
                ? "TARGET NUMBER"
                : "WHATSAPP GROUP LINK",
            style: TextStyle(
              color: textMain,
              fontWeight: FontWeight.bold,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        TextField(
          controller: targetController,
          style: const TextStyle(color: textMain, fontSize: 15),
          cursorColor: neonRed,
          keyboardType: _selectedBugMode == "number"
              ? TextInputType.phone
              : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number"
                ? "e.g. +628xxxxxxxx"
                : "e.g. https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: textSub.withOpacity(0.5)),
            filled: true,
            fillColor: bgSurface.withOpacity(0.95),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: neonRed, width: 1.4),
            ),
            prefixIcon: Icon(
              _selectedBugMode == "number"
                  ? Icons.phone_android_rounded
                  : Icons.link,
              color: textSub,
            ),
            contentPadding:
                const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
          ),
        ),
        const SizedBox(height: 20),
        _buildPayloadList(availableBugs),
      ],
    );
  }

  Widget _buildTargetModeTabs() {
    // Gaya seperti foto: ikon di atas, teks di bawah
    return Row(
      children: [
        Expanded(
          child: _modeTab(
            label: 'Number',
            icon: Icons.person_rounded,
            selected: _selectedBugMode == 'number',
            onTap: () {
              setState(() {
                _selectedBugMode = 'number';
                targetController.clear();
                final bugs = _getFilteredBugs();
                if (bugs.isNotEmpty) selectedBugId = bugs[0]['bug_id'];
              });
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _modeTab(
            label: 'Group',
            icon: Icons.groups_rounded,
            selected: _selectedBugMode == 'group',
            onTap: () {
              setState(() {
                _selectedBugMode = 'group';
                targetController.clear();
                final bugs = _getFilteredBugs();
                if (bugs.isNotEmpty) selectedBugId = bugs[0]['bug_id'];
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _modeTab({
    required String label,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    // Justin Official: selected = abu-abu, bukan hijau
    const selectedBg = Color(0xFF2A2A34);
    const selectedFg = Color(0xFFB0B0B8);
    const unselectedBg = Color(0xFF15151C);
    const unselectedFg = Color(0xFF6E6E78);

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? selectedBg : unselectedBg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? Colors.white.withOpacity(0.14)
                : Colors.white.withOpacity(0.05),
            width: 1,
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 24,
              color: selected ? selectedFg : unselectedFg,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : unselectedFg,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                fontSize: 12.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPayloadList(List<Map<String, dynamic>> availableBugs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            "BUG TYPE / PAYLOAD",
            style: TextStyle(
              color: textMain,
              fontWeight: FontWeight.w900,
              fontSize: 12,
              fontFamily: 'Orbitron',
              letterSpacing: 1.5,
            ),
          ),
        ),
        Container(
          constraints: const BoxConstraints(maxHeight: 260),
          decoration: BoxDecoration(
            color: bgCard.withOpacity(0.6),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: availableBugs.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Text(
                      'Tidak ada payload',
                      style: TextStyle(color: textSub),
                    ),
                  ),
                )
              : ScrollConfiguration(
                  behavior: ScrollConfiguration.of(context).copyWith(
                    physics: const BouncingScrollPhysics(
                      decelerationRate: ScrollDecelerationRate.normal,
                    ),
                  ),
                  child: ListView.separated(
                    padding: const EdgeInsets.all(10),
                    shrinkWrap: true,
                    // Scroll lebih pelan / tidak "terbang"
                    physics: const BouncingScrollPhysics(),
                    itemCount: availableBugs.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final bug = availableBugs[index];
                      final id = bug['bug_id']?.toString() ?? '';
                      final name = _cleanBugName(
                          bug['bug_name']?.toString() ?? 'Unknown');
                      final selected = id == selectedBugId;
                      final isIos = id.toLowerCase().contains('ios') ||
                          name.toLowerCase().contains('ios');

                      return GestureDetector(
                        onTap: () => setState(() => selectedBugId = id),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: selected
                                ? neonRed.withOpacity(0.10)
                                : const Color(0xFF12101A),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: selected
                                  ? neonRed
                                  : Colors.white.withOpacity(0.10),
                              width: selected ? 1.6 : 1,
                            ),
                            boxShadow: selected
                                ? [
                                    BoxShadow(
                                      color: neonRed.withOpacity(0.30),
                                      blurRadius: 12,
                                      offset: const Offset(0, 3),
                                    ),
                                  ]
                                : null,
                          ),
                          child: Row(
                            children: [
                              Icon(
                                isIos
                                    ? Icons.phone_iphone_rounded
                                    : Icons.android_rounded,
                                color: selected ? neonRed : textSub,
                                size: 20,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: selected ? neonRed : textMain,
                                    fontSize: 13,
                                    fontWeight: selected
                                        ? FontWeight.w800
                                        : FontWeight.w500,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              ),
                              if (selected)
                                const Icon(Icons.check_circle,
                                    color: neonRed, size: 20)
                              else
                                Icon(Icons.circle_outlined,
                                    color: Colors.white.withOpacity(0.2),
                                    size: 18),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
        ),
        const SizedBox(height: 16),
        if (widget.role == 'developer' ||
            widget.role == 'owner' ||
            widget.role == 'vip' ||
            widget.role == 'moderator') ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(
              "SENDER MODE",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.w900,
                fontSize: 12,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
              ),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: _buildSenderModeButton(
                  label: "PRIVATE",
                  icon: Icons.lock_person_rounded,
                  count: _privateSenderCount,
                  isSelected: _senderMode == 'private',
                  onTap: () => setState(() => _senderMode = 'private'),
                ),
              ),
              if (widget.role != 'moderator') ...[
                const SizedBox(width: 12),
                Expanded(
                  child: _buildSenderModeButton(
                    label: "GLOBAL",
                    icon: Icons.public_rounded,
                    count: _globalSenderCount,
                    isSelected: _senderMode == 'global',
                    onTap: () => setState(() => _senderMode = 'global'),
                  ),
                ),
              ],
            ],
          ),
        ],
      ],
    );
  }


  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return _PressableScale(
          child: Container(
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: Colors.white24, width: 1),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08 * _pulseController.value),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isSending ? null : _sendBug,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
                shadowColor: Colors.transparent,
              ),
              child: _isSending
                  ? SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: neonRed,
                        strokeWidth: 2,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_outlined,
                            color: Color(0xFF121218), size: 18),
                        const SizedBox(width: 10),
                        Text(
                          "LAUNCH ATTACK",
                          style: TextStyle(
                            color: Color(0xFF121218),
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 1.8,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.transparent,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Info akun lonjong di atas video
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: _buildUserInfoBar(),
                ),
                const SizedBox(height: 12),
                // Video dengan lengkungan (rounded corners)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: SizedBox(
                      height: 200,
                      width: double.infinity,
                      child: _buildAccountOverlay(),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: _buildInputPanel(),
                ),
                const SizedBox(height: 24),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: _buildSendButton(),
                ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const _PressableScale({required this.child, this.onTap});

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale> {
  double _scale = 1.0;

  void _setPressed(bool pressed) {
    if (!mounted) return;
    setState(() => _scale = pressed ? 0.90 : 1.0);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedScale(
          scale: _scale,
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      ),
    );
  }
}