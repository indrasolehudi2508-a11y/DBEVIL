import 'package:flutter/material.dart';

/// Tema global XEON — Manga / Anime
/// Background hitam + garis grid putih (tetap)
/// Aksen tinta crimson / sakura, tombol panjang putih seperti login
class AppTheme {
  // Latar (hitam — jangan diganti terang)
  static const Color bgMain = Color(0xFF0A0A0F);
  static const Color bgCard = Color(0xFF14141A);
  static const Color bgSurface = Color(0xFF1A1A22);

  // Aksen manga / anime
  static const Color accent = Color(0xFFE53935); // crimson tinta
  static const Color accentMid = Color(0xFFFF5252);
  static const Color accentLight = Color(0xFFFF8A80); // sakura soft
  static const Color accentInk = Color(0xFFF5F5F7); // tinta putih
  static const Color accentGold = Color(0xFFFFD54F); // highlight shonen

  static const Color textMain = Color(0xFFF5F5F7);
  static const Color textSub = Color(0xFFB0B0B8);
  static const Color gridColor = Color(0x22FFFFFF);
  static const Color border = Color(0x33FFFFFF);
  static const Color danger = Color(0xFFEF5350);
  static const Color success = Color(0xFF69F0AE);

  /// Tombol panjang gaya login: putih, teks gelap, pill
  static ButtonStyle get mangaLongButton => ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF121218),
        disabledBackgroundColor: Colors.white54,
        disabledForegroundColor: const Color(0xFF121218),
        elevation: 0,
        shadowColor: Colors.transparent,
        minimumSize: const Size(double.infinity, 54),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
        textStyle: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w800,
          letterSpacing: 2.0,
        ),
      );

  /// Tombol sekunder manga: outline putih
  static ButtonStyle get mangaOutlineButton => OutlinedButton.styleFrom(
        foregroundColor: textMain,
        side: const BorderSide(color: Colors.white54, width: 1.2),
        minimumSize: const Size(double.infinity, 48),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
      );

  /// Chip / badge manga
  static BoxDecoration get mangaChip => BoxDecoration(
        color: accent.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accent.withOpacity(0.45)),
      );

  static ThemeData get darkTheme => ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.transparent,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          secondary: accentLight,
          surface: bgSurface,
          background: bgMain,
          onPrimary: textMain,
          onSurface: textMain,
          error: danger,
        ),
        primaryColor: accent,
        appBarTheme: const AppBarTheme(
          backgroundColor: bgMain,
          foregroundColor: textMain,
          iconTheme: IconThemeData(color: textMain),
          elevation: 0,
        ),
        iconTheme: const IconThemeData(color: textMain),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: mangaLongButton,
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(foregroundColor: accentLight),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: mangaOutlineButton,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: accent,
          foregroundColor: textMain,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: bgSurface,
          hintStyle: const TextStyle(color: textSub),
          labelStyle: const TextStyle(color: textSub),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: accent, width: 1.4),
            borderRadius: BorderRadius.circular(14),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white.withOpacity(0.12)),
            borderRadius: BorderRadius.circular(14),
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        cardColor: bgCard,
        dividerColor: Colors.white12,
        snackBarTheme: SnackBarThemeData(
          backgroundColor: bgCard,
          contentTextStyle: const TextStyle(color: textMain),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        progressIndicatorTheme: const ProgressIndicatorThemeData(
          color: accent,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: bgCard,
          selectedItemColor: accent,
          unselectedItemColor: textSub,
        ),
      );
}

/// Painter garis-garis kotak putih (grid manga panel)
class GridPainter extends CustomPainter {
  final Color color;
  final double step;

  const GridPainter({this.color = AppTheme.gridColor, this.step = 28.0});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant GridPainter old) =>
      old.color != color || old.step != step;
}

/// Widget background hitam + grid putih
class GridBackground extends StatelessWidget {
  final Widget child;
  final Color? backgroundColor;

  const GridBackground({
    super.key,
    required this.child,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: backgroundColor ?? AppTheme.bgMain,
      child: CustomPaint(
        painter: const GridPainter(),
        child: child,
      ),
    );
  }
}
