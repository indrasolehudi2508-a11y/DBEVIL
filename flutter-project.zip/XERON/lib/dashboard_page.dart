import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:video_player/video_player.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';

// Import halaman lain
import 'nik_check.dart';
import 'home_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'landing_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'device_dashboard.dart';
import 'set.dart';
import 'tap.dart';
import 'widgets/custom_popup.dart';
import 'chat_page.dart';
import 'ordernokos.dart';
import 'srv.dart';

// ── Role Pages ─────────────────────────────────────────────────────────────
import 'admin_page.dart';
import 'owner_page.dart';
import 'seller_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // Jadwal Sholat
  String _prayerCity = 'Jombang';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '-';
  String _nextPrayerTime = '--:--';
  bool _prayerLoading = false;
  Timer? _prayerTimer;
  final Set<String> _notifiedPrayers = {};

  // Cuaca (lokasi terkini)
  bool _weatherLoading = false;
  String _weatherCity = 'Lokasi...';
  String _weatherCountry = 'Indonesia';
  String _weatherDesc = '-';
  double? _weatherTemp;
  double? _weatherFeels;
  int? _weatherHumidity;
  double? _weatherWind;
  double? _weatherPressure;
  String _weatherUpdated = '--:--';
  IconData _weatherIcon = Icons.cloud_rounded;

  static const List<String> _indoCities = [
    'Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Semarang', 'Makassar',
    'Palembang', 'Tangerang', 'Depok', 'Bekasi', 'Bogor', 'Malang',
    'Yogyakarta', 'Jombang', 'Kediri', 'Solo', 'Denpasar', 'Balikpapan',
    'Pontianak', 'Banjarmasin', 'Manado', 'Padang', 'Pekanbaru', 'Aceh',
    'Lampung', 'Cirebon', 'Tasikmalaya', 'Sukabumi', 'Purwokerto', 'Magelang',
    'Madiun', 'Sidoarjo', 'Gresik', 'Probolinggo', 'Banyuwangi', 'Jember',
    'Cianjur', 'Garut', 'Kuningan', 'Tegal', 'Pekalongan', 'Salatiga',
  ];

  late PageController _newsPageController;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;
  VideoPlayerController? _videoController;
  final FlutterLocalNotificationsPlugin _notifPlugin =
      FlutterLocalNotificationsPlugin();

  // --- TEMA HITAM UNGU + TEKS PUTIH ---
  static const Color bgMain = Color(0xFF0A0A0F);
  static const Color bgSurface = Color(0xFF14141A);
  static const Color bgCard = Color(0xFF14141A);
  static const Color textMain = Color(0xFFF5F5F7); // putih kebiruan
  static const Color textSub = Color(0xFFB0B0B8); // abu biru
  static const Color accentWhite = Color(0xFFE53935); // ocean blue
  static const Color borderLight = Color(0xFFFF8A80);
  static const Color borderGlass = Color(0xFFFF8A80);

  @override
  void initState() {
    super.initState();

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    // Hero card: video assets/videos/banner.mp4
    _initBannerVideo();

    _initNewsBanner();
    _selectedPage = _buildNewsPage();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initPrayerSchedule();
    _initWeather();
  }

  Future<void> _initBannerVideo() async {
    try {
      final ctrl = VideoPlayerController.asset('assets/videos/banner.mp4');
      await ctrl.initialize();
      await ctrl.setLooping(true);
      await ctrl.setVolume(0);
      await ctrl.seekTo(Duration.zero);
      // Hanya play jika sedang di tab Home (index 0)
      if (_bottomNavIndex == 0) {
        await ctrl.play();
      } else {
        await ctrl.pause();
      }
      if (!mounted) {
        await ctrl.dispose();
        return;
      }
      setState(() {
        _videoController = ctrl;
      });
    } catch (_) {
      // fallback diam — kartu tetap pakai warna gelap
    }
  }

  /// Play/pause hero video — tidak jalan di background tab lain
  Future<void> _setHeroVideoActive(bool active) async {
    final ctrl = _videoController;
    if (ctrl == null || !ctrl.value.isInitialized) return;
    try {
      if (active) {
        await ctrl.seekTo(Duration.zero);
        await ctrl.play();
      } else {
        await ctrl.pause();
      }
    } catch (_) {}
  }

  void _initNewsBanner() {
    _newsPageController = PageController(
      initialPage: 0,
      viewportFraction: 0.9,
    );

    _newsPageController.addListener(() {
      if (_newsPageController.hasClients && _newsPageController.page != null) {
        _currentNewsPage = _newsPageController.page!;
      }
    });

    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (Timer timer) {
        if (_newsPageController.hasClients) {
          int targetIndex = (_currentNewsPage + 1).round() % newsList.length;
          _newsPageController.animateToPage(
            targetIndex,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
          );
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse(Srv.wsUrl),
    );
    channel.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    CustomPopup.show(
      context,
      title: "Session Expired",
      message: message,
      icon: Icons.error_outline,
      iconColor: Colors.redAccent,
      confirmText: "OK",
      onConfirm: () {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (route) => false,
        );
      },
    );
  }

  void _onBottomNavTapped(int index) {
    // Video hero hanya aktif di tab Home
    _setHeroVideoActive(index == 0);
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        // WhatsApp → HomePage (video sendiri, hero di-pause)
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
          expiredDate: expiredDate,
        );
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _showWhatsAppMenu() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF25D366).withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      FontAwesomeIcons.whatsapp,
                      size: 36,
                      color: Color(0xFF25D366),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "WHATSAPP TOOLS",
                    style: TextStyle(
                      color: textMain,
                      fontFamily: 'Orbitron',
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Choose an action to perform",
                    style: TextStyle(color: textSub, fontSize: 13),
                  ),
                  const SizedBox(height: 24),
                  _buildWhatsAppOption(
                    icon: Icons.bug_report,
                    color: Colors.redAccent,
                    title: "WhatsApp Crash",
                    subtitle: "Send payloads & crash codes",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() {
                        _bottomNavIndex = 1;
                        _selectedPage = HomePage(
                          username: username,
                          password: password,
                          listBug: listBug,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        );
                      });
                    },
                  ),
                  const SizedBox(height: 12),
                  _buildWhatsAppOption(
                    icon: Icons.devices,
                    color: Colors.greenAccent,
                    title: "Manage Sender",
                    subtitle: "Pair devices & manage sessions",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        foregroundColor: textMain,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      child: const Text(
                        "Cancel",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWhatsAppOption({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: textMain,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: textSub,
                      fontSize: 13,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios,
                color: textSub.withOpacity(0.5), size: 14),
          ],
        ),
      ),
    );
  }

  String _getGreetingPeriod() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 6) return "Subuh";
    if (hour >= 6 && hour < 11) return "Pagi";
    if (hour >= 11 && hour < 15) return "Siang";
    if (hour >= 15 && hour < 18) return "Sore";
    return "Malam";
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "developer":
        return const Color(0xFFFFAB91);
      case "owner":
        return const Color(0xFFEF5350);
      case "admin":
        return const Color(0xFFFF8A80);
      case "reseller":
        return const Color(0xFFFFB74D);
      case "partner":
        return const Color(0xFF81C784);
      case "moderator":
        return const Color(0xFFFF8A80);
      case "vip":
        return const Color(0xFFFFD600);
      default:
        return textSub;
    }
  }

  Widget _buildHoxtenHeroCard() {
    final bugCount = listBug.length;
    final ddosCount = listDoos.length;
    final expText =
        expiredDate.toString().isEmpty ? '-' : expiredDate.toString();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            children: [
              // Video banner.mp4 sebagai background kartu
              Positioned.fill(
                child: (_videoController != null &&
                        _videoController!.value.isInitialized)
                    ? FittedBox(
                        fit: BoxFit.cover,
                        clipBehavior: Clip.hardEdge,
                        child: SizedBox(
                          width: _videoController!.value.size.width,
                          height: _videoController!.value.size.height,
                          child: VideoPlayer(_videoController!),
                        ),
                      )
                    : Container(color: const Color(0xFF0A0A0F)),
              ),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.black.withOpacity(0.55),
                        Colors.black.withOpacity(0.72),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.06),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.12)),
                          ),
                          child: const Icon(Icons.person_rounded,
                              color: Colors.white70, size: 28),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Welcome Back.',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.55),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                username.toUpperCase(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.2,
                                  fontFamily: 'Orbitron',
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Text(
                                    role.toUpperCase(),
                                    style: TextStyle(
                                      color: _getRoleColor(role),
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                  Text(
                                    '  •  ONLINE',
                                    style: TextStyle(
                                      color: Colors.greenAccent
                                          .withOpacity(0.9),
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: const Color(0xFFC62828).withOpacity(0.35),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: const Color(0xFFFF5252)
                                    .withOpacity(0.5)),
                          ),
                          child: const Text(
                            'SESSION AKTIF',
                            style: TextStyle(
                              color: Color(0xFFB0B0B8),
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _statChip(
                            icon: Icons.groups_rounded,
                            label: 'Online Users',
                            value: '$onlineUsers Online',
                            accent: const Color(0xFFFF5252),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _statChip(
                            icon: Icons.hub_outlined,
                            label: 'Sender Aktif',
                            value: '$activeConnections terhubung',
                            accent: const Color(0xFFFFB74D),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _miniStat(
                            icon: Icons.bug_report,
                            label: 'BUG',
                            value: '$bugCount item',
                            color: const Color(0xFFE53935),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _miniStat(
                            icon: Icons.flash_on,
                            label: 'DDOS',
                            value: '$ddosCount item',
                            color: const Color(0xFFFFA726),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _miniStat(
                            icon: Icons.timer_outlined,
                            label: 'EXPIRATION',
                            value: expText,
                            color: const Color(0xFF66BB6A),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statChip({
    required IconData icon,
    required String label,
    required String value,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accent.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 14, color: accent),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: accent.withOpacity(0.95),
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.28)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 12, color: color),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                  label,
                  style: TextStyle(
                    color: color.withOpacity(0.95),
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.4,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureDuo() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Row(
        children: [
          Expanded(
            child: _featureBigCard(
              title: 'Manage\nSender',
              subtitle: 'Kelola Sender',
              badge: 'SENDER',
              icon: Icons.wifi_tethering_rounded,
              colors: const [Color(0xFF8B1538), Color(0xFFC62828)],
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BugSenderPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _featureBigCard(
              title: 'Remote\nAcces Trojan',
              subtitle: 'RAT CONTROL',
              badge: 'CONTROL',
              icon: Icons.dashboard_customize_rounded,
              colors: const [Color(0xFF1A237E), Color(0xFF3949AB)],
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => DeviceDashboardPage(sessionKey: sessionKey),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _featureBigCard({
    required String title,
    required String subtitle,
    required String badge,
    required IconData icon,
    required List<Color> colors,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 140,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: colors,
          ),
          boxShadow: [
            BoxShadow(
              color: colors.last.withOpacity(0.35),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.white.withOpacity(0.9), size: 22),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    badge,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
              ],
            ),
            const Spacer(),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                height: 1.15,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.white.withOpacity(0.75),
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlobalChatPreview() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 10),
            decoration: const BoxDecoration(
              border: Border(left: BorderSide(color: accentWhite, width: 3.5)),
            ),
            child: const Row(
              children: [
                Icon(Icons.groups_2_rounded, color: textMain, size: 20),
                SizedBox(width: 8),
                Text(
                  "GLOBAL CHAT",
                  style: TextStyle(
                    color: textMain,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 60,
            height: 4,
            decoration: BoxDecoration(
              color: accentWhite,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "Ngobrol langsung dengan semua pengguna MidNight Crash di satu ruangan.",
            style: TextStyle(color: textSub, fontSize: 13, height: 1.45),
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChatPage(
                  currentUsername: username,
                  currentRole: role,
                  sessionKey: sessionKey,
                ),
              ),
            ),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: bgCard,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.black, width: 1.5),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black,
                    blurRadius: 0,
                    offset: Offset(4, 4),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: accentWhite.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.black, width: 1.2),
                    ),
                    child: const Icon(
                      Icons.groups_2_rounded,
                      size: 22,
                      color: accentWhite,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Community Room",
                          style: TextStyle(
                            color: textMain,
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                color: Colors.green,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 5),
                            const Text(
                              "Tap untuk masuk ke ruang chat",
                              style: TextStyle(
                                color: textSub,
                                fontSize: 13,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentWhite.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_forward_rounded,
                      color: accentWhite,
                      size: 20,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Jadwal Sholat ────────────────────────────────────────────────────────
  Future<void> _initPrayerSchedule() async {
    await _initLocalNotifications();
    final prefs = await SharedPreferences.getInstance();
    _prayerCity = prefs.getString('prayer_city') ?? 'Jombang';
    await _fetchPrayerTimes();
    _prayerTimer?.cancel();
    _prayerTimer = Timer.periodic(const Duration(seconds: 20), (_) {
      _updateNextPrayer();
      _checkPrayerNotification();
    });
  }

  Future<void> _initLocalNotifications() async {
    try {
      tzdata.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation('Asia/Jakarta'));
      const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
      const iosInit = DarwinInitializationSettings();
      await _notifPlugin.initialize(
        const InitializationSettings(android: androidInit, iOS: iosInit),
      );
      final android = _notifPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
      const channel = AndroidNotificationChannel(
        'prayer_channel',
        'Jadwal Sholat',
        description: 'Notifikasi waktu sholat',
        importance: Importance.high,
      );
      await android?.createNotificationChannel(channel);
    } catch (e) {
      debugPrint('notif init: $e');
    }
  }

  Future<void> _schedulePrayerNotifications() async {
    if (_prayerTimes.isEmpty) return;
    try {
      // Minta izin exact alarm (Android 12+) bila tersedia
      final android = _notifPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      try {
        await android?.requestExactAlarmsPermission();
      } catch (_) {}

      await _notifPlugin.cancelAll();
      final now = tz.TZDateTime.now(tz.local);
      final order = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
      int id = 100;
      for (final name in order) {
        final t = _prayerTimes[name];
        if (t == null || !t.contains(':')) continue;
        final parts = t.split(':');
        final h = int.tryParse(parts[0]) ?? 0;
        final m = int.tryParse(parts[1]) ?? 0;
        var when = tz.TZDateTime(tz.local, now.year, now.month, now.day, h, m);
        if (!when.isAfter(now)) {
          when = when.add(const Duration(days: 1));
        }
        const details = NotificationDetails(
          android: AndroidNotificationDetails(
            'prayer_channel',
            'Jadwal Sholat',
            channelDescription: 'Notifikasi waktu sholat',
            importance: Importance.max,
            priority: Priority.max,
            playSound: true,
            enableVibration: true,
            icon: '@mipmap/ic_launcher',
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentSound: true,
            presentBadge: true,
          ),
        );
        try {
          await _notifPlugin.zonedSchedule(
            id,
            'Waktu Sholat $name',
            'Sudah waktunya sholat $name ($t). Semoga ibadahmu khusyuk.',
            when,
            details,
            androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
            uiLocalNotificationDateInterpretation:
                UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.time,
          );
        } catch (_) {
          // Fallback jika exact alarm ditolak
          await _notifPlugin.zonedSchedule(
            id,
            'Waktu Sholat $name',
            'Sudah waktunya sholat $name ($t). Semoga ibadahmu khusyuk.',
            when,
            details,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            uiLocalNotificationDateInterpretation:
                UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.time,
          );
        }
        id++;
      }
      debugPrint('prayer notifs scheduled');
    } catch (e) {
      debugPrint('schedule prayer notif: $e');
    }
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    try {
      final city = Uri.encodeComponent(_prayerCity);
      final uri = Uri.parse(
        'https://api.aladhan.com/v1/timingsByCity?city=$city&country=Indonesia&method=20',
      );
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final t = data['data']?['timings'] as Map<String, dynamic>?;
        if (t != null) {
          String clean(String? v) =>
              (v ?? '--:--').toString().split(' ').first.trim();
          _prayerTimes = {
            'Subuh': clean(t['Fajr']?.toString()),
            'Dzuhur': clean(t['Dhuhr']?.toString()),
            'Ashar': clean(t['Asr']?.toString()),
            'Maghrib': clean(t['Maghrib']?.toString()),
            'Isya': clean(t['Isha']?.toString()),
          };
          _notifiedPrayers.clear();
          _updateNextPrayer();
          await _schedulePrayerNotifications();
        }
      }
    } catch (e) {
      debugPrint('prayer fetch error: $e');
    }
    if (mounted) setState(() => _prayerLoading = false);
  }

  int _toMinutes(String hhmm) {
    final p = hhmm.split(':');
    if (p.length < 2) return -1;
    final h = int.tryParse(p[0]) ?? -1;
    final m = int.tryParse(p[1]) ?? -1;
    if (h < 0 || m < 0) return -1;
    return h * 60 + m;
  }

  void _updateNextPrayer() {
    if (_prayerTimes.isEmpty) return;
    final now = DateTime.now();
    final nowMin = now.hour * 60 + now.minute;
    final order = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];
    String label = order.first;
    String time = _prayerTimes[label] ?? '--:--';
    for (final name in order) {
      final t = _prayerTimes[name] ?? '--:--';
      final mins = _toMinutes(t);
      if (mins >= nowMin) {
        label = name;
        time = t;
        break;
      }
      // if all passed, next is Subuh tomorrow
      if (name == order.last) {
        label = 'Subuh';
        time = _prayerTimes['Subuh'] ?? '--:--';
      }
    }
    if (!mounted) return;
    if (label != _nextPrayerLabel || time != _nextPrayerTime) {
      setState(() {
        _nextPrayerLabel = label;
        _nextPrayerTime = time;
      });
    }
  }

  void _checkPrayerNotification() {
    if (_prayerTimes.isEmpty || !mounted) return;
    final now = DateTime.now();
    final nowMin = now.hour * 60 + now.minute;
    final today = '${now.year}-${now.month}-${now.day}';
    for (final e in _prayerTimes.entries) {
      final mins = _toMinutes(e.value);
      if (mins < 0) continue;
      final key = '$today-${e.key}';
      if (mins == nowMin && !_notifiedPrayers.contains(key)) {
        _notifiedPrayers.add(key);
        _showPrayerNotification(e.key, e.value);
      }
    }
  }

  void _showPrayerNotification(String name, String time) {
    // Notifikasi sistem (tampil meski app di foreground / background)
    try {
      _notifPlugin.show(
        200 + name.hashCode % 50,
        'Waktu Sholat $name',
        'Sudah waktunya sholat $name ($time). Semoga ibadahmu khusyuk.',
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'prayer_channel',
            'Jadwal Sholat',
            channelDescription: 'Notifikasi waktu sholat',
            importance: Importance.max,
            priority: Priority.max,
            playSound: true,
            enableVibration: true,
            icon: '@mipmap/ic_launcher',
          ),
          iOS: DarwinNotificationDetails(
            presentAlert: true,
            presentSound: true,
          ),
        ),
      );
    } catch (e) {
      debugPrint('show prayer notif: $e');
    }
    if (!mounted) return;
    try {
      CustomPopup.show(
        context,
        title: 'Waktu Sholat',
        message: 'Sudah waktunya sholat $name ($time).\nSemoga ibadahmu khusyuk.',
        icon: Icons.mosque_rounded,
        iconColor: const Color(0xFFE53935),
        confirmText: 'OK',
      );
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Sudah waktunya sholat $name ($time)'),
          backgroundColor: const Color(0xFFE53935),
        ),
      );
    }
  }

  Future<void> _pickPrayerCity() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        String q = '';
        return StatefulBuilder(
          builder: (ctx, setModal) {
            final filtered = _indoCities
                .where((c) => c.toLowerCase().contains(q.toLowerCase()))
                .toList();
            return Container(
              height: MediaQuery.of(ctx).size.height * 0.7,
              decoration: const BoxDecoration(
                color: Color(0xFF0A0A0F),
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 12),
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      'Pilih Kota',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: TextField(
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Cari kota...',
                        hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                        prefixIcon: const Icon(Icons.search, color: Color(0xFFFF8A80)),
                        filled: true,
                        fillColor: const Color(0xFF14141A),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      onChanged: (v) => setModal(() => q = v),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: ListView.builder(
                      itemCount: filtered.length,
                      itemBuilder: (_, i) {
                        final city = filtered[i];
                        final active = city == _prayerCity;
                        return ListTile(
                          title: Text(
                            city,
                            style: TextStyle(
                              color: active ? const Color(0xFFFF8A80) : Colors.white,
                              fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                            ),
                          ),
                          trailing: active
                              ? const Icon(Icons.check_circle, color: Color(0xFFE53935))
                              : null,
                          onTap: () => Navigator.pop(ctx, city),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (selected != null && selected.isNotEmpty) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('prayer_city', selected);
      setState(() => _prayerCity = selected);
      await _fetchPrayerTimes();
    }
  }

  // ── Cuaca (GPS) ──────────────────────────────────────────────────────────
  Future<void> _initWeather() async {
    await _fetchWeatherByGps();
  }

  String _weatherCodeToId(int code) {
    // Open-Meteo WMO codes → deskripsi ID
    if (code == 0) return 'Cerah';
    if (code == 1) return 'Cerah berawan';
    if (code == 2) return 'Berawan sebagian';
    if (code == 3) return 'Berawan';
    if (code == 45 || code == 48) return 'Berkabut';
    if (code >= 51 && code <= 57) return 'Gerimis';
    if (code >= 61 && code <= 67) return 'Hujan';
    if (code >= 71 && code <= 77) return 'Salju';
    if (code >= 80 && code <= 82) return 'Hujan lokal';
    if (code >= 85 && code <= 86) return 'Salju lokal';
    if (code >= 95) return 'Badai petir';
    return 'Awan pecah';
  }

  IconData _weatherCodeToIcon(int code) {
    if (code == 0) return Icons.wb_sunny_rounded;
    if (code <= 2) return Icons.cloud_queue_rounded;
    if (code == 3) return Icons.cloud_rounded;
    if (code == 45 || code == 48) return Icons.cloud_rounded;
    if (code >= 51 && code <= 67) return Icons.water_drop_rounded;
    if (code >= 80 && code <= 82) return Icons.grain_rounded;
    if (code >= 95) return Icons.thunderstorm_rounded;
    return Icons.cloud_rounded;
  }

  Future<bool> _ensureLocationPermission() async {
    var status = await Permission.locationWhenInUse.status;
    if (status.isGranted) return true;
    status = await Permission.locationWhenInUse.request();
    if (status.isGranted) return true;
    if (status.isPermanentlyDenied) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Izin lokasi ditolak. Buka pengaturan aplikasi.'),
            action: SnackBarAction(
              label: 'Settings',
              onPressed: openAppSettings,
            ),
          ),
        );
      }
      return false;
    }
    return false;
  }

  Future<void> _fetchWeatherByGps() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);
    try {
      final ok = await _ensureLocationPermission();
      if (!ok) {
        setState(() {
          _weatherLoading = false;
          _weatherCity = 'Izin lokasi dibutuhkan';
          _weatherDesc = 'Ketuk refresh untuk mencoba lagi';
        });
        return;
      }

      final serviceOn = await Geolocator.isLocationServiceEnabled();
      if (!serviceOn) {
        setState(() {
          _weatherLoading = false;
          _weatherCity = 'GPS mati';
          _weatherDesc = 'Aktifkan lokasi perangkat';
        });
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit: const Duration(seconds: 15),
      );

      // Nama kota (reverse geocode Nominatim)
      try {
        final geoUri = Uri.parse(
          'https://nominatim.openstreetmap.org/reverse?lat=${pos.latitude}&lon=${pos.longitude}&format=json&zoom=10&addressdetails=1',
        );
        final geoRes = await http.get(
          geoUri,
          headers: {'User-Agent': 'MidNight CrashApp/1.0'},
        ).timeout(const Duration(seconds: 10));
        if (geoRes.statusCode == 200) {
          final g = jsonDecode(geoRes.body) as Map<String, dynamic>;
          final addr = (g['address'] as Map?) ?? {};
          _weatherCity = (addr['city'] ??
                  addr['town'] ??
                  addr['county'] ??
                  addr['state'] ??
                  g['name'] ??
                  'Lokasi')
              .toString();
          _weatherCountry = (addr['country'] ?? 'Indonesia').toString();
        }
      } catch (_) {
        _weatherCity = 'Lokasi Anda';
        _weatherCountry = 'Indonesia';
      }

      // Cuaca Open-Meteo
      final wUri = Uri.parse(
        'https://api.open-meteo.com/v1/forecast'
        '?latitude=${pos.latitude}&longitude=${pos.longitude}'
        '&current=temperature_2m,relative_humidity_2m,apparent_temperature,'
        'weather_code,wind_speed_10m,surface_pressure'
        '&timezone=Asia%2FJakarta',
      );
      final wRes = await http.get(wUri).timeout(const Duration(seconds: 12));
      if (wRes.statusCode == 200) {
        final data = jsonDecode(wRes.body) as Map<String, dynamic>;
        final cur = (data['current'] as Map?) ?? {};
        final code = int.tryParse('${cur['weather_code']}') ?? 0;
        final now = DateTime.now();
        _weatherTemp = (cur['temperature_2m'] as num?)?.toDouble();
        _weatherFeels = (cur['apparent_temperature'] as num?)?.toDouble();
        _weatherHumidity = (cur['relative_humidity_2m'] as num?)?.toInt();
        _weatherWind = (cur['wind_speed_10m'] as num?)?.toDouble();
        _weatherPressure = (cur['surface_pressure'] as num?)?.toDouble();
        _weatherDesc = _weatherCodeToId(code);
        _weatherIcon = _weatherCodeToIcon(code);
        _weatherUpdated =
            '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      }
    } catch (e) {
      debugPrint('weather error: $e');
      if (mounted) {
        setState(() {
          _weatherCity = 'Gagal memuat';
          _weatherDesc = 'Coba lagi';
        });
      }
    }
    if (mounted) setState(() => _weatherLoading = false);
  }

  Widget _buildWeatherCard() {
    final tempStr = _weatherTemp != null
        ? '${_weatherTemp!.toStringAsFixed(1)}°C'
        : '--°C';
    final feelsStr = _weatherFeels != null
        ? '${_weatherFeels!.toStringAsFixed(1)}°C'
        : '--';
    final humStr = _weatherHumidity != null ? '$_weatherHumidity%' : '--';
    final windStr =
        _weatherWind != null ? '${_weatherWind!.toStringAsFixed(1)} m/s' : '--';
    final pressStr = _weatherPressure != null
        ? '${_weatherPressure!.toStringAsFixed(0)} hPa'
        : '--';

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color(0xFF14141A).withOpacity(0.95),
          border: Border.all(color: const Color(0xFFE53935).withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE53935).withOpacity(0.12),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header lokasi
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE53935).withOpacity(0.18),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.location_on_rounded,
                      color: Color(0xFFFF8A80), size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _weatherCity,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        _weatherCountry.toUpperCase(),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.45),
                          fontSize: 11,
                          letterSpacing: 0.6,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _weatherLoading ? null : _fetchWeatherByGps,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE53935).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: const Color(0xFFE53935).withOpacity(0.45)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _weatherLoading
                              ? Icons.hourglass_top_rounded
                              : Icons.my_location_rounded,
                          color: const Color(0xFFFF8A80),
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _weatherLoading ? '...' : 'GPS',
                          style: const TextStyle(
                            color: Color(0xFFFF8A80),
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Suhu besar
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE53935).withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(_weatherIcon,
                      color: const Color(0xFFFF8A80), size: 28),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tempStr,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 36,
                          fontWeight: FontWeight.w900,
                          height: 1.0,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _weatherLoading ? 'Memuat cuaca...' : _weatherDesc,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.75),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Terasa $feelsStr  ·  $humStr',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.45),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            // Mini stats
            Row(
              children: [
                Expanded(
                  child: _weatherMini(
                    Icons.air_rounded,
                    windStr,
                    'Angin',
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _weatherMini(
                    Icons.speed_rounded,
                    pressStr,
                    'Tekanan',
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _weatherMini(
                    Icons.access_time_rounded,
                    _weatherUpdated,
                    'Update',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _weatherMini(IconData icon, String value, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFE53935).withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE53935).withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 16, color: const Color(0xFFFF8A80)),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.45),
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayerScheduleCard() {
    final items = [
      ('Subuh', Icons.nightlight_round, _prayerTimes['Subuh'] ?? '--:--'),
      ('Dzuhur', Icons.wb_sunny_rounded, _prayerTimes['Dzuhur'] ?? '--:--'),
      ('Ashar', Icons.cloud_rounded, _prayerTimes['Ashar'] ?? '--:--'),
      ('Maghrib', Icons.wb_twilight, _prayerTimes['Maghrib'] ?? '--:--'),
      ('Isya', Icons.brightness_2_rounded, _prayerTimes['Isya'] ?? '--:--'),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color(0xFF14141A).withOpacity(0.95),
          border: Border.all(color: const Color(0xFFE53935).withOpacity(0.35)),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE53935).withOpacity(0.12),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE53935).withOpacity(0.18),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.mosque_rounded,
                      color: Color(0xFFFF8A80), size: 20),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'JADWAL SHOLAT',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          const Icon(Icons.location_on,
                              size: 12, color: Color(0xFFFF8A80)),
                          const SizedBox(width: 4),
                          Flexible(
                            child: Text(
                              _prayerCity,
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.7),
                                fontSize: 12,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _pickPrayerCity,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE53935),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.swap_horiz, color: Colors.white, size: 14),
                        SizedBox(width: 4),
                        Text(
                          'GANTI',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFE53935).withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: const Color(0xFFE53935).withOpacity(0.25)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Color(0xFFFF8A80),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _prayerLoading
                          ? 'Memuat jadwal...'
                          : 'Menuju $_nextPrayerLabel : $_nextPrayerTime',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE53935),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'NOW',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                for (int i = 0; i < items.length; i++) ...[
                  if (i > 0) const SizedBox(width: 6),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: items[i].$1 == _nextPrayerLabel
                            ? const Color(0xFFE53935).withOpacity(0.35)
                            : const Color(0xFFE53935).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: items[i].$1 == _nextPrayerLabel
                              ? const Color(0xFFFF8A80)
                              : const Color(0xFFE53935).withOpacity(0.2),
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(items[i].$2,
                              size: 16, color: const Color(0xFFFF8A80)),
                          const SizedBox(height: 4),
                          Text(
                            items[i].$1.toUpperCase(),
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.75),
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            items[i].$3,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _buildHoxtenHeroCard(),
          _buildFeatureDuo(),
          const SizedBox(height: 18),
          // QUICK ACTIONS (gaya Justin Official)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'QUICK ACTIONS',
                  style: TextStyle(
                    color: textMain,
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.0,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Akses cepat fitur favorit kamu',
                  style: TextStyle(color: textSub.withOpacity(0.85), fontSize: 12),
                ),
                const SizedBox(height: 14),
                // Baris 1: Order Nokos + Chat
                Row(
                  children: [
                    Expanded(
                      child: _JustinActionTile(
                        title: 'Order Nokos',
                        subtitle: 'Beli nomor OTP',
                        icon: Icons.phone_android_rounded,
                        color: const Color(0xFFE53935),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => OrderNokosPage(
                              sessionKey: sessionKey,
                              username: username,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _JustinActionTile(
                        title: 'Chat',
                        subtitle: 'Global chat room',
                        icon: Icons.chat_bubble_rounded,
                        color: const Color(0xFF7E57C2),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => ChatPage(
                                currentUsername: username,
                                currentRole: role,
                                sessionKey: sessionKey,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // Join channel — panjang
                _JustinWideTile(
                  title: 'Join Channel Telegram',
                  subtitle: 'Channel resmi MidNight Crash Community',
                  icon: FontAwesomeIcons.telegram,
                  color: const Color(0xFF29B6F6),
                  onTap: () => _openUrl('https://t.me/MidNight CrashComunity'),
                ),
                const SizedBox(height: 10),
                // Riwayat + Profile
                Row(
                  children: [
                    Expanded(
                      child: _JustinActionTile(
                        title: 'Riwayat',
                        subtitle: 'Histori aktivitas',
                        icon: Icons.history_rounded,
                        color: const Color(0xFFFF8A80),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RiwayatPage(
                              sessionKey: sessionKey,
                              role: role,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _JustinActionTile(
                        title: 'Profile',
                        subtitle: 'Kelola akun',
                        icon: Icons.person_rounded,
                        color: const Color(0xFF81C784),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProfilePage(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // Contact + Info
                Row(
                  children: [
                    Expanded(
                      child: _JustinActionTile(
                        title: 'Contact',
                        subtitle: 'Hubungi support',
                        icon: Icons.contact_support_rounded,
                        color: const Color(0xFFFFB74D),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const ContactPage()),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _JustinActionTile(
                        title: 'Info',
                        subtitle: 'Bantuan & panduan',
                        icon: Icons.info_rounded,
                        color: const Color(0xFF64B5F6),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => InfoPage(
                              sessionKey: sessionKey,
                              username: username,
                              role: role,
                              expiredDate: expiredDate,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // Contact Developer + Role Page — sejajar (2 kolom)
                Builder(builder: (context) {
                  final roleTile = _buildRoleBasedActionTile();
                  if (roleTile != null) {
                    return Row(
                      children: [
                        Expanded(
                          child: _JustinActionTile(
                            title: 'Contact Developer',
                            subtitle: 'Telegram @topsryaa',
                            icon: FontAwesomeIcons.telegram,
                            color: const Color(0xFF0088CC),
                            onTap: () => _openUrl('https://t.me/topsryaa'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: roleTile),
                      ],
                    );
                  }
                  // Fallback: role tidak punya halaman khusus → full width
                  return _JustinWideTile(
                    title: 'Contact Developer',
                    subtitle: 'Telegram @topsryaa',
                    icon: FontAwesomeIcons.telegram,
                    color: const Color(0xFF0088CC),
                    onTap: () => _openUrl('https://t.me/topsryaa'),
                  );
                }),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // LATEST UPDATE
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.only(left: 10),
                  decoration: const BoxDecoration(
                    border: Border(
                      left: BorderSide(color: accentWhite, width: 3.5),
                    ),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.calendar_month_rounded,
                          color: textMain, size: 20),
                      SizedBox(width: 8),
                      Text(
                        "LATEST UPDATE",
                        style: TextStyle(
                          color: textMain,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.2,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: accentWhite,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  "Keep yourself informed about recent system maintenance, newly added tools, and important announcements from the administration.",
                  style: TextStyle(
                    color: textSub,
                    fontSize: 13,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            height: 180,
            margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: Stack(
              children: [
                PageView.builder(
                  controller: _newsPageController,
                  itemCount: newsList.isEmpty ? 1 : newsList.length,
                  itemBuilder: (context, index) {
                    if (newsList.isEmpty) {
                      return Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: bgCard,
                          border: Border.all(color: Colors.black, width: 1.5),
                        ),
                        child: const Center(
                          child: Text(
                            "No updates yet",
                            style: TextStyle(color: textSub),
                          ),
                        ),
                      );
                    }
                    final item = newsList[index];
                    final String mediaUrl = (item is Map)
                        ? (item['image'] ?? item['media'] ?? '').toString()
                        : '';
                    final String title = (item is Map)
                        ? (item['title'] ?? 'Update').toString()
                        : 'Update';
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: bgCard,
                        border: Border.all(color: Colors.black, width: 1.5),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black,
                            blurRadius: 0,
                            offset: Offset(4, 4),
                          ),
                        ],
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (mediaUrl.isNotEmpty)
                            NewsMedia(url: mediaUrl)
                          else
                            Container(color: bgSurface),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.transparent,
                                  Colors.black.withOpacity(0.75),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 14,
                            right: 14,
                            bottom: 14,
                            child: Text(
                              title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                Positioned(
                  bottom: 8,
                  left: 0,
                  right: 0,
                  child: AnimatedBuilder(
                    animation: _newsPageController,
                    builder: (context, child) {
                      double currentNewsPage = 0.0;
                      if (_newsPageController.hasClients &&
                          _newsPageController.page != null) {
                        currentNewsPage = _newsPageController.page!;
                      } else {
                        currentNewsPage = _currentNewsPage;
                      }

                      return Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          newsList.isEmpty ? 1 : newsList.length,
                          (index) {
                            double diff = (index - currentNewsPage).abs();
                            double width = 5.0;
                            double opacity = 0.3;

                            if (diff < 1) {
                              width = 25.0 - (diff * 20.0);
                              opacity = 1.0 - (diff * 0.7);
                            }

                            return Container(
                              margin:
                                  const EdgeInsets.symmetric(horizontal: 2.5),
                              width: width,
                              height: 5,
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(opacity),
                                borderRadius: BorderRadius.circular(5),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // JADWAL SHOLAT
          _buildPrayerScheduleCard(),

          // CUACA
          _buildWeatherCard(),

          const SizedBox(height: 110),
        ],
      ),
    );
  }

  // ── Tile Role Page (sejajar dengan Contact Developer) ─────────────────────
  Widget? _buildRoleBasedActionTile() {
    const Color greenIcon = Color(0xFF66BB6A); // hijau sesuai tema
    final r = role.toLowerCase();

    Widget tile({
      required String title,
      required String subtitle,
      required IconData icon,
      required VoidCallback onTap,
    }) {
      return _JustinActionTile(
        title: title,
        subtitle: subtitle,
        icon: icon,
        color: greenIcon,
        onTap: onTap,
      );
    }

    switch (r) {
      case 'admin':
        return tile(
          title: 'Admin Page',
          subtitle: 'Admin Page Settings',
          icon: Icons.admin_panel_settings_rounded,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => AdminPage(sessionKey: sessionKey)),
          ),
        );

      case 'reseller':
        return tile(
          title: 'Seller Page',
          subtitle: 'Seller Page Settings',
          icon: Icons.storefront_rounded,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
                builder: (_) => SellerPage(keyToken: sessionKey)),
          ),
        );

      case 'partner':
        return tile(
          title: 'Partner Page',
          subtitle: 'Partner Page Settings',
          icon: Icons.handshake_rounded,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  PartnerPage(sessionKey: sessionKey, username: username),
            ),
          ),
        );

      case 'moderator':
        return tile(
          title: 'Moderator Page',
          subtitle: 'Moderator Page Settings',
          icon: Icons.gavel_rounded,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  ModeratorPage(sessionKey: sessionKey, username: username),
            ),
          ),
        );

      case 'owner':
        return tile(
          title: 'Owner Page',
          subtitle: 'Owner Page Settings',
          icon: Icons.workspace_premium_rounded,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  OwnerPage(sessionKey: sessionKey, username: username),
            ),
          ),
        );

      default:
        return null;
    }
  }

  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.55,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 180,
            decoration: const BoxDecoration(color: bgMain),
            child: SafeArea(
              child: Center(
                child: Image.asset(
                  'assets/images/logo.png',
                  width: 120,
                  height: 120,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.transparent,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 10),
                children: [
                  _buildDrawerMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  _buildDrawerMenuItem(
                    icon: Icons.logout,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: isLogout ? Colors.redAccent : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        boxShadow: isLogout
            ? [
                BoxShadow(
                  color: Colors.redAccent.withOpacity(0.3),
                  blurRadius: 8,
                  spreadRadius: 1,
                )
              ]
            : null,
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: isLogout ? Colors.white : textSub,
          size: 22,
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.white : textMain,
            fontWeight: FontWeight.bold,
            fontSize: 15,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: isLogout ? Colors.white70 : textSub,
          size: 12,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF14141A).withOpacity(0.9),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Text(
              "MidNight Crash",
              style: TextStyle(
                color: textMain,
                fontWeight: FontWeight.w900,
                fontSize: 14,
                fontFamily: 'Orbitron',
                letterSpacing: 2.0,
              ),
            ),
          ),
          centerTitle: false,
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: const IconThemeData(color: textMain),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout_rounded, color: textMain),
              tooltip: 'Log Out',
              onPressed: () async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LandingPage()),
                  (route) => false,
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.headset_mic_outlined, color: textMain),
              tooltip: 'Customer Service',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ContactPage()),
              ),
            ),
            IconButton(
              icon: const Icon(FontAwesomeIcons.userCircle, color: textMain),
              tooltip: 'My Profile',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProfilePage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  ),
                ),
              ),
            ),
          ],
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.transparent,
          child: SafeArea(
            child: FadeTransition(
              opacity: _animation,
              child: _selectedPage,
            ),
          ),
        ),
        extendBody: true,
        bottomNavigationBar: _buildGlazeNavBar(),
      ),
    );
  }

  Widget _buildGlazeNavBar() {
    // Glaze Nav Bar default (tanpa foto nav.jpg) — tema dark, tombol aktif merah
    const activeRed = Color(0xFFE53935);
    return GlazeNavBar(
      index: _bottomNavIndex,
      backgroundColor: const Color(0xFF0A0A0F),
      color: const Color(0xFF1A1A22),
      glassBlur: 20,
      glassOpacity: 0.35,
      glassBorderRadius: 0,
      glassBorderWidth: 1.5,
      glassBorderColor: Colors.white.withOpacity(0.12),
      buttonBackgroundColor: activeRed,
      buttonBorderColor: Colors.white.withOpacity(0.9),
      buttonBorderWidth: 3.0,
      buttonGradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFFFF5252), Color(0xFFC62828)],
      ),
      animationDuration: const Duration(milliseconds: 600),
      animationCurve: Curves.easeOut,
      onTap: _onBottomNavTapped,
      items: [
        GlazeNavBarItem(
          child: Icon(
            Icons.home_rounded,
            color: _bottomNavIndex == 0 ? Colors.white : Colors.white70,
            size: 24,
          ),
          label: 'Home',
          labelStyle: TextStyle(
            color: _bottomNavIndex == 0 ? activeRed : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        GlazeNavBarItem(
          child: Icon(
            FontAwesomeIcons.whatsapp,
            color: _bottomNavIndex == 1 ? Colors.white : Colors.white70,
            size: 20,
          ),
          label: 'WA',
          labelStyle: TextStyle(
            color: _bottomNavIndex == 1 ? activeRed : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        GlazeNavBarItem(
          child: Icon(
            Icons.notifications_rounded,
            color: _bottomNavIndex == 2 ? Colors.white : Colors.white70,
            size: 24,
          ),
          label: 'Info',
          labelStyle: TextStyle(
            color: _bottomNavIndex == 2 ? activeRed : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
        GlazeNavBarItem(
          child: Icon(
            Icons.build_circle,
            color: _bottomNavIndex == 3 ? Colors.white : Colors.white70,
            size: 24,
          ),
          label: 'Tools',
          labelStyle: TextStyle(
            color: _bottomNavIndex == 3 ? activeRed : Colors.white70,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    try {
      _videoController?.pause();
    } catch (_) {}
    _videoController?.dispose();
    _videoController = null;
    _newsTimer?.cancel();
    _prayerTimer?.cancel();
    _newsPageController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    super.dispose();
  }
}

class _QuickActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 168,
        margin: const EdgeInsets.only(right: 12, bottom: 4, top: 2),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
        decoration: BoxDecoration(
          color: const Color(0xFF16161E),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.28),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: accent, size: 20),
                ),
                const Spacer(),
                Icon(Icons.arrow_forward_ios_rounded,
                    size: 12, color: Colors.white.withOpacity(0.35)),
              ],
            ),
            const Spacer(),
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13.5,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Path _buildNotchedNavBarPath(Size size) {
  const double radius = 30;
  const double notchRadius = 34;
  final double centerX = size.width / 2;

  final path = Path();
  path.moveTo(0, radius);
  path.quadraticBezierTo(0, 0, radius, 0);
  path.lineTo(centerX - notchRadius - 6, 0);
  path.arcToPoint(
    Offset(centerX + notchRadius + 6, 0),
    radius: const Radius.circular(notchRadius),
    clockwise: false,
  );
  path.lineTo(size.width - radius, 0);
  path.quadraticBezierTo(size.width, 0, size.width, radius);
  path.lineTo(size.width, size.height - radius);
  path.quadraticBezierTo(
    size.width,
    size.height,
    size.width - radius,
    size.height,
  );
  path.lineTo(radius, size.height);
  path.quadraticBezierTo(0, size.height, 0, size.height - radius);
  path.close();
  return path;
}

class _NotchedNavBarClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) => _buildNotchedNavBarPath(size);

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class _NotchedNavBarPainter extends CustomPainter {
  final Color backgroundColor;
  final Color borderColor;

  _NotchedNavBarPainter({
    required this.backgroundColor,
    required this.borderColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final path = _buildNotchedNavBarPath(size);

    final shadowPath = path.shift(const Offset(4, 4));
    canvas.drawPath(shadowPath, Paint()..color = Colors.black);

    canvas.drawShadow(
      path.shift(const Offset(0, 6)),
      Colors.black.withOpacity(0.15),
      16,
      false,
    );

    canvas.drawPath(path, Paint()..color = backgroundColor);

    canvas.drawPath(
      path,
      Paint()
        ..color = borderColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  @override
  bool shouldRepaint(covariant _NotchedNavBarPainter oldDelegate) =>
      oldDelegate.backgroundColor != backgroundColor ||
      oldDelegate.borderColor != borderColor;
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    if (url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov")) {
      return Container(
        color: Colors.black,
        child: const Center(
          child: Icon(Icons.videocam_off, color: Colors.grey, size: 50),
        ),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: const Color(0xFF1C1C1E),
        child: const Center(
          child: Icon(Icons.broken_image, color: Colors.grey),
        ),
      ),
    );
  }
}

// ── Quick Action gaya Justin Official ──────────────────────────────────────

class _JustinActionTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _JustinActionTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A22).withOpacity(0.92),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  color: Colors.white.withOpacity(0.35), size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

class _JustinWideTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _JustinWideTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A22).withOpacity(0.92),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 11.5,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  color: Colors.white.withOpacity(0.35), size: 22),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Bottom nav: background nav.jpg, aktif merah tanpa border abu ───────────

class _XeonNavBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _XeonNavBar({
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    return SizedBox(
      height: 72 + bottom,
      child: Padding(
        padding: EdgeInsets.fromLTRB(12, 0, 12, 8 + bottom * 0.25),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                'assets/images/nav.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Container(color: const Color(0xFF121218)),
              ),
              Container(color: Colors.black.withOpacity(0.42)),
              Row(
                children: [
                  _item(0, Icons.home_rounded, 'Home'),
                  _item(1, FontAwesomeIcons.whatsapp, 'WA'),
                  _item(2, Icons.notifications_rounded, 'Info'),
                  _item(3, Icons.build_circle, 'Tools'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _item(int index, IconData icon, String label) {
    final selected = currentIndex == index;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onTap(index),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: selected ? 24 : 22,
              color: selected
                  ? const Color(0xFFE53935)
                  : Colors.white.withOpacity(0.75),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: selected
                    ? const Color(0xFFE53935)
                    : Colors.white.withOpacity(0.65),
                fontSize: 10,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}