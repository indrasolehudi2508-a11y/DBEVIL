// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'login_page.dart';
import 'tap.dart';

const Color _lAccent = Color(0xFFE53935);
const Color _lText = Color(0xFFF5F5F7);
const Color _lTextSub = Color(0xFFB8B8C8);
const String _lFont = "Orbitron";

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  late AnimationController _entryController;

  @override
  void initState() {
    super.initState();
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();

    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      final c = VideoPlayerController.asset('assets/videos/bg_landing.mp4');
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      await c.play();
      // pastikan tetap play setelah frame pertama
      c.addListener(() {
        if (!mounted) return;
        if (c.value.isInitialized && !c.value.isPlaying) {
          c.play();
        }
      });
      if (!mounted) {
        c.dispose();
        return;
      }
      setState(() {
        _videoController = c;
        _videoReady = true;
      });
    } catch (_) {
      if (mounted) setState(() => _videoReady = false);
    }
  }

  @override
  void dispose() {
    _entryController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    try {
      final launched =
          await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak bisa membuka link')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _showPriceList() {
    final categories = <Map<String, dynamic>>[
      {
        "role": "Member",
        "icon": Icons.person,
        "color": const Color(0xFFFF8A80),
        "prices": [
          {"duration": "Permanent", "price": "25k"},
        ],
      },
      {
        "role": "VIP",
        "icon": Icons.shield,
        "color": const Color(0xFFFF8A80),
        "prices": [
          {"duration": "Permanent", "price": "50k"},
        ],
        "badge": "Unlock Sender Global!!",
      },
      {
        "role": "Reseller",
        "icon": Icons.storefront,
        "color": const Color(0xFFFF5252),
        "prices": [
          {"duration": "Permanent", "price": "40k"},
        ],
      },
      {
        "role": "Admin",
        "icon": Icons.admin_panel_settings,
        "color": const Color(0xFFE53935),
        "prices": [
          {"duration": "Permanent", "price": "60k"},
        ],
      },
      {
        "role": "Partner",
        "icon": Icons.handshake,
        "color": const Color(0xFFC62828),
        "prices": [
          {"duration": "Permanent", "price": "80k"},
        ],
      },
      {
        "role": "Moderator",
        "icon": Icons.security,
        "color": const Color(0xFFB71C1C),
        "prices": [
          {"duration": "Permanent", "price": "100k"},
        ],
      },
      {
        "role": "Owner",
        "icon": Icons.star,
        "color": const Color(0xFFFFB74D),
        "prices": [
          {"duration": "Permanent", "price": "150k"},
        ],
        "badge": "Unlock Sender Global!!",
      },
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(ctx).size.height * 0.85,
          ),
          decoration: const BoxDecoration(
            color: Color(0xFF0A0A0F),
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            border: Border(top: BorderSide(color: Colors.black, width: 1.5)),
          ),
          child: Column(
            children: [
              const SizedBox(height: 12),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  "LIST HARGA AKSES",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: _lFont,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  children: [
                    for (final cat in categories)
                      _priceCategoryCard(
                        role: cat["role"] as String,
                        icon: cat["icon"] as IconData,
                        color: cat["color"] as Color,
                        prices:
                            (cat["prices"] as List).cast<Map<String, String>>(),
                        badge: cat["badge"] as String?,
                      ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _lAccent,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: const BorderSide(
                                color: Colors.black, width: 1.5),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(ctx);
                          _openUrl("https://t.me/xeonredupbot");
                        },
                        icon: const Icon(FontAwesomeIcons.telegram, size: 18),
                        label: const Text(
                          "Hubungi untuk Beli",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _priceCategoryCard({
    required String role,
    required IconData icon,
    required Color color,
    required List<Map<String, String>> prices,
    String? badge,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.55), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.18),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.22),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  role,
                  style: TextStyle(
                    color: color,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: _lFont,
                  ),
                ),
              ),
              if (badge != null && badge.isNotEmpty)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: color.withOpacity(0.85), width: 1),
                  ),
                  child: Text(
                    badge,
                    style: TextStyle(
                      color: color,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          ...prices.map(
            (price) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    price["duration"] ?? "",
                    style: TextStyle(
                      color: color.withOpacity(0.85),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.20),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: color.withOpacity(0.45)),
                    ),
                    child: Text(
                      "Rp ${price["price"]}",
                      style: TextStyle(
                        color: color,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _featureChip(IconData icon, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.07),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
        ),
        child: Column(
          children: [
            Icon(icon, color: _lText, size: 20),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: _lText.withOpacity(0.85),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _socialBtn({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.07),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _lText, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: _lText.withOpacity(0.9),
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: const Color(0xFF0A0A0F),
        body: Stack(
          fit: StackFit.expand,
          children: [
            // ── Video background ───────────────────────────────────────
            if (_videoReady && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              Container(color: const Color(0xFF0A0A0F)),

            // ── Blur + dark overlay (seperti foto) ─────────────────────
            BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.55),
                      Colors.black.withOpacity(0.72),
                      Colors.black.withOpacity(0.88),
                    ],
                  ),
                ),
              ),
            ),

            // ── Content ────────────────────────────────────────────────
            SafeArea(
              child: FadeTransition(
                opacity: _entryController,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    children: [
                      const Spacer(flex: 2),

                      // Logo 16:9 — assets/images/anjay.png
                      ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: AspectRatio(
                          aspectRatio: 16 / 9,
                          child: Image.asset(
                            'assets/images/anjay.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: Colors.white.withOpacity(0.08),
                              alignment: Alignment.center,
                              child: const Icon(Icons.image,
                                  color: Colors.white38, size: 40),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 28),

                      const Text(
                        'WELCOME BACK',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _lText,
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.5,
                          fontFamily: _lFont,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Premium tools for your digital needs.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _lTextSub.withOpacity(0.9),
                          fontSize: 14,
                          height: 1.4,
                        ),
                      ),

                      const SizedBox(height: 28),

                      // Feature chips
                      Row(
                        children: [
                          _featureChip(Icons.bolt_rounded, 'Fast'),
                          const SizedBox(width: 10),
                          _featureChip(Icons.shield_outlined, 'Safe'),
                          const SizedBox(width: 10),
                          _featureChip(Icons.headset_mic_outlined, '24/7'),
                        ],
                      ),

                      const SizedBox(height: 14),

                      // Social
                      Row(
                        children: [
                          _socialBtn(
                            icon: FontAwesomeIcons.telegram,
                            label: 'Telegram',
                            onTap: () =>
                                _openUrl('https://t.me/XeronComunity'),
                          ),
                          const SizedBox(width: 10),
                          _socialBtn(
                            icon: FontAwesomeIcons.tiktok,
                            label: 'TikTok',
                            onTap: () => _openUrl(
                                'https://www.tiktok.com/@aryanylgibobo'),
                          ),
                        ],
                      ),

                      // Langsung di bawah Telegram / TikTok
                      const SizedBox(height: 16),

                      // Check Pricing
                      GestureDetector(
                        onTap: _showPriceList,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.14)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.shopping_bag_outlined,
                                  color: _lText.withOpacity(0.9), size: 20),
                              const SizedBox(width: 10),
                              Text(
                                'Check Pricing',
                                style: TextStyle(
                                  color: _lText.withOpacity(0.95),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      // Sign In Now
                      GestureDetector(
                        onTap: () => Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const LoginPage()),
                        ),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Sign In Now',
                                style: TextStyle(
                                  color: Color(0xFF121218),
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              SizedBox(width: 8),
                              Icon(Icons.arrow_forward_rounded,
                                  color: Color(0xFF121218), size: 20),
                            ],
                          ),
                        ),
                      ),

                      const Spacer(flex: 2),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
