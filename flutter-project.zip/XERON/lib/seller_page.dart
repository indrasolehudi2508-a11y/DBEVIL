import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'srv.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  // ===== TEMA CYBER (samain dashboard) =====
  final Color bgDark       = const Color(0xFF0A0A0F); // background utama
  final Color cardBg       = const Color(0xFF14141A); // kartu
  final Color inputBg      = const Color(0xFF1A1A22); // input
  final Color primaryWhite = const Color(0xFFF5F5F7);
  final Color textGrey     = const Color(0xFFB0B0B8);

  // Accent seller: NEON YELLOW/GOLD (signature)
  final Color accentPurple = const Color(0xFFFFD600);
  final Color neonYellow   = const Color(0xFFFFD600);
  final Color neonCyan     = const Color(0xFF00E5FF);
  final Color neonGreen    = const Color(0xFF00E676);
  final Color neonRed      = const Color(0xFFFF1744);
  final Color neonOrange   = const Color(0xFFFF6D00);

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          'http://console.jhonaleystore.id:2899/listUsers?key=${widget.keyToken}'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          'http://console.jhonaleystore.id:2899/deleteUser?key=${widget.keyToken}&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          'http://console.jhonaleystore.id:2899/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun MEMBER berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _fetchUsers();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) {
          msg += " (Max 30 hari untuk Reseller)";
        }
        _alert("Gagal", msg);
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
          'http://console.jhonaleystore.id:2899/editUser?key=${widget.keyToken}&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ================= ALERT CYBER =================
  void _alert(String title, String message) {
    final isError = title.toLowerCase().contains('error') ||
        title.toLowerCase().contains('gagal') ||
        title.toLowerCase().contains('peringatan');
    final accent = isError ? neonRed : neonGreen;
    final icon = isError
        ? Icons.error_outline_rounded
        : Icons.check_circle_outline_rounded;

    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 26, 22, 20),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: accent.withOpacity(0.55), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.28),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withOpacity(0.15),
                  border:
                      Border.all(color: accent.withOpacity(0.6), width: 1.5),
                  boxShadow: [
                    BoxShadow(color: accent.withOpacity(0.4), blurRadius: 18),
                  ],
                ),
                child: Icon(icon, color: accent, size: 34),
              ),
              const SizedBox(height: 16),
              Text(
                title.toUpperCase(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.78),
                  fontSize: 13,
                  height: 1.45,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 46,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                    shadowColor: accent.withOpacity(0.7),
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.8,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  // ================================================

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        cursorColor: neonYellow,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: textGrey, fontSize: 13),
          prefixIcon: Icon(icon, color: neonYellow, size: 20),
          filled: true,
          fillColor: inputBg,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.white.withOpacity(0.08)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: neonYellow, width: 1.5),
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(24),
              border:
                  Border.all(color: neonGreen.withOpacity(0.45), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: neonGreen.withOpacity(0.25),
                  blurRadius: 24,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: neonGreen.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: neonGreen.withOpacity(0.6), width: 1.2),
                      boxShadow: [
                        BoxShadow(
                            color: neonGreen.withOpacity(0.4),
                            blurRadius: 16),
                      ],
                    ),
                    child: Icon(FontAwesomeIcons.userPlus,
                        color: neonGreen, size: 30),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "CREATE MEMBER",
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildInput(
                      label: "Username Baru",
                      controller: createUsernameController,
                      icon: FontAwesomeIcons.user),
                  _buildInput(
                      label: "Password",
                      controller: createPasswordController,
                      icon: FontAwesomeIcons.lock),
                  _buildInput(
                      label: "Durasi (Max 30 Hari)",
                      controller: createDayController,
                      icon: FontAwesomeIcons.calendarDay,
                      type: TextInputType.number),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _createAccount();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: neonGreen,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                        shadowColor: neonGreen.withOpacity(0.7),
                      ),
                      child: const Text(
                        "CREATE",
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.8,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showExtendDurationPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(24),
              border:
                  Border.all(color: neonCyan.withOpacity(0.45), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.25),
                  blurRadius: 24,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: neonCyan.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: neonCyan.withOpacity(0.6), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: neonCyan.withOpacity(0.4), blurRadius: 16),
                    ],
                  ),
                  child:
                      Icon(FontAwesomeIcons.clock, color: neonCyan, size: 30),
                ),
                const SizedBox(height: 16),
                Text(
                  "ADD DURATION",
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 24),
                _buildInput(
                    label: "Username Target",
                    controller: editUsernameController,
                    icon: FontAwesomeIcons.userEdit),
                _buildInput(
                    label: "Tambah Hari (Max 30)",
                    controller: editDayController,
                    icon: FontAwesomeIcons.calendarPlus,
                    type: TextInputType.number),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _editUser();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: neonCyan,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      elevation: 0,
                      shadowColor: neonCyan.withOpacity(0.7),
                    ),
                    child: const Text(
                      "ADD DAYS",
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: neonRed.withOpacity(0.5), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: neonRed.withOpacity(0.28),
                  blurRadius: 24,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: neonRed.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: neonRed.withOpacity(0.6), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                          color: neonRed.withOpacity(0.45), blurRadius: 16),
                    ],
                  ),
                  child: Icon(FontAwesomeIcons.userSlash,
                      color: neonRed, size: 30),
                ),
                const SizedBox(height: 16),
                Text(
                  "DELETE ACCOUNT",
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 24),
                _buildInput(
                    label: "Username Target",
                    controller: deleteController,
                    icon: FontAwesomeIcons.user),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _deleteUser();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: neonRed,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      elevation: 0,
                      shadowColor: neonRed.withOpacity(0.7),
                    ),
                    child: const Text(
                      "DELETE",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopButton({
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          height: 108,
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: color.withOpacity(0.5), width: 1.4),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.22),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.15),
                  border:
                      Border.all(color: color.withOpacity(0.55), width: 1.2),
                  boxShadow: [
                    BoxShadow(color: color.withOpacity(0.4), blurRadius: 12),
                  ],
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.0,
                  height: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: neonYellow.withOpacity(0.35), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: neonYellow.withOpacity(0.15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: neonYellow.withOpacity(0.15),
              shape: BoxShape.circle,
              border:
                  Border.all(color: neonYellow.withOpacity(0.55), width: 1.2),
              boxShadow: [
                BoxShadow(color: neonYellow.withOpacity(0.4), blurRadius: 12),
              ],
            ),
            child: Icon(Icons.person, color: neonYellow, size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: neonYellow.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(
                            color: neonYellow.withOpacity(0.5), width: 0.8),
                      ),
                      child: Text(
                        user['role'].toString().toUpperCase(),
                        style: TextStyle(
                          color: neonYellow,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.6,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        "EXP: ${user['expiredDate']}",
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: textGrey,
                          fontSize: 11,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, color: neonRed),
            style: IconButton.styleFrom(
              backgroundColor: neonRed.withOpacity(0.10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: BorderSide(color: neonRed.withOpacity(0.45), width: 1),
              ),
            ),
            onPressed: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return InkWell(
          onTap: () => setState(() => currentPage = page),
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected
                  ? neonYellow.withOpacity(0.18)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isSelected
                    ? neonYellow
                    : Colors.white.withOpacity(0.12),
                width: isSelected ? 1.4 : 1,
              ),
              boxShadow: isSelected
                  ? [
                      BoxShadow(
                          color: neonYellow.withOpacity(0.4), blurRadius: 10),
                    ]
                  : null,
            ),
            child: Text(
              "$page",
              style: TextStyle(
                color: isSelected ? neonYellow : Colors.white70,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: isLoading && fullUserList.isEmpty
            ? Center(child: CircularProgressIndicator(color: neonYellow))
            : SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: neonYellow.withOpacity(0.15),
                            border: Border.all(
                                color: neonYellow.withOpacity(0.55),
                                width: 1.4),
                            boxShadow: [
                              BoxShadow(
                                  color: neonYellow.withOpacity(0.45),
                                  blurRadius: 14),
                            ],
                          ),
                          child: Icon(Icons.storefront,
                              color: neonYellow, size: 24),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "SELLER PANEL",
                              style: TextStyle(
                                color: primaryWhite,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.2,
                              ),
                            ),
                            Text(
                              "MANAGEMENT DASHBOARD",
                              style: TextStyle(
                                color: textGrey,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 1.0,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // 3 Buttons Row
                    Row(
                      children: [
                        _buildTopButton(
                            title: "BUAT\nAKUN",
                            icon: FontAwesomeIcons.userPlus,
                            color: neonGreen,
                            onTap: _showCreateAccountPopup),
                        const SizedBox(width: 12),
                        _buildTopButton(
                            title: "ADD\nDURASI",
                            icon: FontAwesomeIcons.clock,
                            color: neonCyan,
                            onTap: _showExtendDurationPopup),
                        const SizedBox(width: 12),
                        _buildTopButton(
                            title: "HAPUS\nAKUN",
                            icon: FontAwesomeIcons.userSlash,
                            color: neonRed,
                            onTap: _showDeleteAccountPopup),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // User List Section
                    Row(
                      children: [
                        Container(
                          width: 4,
                          height: 20,
                          decoration: BoxDecoration(
                            color: neonYellow,
                            borderRadius: BorderRadius.circular(2),
                            boxShadow: [
                              BoxShadow(
                                  color: neonYellow.withOpacity(0.7),
                                  blurRadius: 8),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "MEMBER DIRECTORY",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),

                    if (isLoading && fullUserList.isNotEmpty)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child:
                              CircularProgressIndicator(color: neonYellow),
                        ),
                      ),

                    if (filteredList.isEmpty && !isLoading)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Text(
                            "Belum ada member.",
                            style: TextStyle(
                                color: textGrey,
                                fontFamily: 'ShareTechMono'),
                          ),
                        ),
                      ),

                    ..._getCurrentPageData()
                        .map((u) => _buildUserItem(u))
                        .toList(),

                    const SizedBox(height: 20),
                    Center(child: _buildPagination()),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
      ),
    );
  }
}