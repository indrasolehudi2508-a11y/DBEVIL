/// ============================================================
///  SERVER CONFIG — ubah domain HANYA di file ini
/// ============================================================
/// Semua page yang butuh base URL / WebSocket ambil dari sini.
/// Contoh ganti domain:
///   static const String baseUrl = 'http://domain-baru.com:PORT';
/// ============================================================

class Srv {
  /// Domain utama server Xeron (HTTP/API)
  static const String baseUrl = 'http://console.jhonaleystore.id:2192';

  /// Domain manage server / activity (opsional, terpisah)
  static const String manageServerUrl =
      'http://console.jhonaleystore.id:2192';

  /// Domain test-function (opsional)
  static const String tesFuncUrl =
      'http://console.jhonaleystore.id:2192';

  /// WebSocket base (otomatis dari baseUrl: http→ws, https→wss)
  static String get wsUrl {
    final u = Uri.parse(baseUrl);
    final scheme = (u.scheme == 'https') ? 'wss' : 'ws';
    final port = u.hasPort ? ':${u.port}' : '';
    return '$scheme://${u.host}$port';
  }

  /// WebSocket chat
  static String get chatWsUrl => '$wsUrl/chat';
}
