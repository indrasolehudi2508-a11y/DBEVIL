package com.arya.xeron;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
