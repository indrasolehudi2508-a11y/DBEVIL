import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'dart:math';
import 'dart:async';

import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;
  late Animation<double> pulseAnimation;
  late VideoPlayerController _videoController;

  // NEON CYBERPUNK PREMIUM THEME
  final Color _primaryColor = const Color(0xFF00FF88);
  final Color _secondaryColor = const Color(0xFF00D4FF);
  final Color _accentColor = const Color(0xFF8844FF);
  final Color _darkBg = const Color(0xFF0A0A1A);
  final Color _darkerBg = const Color(0xFF05050A);
  final Color _surfaceColor = const Color(0xFF12121F);
  final Color _cardColor = const Color(0xFF0E0E18);
  final Color _glowColor1 = const Color(0xFF00FF88);
  final Color _glowColor2 = const Color(0xFF00D4FF);
  final Color _glowColor3 = const Color(0xFF8844FF);

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    
    fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    
    slideAnimation = Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    
    pulseAnimation = Tween<double>(begin: 1, end: 1.05).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeInOutSine));
    
    _controller.forward();

    _videoController = VideoPlayerController.asset('assets/videos/animek.mp4')
      ..initialize().then((_) {
        _videoController.setLooping(true);
        _videoController.setVolume(0.0);
        _videoController.play();
        if (mounted) setState(() {});
      }).catchError((error) {
        debugPrint("Video initialization error: $error");
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    _videoController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      debugPrint("Error launching $uri");
    }
  }

  Widget _buildAnimatedBackground() {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.5),
          radius: 1.8,
          colors: [
            _glowColor1.withOpacity(0.08),
            _glowColor2.withOpacity(0.04),
            _darkBg,
            _darkerBg,
          ],
        ),
      ),
      child: Stack(
        children: [
          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: Opacity(
                opacity: 0.04,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              ),
            ),
          ...List.generate(3, (index) {
            return Positioned(
              top: Random().nextDouble() * MediaQuery.of(context).size.height,
              left: Random().nextDouble() * MediaQuery.of(context).size.width,
              child: Container(
                width: 2,
                height: 2,
                decoration: BoxDecoration(
                  color: _glowColor1.withOpacity(0.3),
                  shape: BoxShape.circle,
                ),
              ),
            );
          }),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.85),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkerBg,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: FadeTransition(
              opacity: fadeAnimation,
              child: SlideTransition(
                position: slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      
                      // Logo / Title utama
                      Column(
                        children: [
                          ShaderMask(
                            shaderCallback: (bounds) => LinearGradient(
                              colors: [_glowColor1, _glowColor3, _glowColor2],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ).createShader(bounds),
                            child: Text(
                              "RootX",
                              style: TextStyle(
                                fontSize: 48,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 6,
                                fontFamily: 'Rajdhani',
                                color: Colors.white,
                                shadows: [
                                  Shadow(color: _glowColor1.withOpacity(0.6), blurRadius: 25),
                                  Shadow(color: _glowColor2.withOpacity(0.3), blurRadius: 15),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [_glowColor1.withOpacity(0.2), _glowColor2.withOpacity(0.1)],
                              ),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              "OFFICIAL",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 8,
                                fontFamily: 'Rajdhani',
                                color: _glowColor2.withOpacity(0.9),
                              ),
                            ),
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 50),
                      
                      // Social Media Icons
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildSocialIcon(
                            icon: FontAwesomeIcons.tiktok,
                            url: "https://tiktok.com/@aprozius",
                            color: _glowColor1,
                          ),
                          const SizedBox(width: 40),
                          _buildSocialIcon(
                            icon: FontAwesomeIcons.telegram,
                            url: "https://t.me/aprozius",
                            color: _glowColor2,
                          ),
                          const SizedBox(width: 40),
                          _buildSocialIcon(
                            icon: FontAwesomeIcons.github,
                            url: "https://github.com/aprozius",
                            color: _glowColor3,
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 40),
                      
                      // Divider garis
                      AnimatedContainer(
                        duration: const Duration(seconds: 2),
                        width: 180,
                        height: 1.5,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [_glowColor1.withOpacity(0.1), _glowColor1, _glowColor1.withOpacity(0.1)],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 30),
                      
                      // Owner credit
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                            colors: [
                              _glowColor1.withOpacity(0.05),
                              _glowColor2.withOpacity(0.02),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: _glowColor1.withOpacity(0.1), width: 0.5),
                        ),
                        child: Column(
                          children: [
                            Text(
                              "WELCOME BACK ROOTX",
                              style: TextStyle(
                                color: _glowColor2.withOpacity(0.4),
                                fontSize: 10,
                                letterSpacing: 3,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "RootX",
                              style: TextStyle(
                                color: _glowColor1.withOpacity(0.9),
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 3,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "Developer : @mizukisnjii • team: @rootxoffc",
                              style: TextStyle(
                                color: _glowColor3.withOpacity(0.4),
                                fontSize: 9,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                      
                      // Kata Sambutan Card
                      Container(
                        padding: const EdgeInsets.all(28),
                        decoration: BoxDecoration(
                          color: _cardColor.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: _glowColor1.withOpacity(0.2), width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: _glowColor1.withOpacity(0.1),
                              blurRadius: 30,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 4,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [_glowColor1, _glowColor2],
                                    ),
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  "KATA SAMBUTAN",
                                  style: TextStyle(
                                    color: _glowColor1,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 4,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 20),
                            Text(
                              "Welcome To RootX.",
                              style: TextStyle(
                                color: _glowColor1.withOpacity(0.9),
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              "We are an application with a mobile phone monitoring system at any distance.",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.7),
                                fontSize: 14,
                                height: 1.5,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "Tetap terhubung, tetap aman, dan bersiaplah menjelajahi ekosistem digital kami tanpa batas. Silakan melakukan login untuk mengakses seluruh fitur eksekutif yang telah dipersiapkan.",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 12,
                                height: 1.5,
                                fontFamily: 'Rajdhani',
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 40),
                      
                      // Tombol Login dengan efek pulse
                      GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const LoginPage(),
                            settings: const RouteSettings(name: '/login'),
                          ),
                        ),
                        child: AnimatedBuilder(
                          animation: pulseAnimation,
                          builder: (context, _) {
                            return Transform.scale(
                              scale: pulseAnimation.value,
                              child: Container(
                                width: double.infinity,
                                height: 60,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [_glowColor1, _glowColor2],
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _glowColor1.withOpacity(0.4),
                                      blurRadius: 25,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                                child: Center(
                                  child: Text(
                                    "LOGIN",
                                    style: TextStyle(
                                      color: _darkerBg,
                                      fontWeight: FontWeight.w900,
                                      fontSize: 15,
                                      letterSpacing: 4,
                                      fontFamily: 'Rajdhani',
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      
                      const SizedBox(height: 16),
                      
                      // Tombol Customer Service
                      GestureDetector(
                        onTap: () => _openUrl("https://t.me/aprozius_cs"),
                        child: Container(
                          width: double.infinity,
                          height: 52,
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _glowColor2.withOpacity(0.4), width: 1.5),
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                FaIcon(
                                  FontAwesomeIcons.headset,
                                  color: _glowColor2.withOpacity(0.8),
                                  size: 16,
                                ),
                                const SizedBox(width: 12),
                                Text(
                                  "CUSTOMER SERVICE",
                                  style: TextStyle(
                                    color: _glowColor2.withOpacity(0.8),
                                    fontWeight: FontWeight.w800,
                                    fontSize: 13,
                                    letterSpacing: 3,
                                    fontFamily: 'Rajdhani',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 50),
                      
                      // Footer
                      Column(
                        children: [
                          Container(
                            width: 120,
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [Colors.white.withOpacity(0), Colors.white.withOpacity(0.1), Colors.white.withOpacity(0)],
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            "© 2027 RootX Official",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.08),
                              fontSize: 10,
                              letterSpacing: 3,
                              fontFamily: 'Rajdhani',
                            ),
                          ),
                        ],
                      ),
                      
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===== PERBAIKAN DI SINI =====
  // Ubah tipe parameter icon dari IconData menjadi FaIconData
  Widget _buildSocialIcon({
    required FaIconData icon,   // <-- Ini perbaikannya
    required String url,
    required Color color,
  }) {
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        width: 55,
        height: 55,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _surfaceColor,
              _surfaceColor.withOpacity(0.5),
            ],
          ),
          border: Border.all(color: color.withOpacity(0.4), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.2),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Center(
          child: FaIcon(
            icon,
            color: color,
            size: 24,
          ),
        ),
      ),
    );
  }
}