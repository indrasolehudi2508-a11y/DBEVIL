import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage>
    with SingleTickerProviderStateMixin {
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.black54;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  // --- PALETTE WARNA ASLI (TIDAK DIUBAH) ---
  final Color bgDark = const Color(0xFFF3E9D2);
  final Color cardBg = const Color(0xFFFFFDF5);
  final Color borderLight = const Color(0xFFFFD43B);
  final Color textMain = Colors.black87;
  final Color textSub = Colors.black54;

  // Data Aturan (Sama Persis)
  final List<Map<String, dynamic>> rulesList = [
    {
      "title": "NO ACCOUNT BARTERING",
      "icon": Icons.swap_horizontal_circle_outlined,
      "desc": "Akun eksklusif Parapam tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun. Pelanggaran log akan terpantau."
    },
    {
      "title": "STRICTLY PERSONAL USE",
      "icon": Icons.person_off_outlined,
      "desc": "Setiap akun terenkripsi untuk satu pengguna dan hanya boleh diakses oleh pemilik perangkat yang mendaftar (terikat Device ID)."
    },
    {
      "title": "RESELLING PROHIBITED",
      "icon": Icons.money_off_csred_outlined,
      "desc": "Member reguler dilarang memperjualbelikan akun. Akses penjualan eksklusif milik role berwenang (Partner, Owner, atau Reseller)."
    },
    {
      "title": "ILLEGAL DURATION SALES",
      "icon": Icons.timer_off_outlined,
      "desc": "Sangat dilarang membagi atau menjual akses eceran (harian, mingguan, trial) yang mengelabui skema periode resmi."
    },
    {
      "title": "PRICE DUMPING BAN",
      "icon": Icons.trending_down_rounded,
      "desc": "Dilarang keras merusak standar harga pasar (banting harga) di bawah kesepakatan jaminan keamanan platform kami."
    },
  ];

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _fetchServerInfo();
    _startApiPingLoop();
  }

  void _initAnimations() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http
          .get(Uri.parse('http://public.queen-official.com:2302/getServerInfo?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 5));
      if (mounted) setState(() => isLoading = false);
    } catch (_) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkApiPing());
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse('http://public.queen-official.com:2302/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final duration = DateTime.now().difference(start).inMilliseconds;

      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = const Color(0xFF00E676);
          } else if (duration < 500) {
            apiStatusColor = const Color(0xFFFFD54F);
          } else {
            apiStatusColor = const Color(0xFFA5B4FC);
          }
          apiStatusText = "Sys.Online :: ${duration}ms";
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = const Color(0xFFD32F2F);
          apiStatusText = "Sys.Offline :: DEST";
        });
      }
    }
  }

  // ============================================================
  //  DESAIN BARU: GLASSMORPHISM + GRADIENT + ANIMASI
  // ============================================================

  // 1. Header Status dengan efek glow & gradient
  Widget _buildStatusHeader() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SlideTransition(
        position: _slideAnim,
        child: Container(
          margin: const EdgeInsets.only(bottom: 36, top: 16),
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                cardBg.withOpacity(0.9),
                cardBg.withOpacity(0.7),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: Colors.white.withOpacity(0.4),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.18),
                blurRadius: 0,
                offset: const Offset(6, 6),
              ),
              BoxShadow(
                color: borderLight,
                blurRadius: 0,
                offset: const Offset(6, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              // Ikon status dengan animasi glow
              AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  return Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          apiStatusColor.withOpacity(0.4),
                          apiStatusColor.withOpacity(0.1),
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
              offset: const Offset(6, 6),
                          color: apiStatusColor.withOpacity(0.3),
                          blurRadius: 0,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Icon(
                      isApiOnline ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
                      color: isApiOnline ? const Color(0xFF00E676) : const Color(0xFFD32F2F),
                      size: 28,
                    ),
                  );
                },
              ),
              const SizedBox(width: 18),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "SERVER STATUS",
                      style: TextStyle(
                        color: textSub.withOpacity(0.7),
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 2.0,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      apiStatusText.toUpperCase(),
                      style: TextStyle(
                        color: apiStatusColor == Colors.black54 ? textMain : apiStatusColor,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      width: 120,
                      height: 4,
                      decoration: BoxDecoration(
                        color: textSub.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: isApiOnline ? (apiPingMs < 200 ? 1.0 : apiPingMs < 500 ? 0.7 : 0.4) : 0.1,
                        child: Container(
                          decoration: BoxDecoration(
                            color: apiStatusColor,
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // Badge kecil
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: isApiOnline ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isApiOnline ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                  ),
                ),
                child: Text(
                  isApiOnline ? "ONLINE" : "OFFLINE",
                  style: TextStyle(
                    color: isApiOnline ? Colors.green : Colors.red,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 2. Kartu Aturan dengan desain cyber/futuristik
  Widget _buildRuleCard(int index, Map<String, dynamic> rule) {
    return FadeTransition(
      opacity: CurvedAnimation(
        parent: _controller,
        curve: Interval(index * 0.15, 1.0, curve: Curves.easeOut),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: cardBg.withOpacity(0.85),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: borderLight,
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: () {
              // Bisa expand jika ingin, tapi kita pakai ExpansionTile biasa
            },
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Icon container dengan gradient border
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          borderLight,
                          borderLight,
                        ],
                      ),
                      border: Border.all(
                        color: borderLight,
                        width: 1.5,
                      ),
                    ),
                    child: Icon(
                      rule['icon'],
                      color: borderLight,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          rule['title'],
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1.0,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          rule['desc'],
                          style: TextStyle(
                            color: textSub,
                            fontSize: 13,
                            height: 1.5,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(height: 10),
                        // Garis aksen di bawah
                        Container(
                          height: 2,
                          width: 60,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                borderLight,
                                borderLight,
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.chevron_right_rounded,
                    color: textSub.withOpacity(0.3),
                    size: 20,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // 3. Penalty Box dengan desain "Danger Zone"
  Widget _buildPenaltyBox() {
    return FadeTransition(
      opacity: CurvedAnimation(
        parent: _controller,
        curve: Interval(0.6, 1.0, curve: Curves.easeOut),
      ),
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 8, bottom: 24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFFD32F2F).withOpacity(0.15),
              const Color(0xFFD32F2F).withOpacity(0.03),
            ],
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: const Color(0xFFD32F2F).withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFD32F2F).withOpacity(0.08),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.gpp_bad_rounded, color: const Color(0xFFEF5350), size: 28),
                const SizedBox(width: 12),
                const Text(
                  "VIOLATION PENALTY",
                  style: TextStyle(
                    color: Color(0xFFEF5350),
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text(
              "Jika pengguna terdeteksi melanggar salah satu protokol kerahasiaan & aturan di atas secara sengaja:",
              style: TextStyle(
                color: Colors.black87,
                fontSize: 13,
                fontFamily: 'ShareTechMono',
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFD32F2F).withOpacity(0.1),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: const Color(0xFFEF5350).withOpacity(0.3),
                ),
              ),
              child: const Text(
                "AKUN DIHAPUS PERMANEN",
                style: TextStyle(
                  color: Colors.black87,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "TIDAK ADA PENGEMBALIAN SALDO ATAU KOMPENSASI.",
              style: TextStyle(
                color: const Color(0xFFEF5350).withOpacity(0.8),
                fontSize: 11,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // 4. Footer dengan desain minimalis
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 40, top: 8),
      child: Center(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: borderLight,
                  width: 1,
                ),
                color: cardBg.withOpacity(0.5),
              ),
              child: const Icon(
                Icons.shield_moon_rounded,
                color: Colors.black26,
                size: 30,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Peraturan ini dibuat semata-mata untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem server Parapam.",
              style: TextStyle(
                color: Colors.black45,
                fontSize: 12,
                fontStyle: FontStyle.italic,
                fontFamily: 'ShareTechMono',
                height: 1.6,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Container(
              height: 3,
              width: 50,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [borderLight, borderLight],
                ),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              "© 2027 PARAPAM V4.0",
              style: TextStyle(
                color: textSub.withOpacity(0.3),
                fontSize: 10,
                fontFamily: 'ShareTechMono',
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  MAIN BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: bgDark,
        body: WintrixUiFrame(
        accent: borderLight,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                width: 48,
                height: 48,
                child: CircularProgressIndicator(
                  color: Color(0xFFFFD43B),
                  strokeWidth: 3,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                "LOADING INFO...",
                style: TextStyle(
                  color: textSub.withOpacity(0.5),
                  fontFamily: 'ShareTechMono',
                  fontSize: 12,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
        ),
      ),
      );
    }

    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // Background decorative blobs
          Positioned(
            top: -80,
            right: -60,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: borderLight,
              ),
            ),
          ),
          Positioned(
            bottom: -100,
            left: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: borderLight,
              ),
            ),
          ),
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverAppBar(
                  backgroundColor: bgDark,
                  elevation: 0,
                  pinned: true,
                  automaticallyImplyLeading: false,
                  expandedHeight: 80,
                  flexibleSpace: FlexibleSpaceBar(
                    titlePadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    title: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: borderLight,
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: const Icon(
                            Icons.security_rounded,
                            color: Color(0xFFFFD43B),
                            size: 24,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "EULA & INFO",
                              style: TextStyle(
                                color: Colors.black87,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.0,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              "End-User License Agreement",
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    centerTitle: false,
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      _buildStatusHeader(),
                      // Section label
                      Row(
                        children: [
                          Container(
                            width: 4,
                            height: 18,
                            decoration: BoxDecoration(
                              color: borderLight,
                              borderRadius: BorderRadius.circular(18),
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "USER PROTOCOLS",
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      ...rulesList.asMap().entries.map((e) {
                        return _buildRuleCard(e.key, e.value);
                      }).toList(),
                      const SizedBox(height: 8),
                      _buildPenaltyBox(),
                      _buildFooter(),
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


/// Visual-only frame for WINTRIX. It deliberately reuses the app's existing
/// palette and does not alter child state, navigation, networking, or actions.
class WintrixUiFrame extends StatelessWidget {
  final Widget child;
  final Color accent;
  final bool showGrid;
  final EdgeInsetsGeometry padding;

  const WintrixUiFrame({
    super.key,
    required this.child,
    required this.accent,
    this.showGrid = true,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        IgnorePointer(
          child: CustomPaint(
            painter: _WintrixBackdropPainter(accent: accent, showGrid: showGrid),
          ),
        ),
        Padding(padding: padding, child: child),
      ],
    );
  }
}

class _WintrixBackdropPainter extends CustomPainter {
  final Color accent;
  final bool showGrid;

  const _WintrixBackdropPainter({required this.accent, required this.showGrid});

  @override
  void paint(Canvas canvas, Size size) {
    final shortest = (size.width < size.height ? size.width : size.height);

    final glow = Paint()
      ..shader = RadialGradient(
        center: const Alignment(0.88, -0.82),
        radius: 1.05,
        colors: [
          accent.withOpacity(0.11),
          accent.withOpacity(0.035),
          Colors.transparent,
        ],
        stops: const [0.0, 0.38, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow);

    final glow2 = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.95, 0.95),
        radius: 1.15,
        colors: [
          accent.withOpacity(0.075),
          Colors.transparent,
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow2);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = accent.withOpacity(0.075);
    final r = shortest * 0.34;
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r,
      ring,
    );
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r * 0.72,
      ring,
    );

    if (showGrid) {
      final grid = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.55
        ..color = accent.withOpacity(0.025);
      const gap = 28.0;
      for (double x = 0; x <= size.width; x += gap) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
      }
      for (double y = 0; y <= size.height; y += gap) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      }
    }

    final corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withOpacity(0.18);
    const len = 26.0;
    const inset = 18.0;
    canvas.drawLine(Offset(inset, inset), Offset(inset + len, inset), corner);
    canvas.drawLine(Offset(inset, inset), Offset(inset, inset + len), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset - len, size.height - inset), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset, size.height - inset - len), corner);
  }

  @override
  bool shouldRepaint(covariant _WintrixBackdropPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.showGrid != showGrid;
}
