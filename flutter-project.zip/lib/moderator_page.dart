import 'dart:io'; // Tambahkan ini agar File dikenali
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'widgets/custom_popup.dart';
import 'package:image_picker/image_picker.dart'; // Tambahkan package ini di pubspec.yaml

class ModeratorPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const ModeratorPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<ModeratorPage> createState() => _ModeratorPageState();
}

class _ModeratorPageState extends State<ModeratorPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['partner', 'admin', 'reseller', 'member'];
  String selectedRole = 'member'; 

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  // Variabel untuk foto yang dipilih
  XFile? _selectedImage;
  String _imageBase64 = '';

  final Color bgDark = const Color(0xFFF3E9D2);
  final Color primaryPurple = const Color(0xFFFFD43B);
  final Color accentPurple = const Color(0xFFFFD43B);
  final Color primaryWhite = Colors.black87;
  final Color textGrey = Colors.black54;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://public.queen-official.com:2302/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://public.queen-official.com:2302/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ===== CREATE ACCOUNT DENGAN PENDING (SUBMIT KE SERVER) =====
  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      // Gunakan endpoint submitPending (POST)
      final url = Uri.parse('http://public.queen-official.com:2302/submitPending');
      final res = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'username': u,
          'password': p,
          'day': d,
          'role': newUserRole,
          'imageBase64': _imageBase64, // Kirim foto base64
        }),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _alert("Sukses", "Permintaan akun dikirim! Tunggu approval Owner di Telegram.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _imageBase64 = '';
        _selectedImage = null;
        newUserRole = 'member';
        // Tidak perlu fetch ulang karena belum jadi
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengirim permintaan.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('http://public.queen-official.com:2302/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    CustomPopup.display(
      context,
      title: title,
      message: message,
      icon: title.toLowerCase().contains("sukses") ? Icons.check_circle_outline : Icons.info_outline,
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: textGrey, fontSize: 13),
          prefixIcon: Icon(icon, color: accentPurple, size: 20),
          filled: true,
          fillColor: const Color(0xFFFFFDF5),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: Colors.black.withOpacity(0.08)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: Colors.black.withOpacity(0.08)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide(color: accentPurple, width: 1.5),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  // ===== FUNGSI PILIH FOTO =====
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await File(image.path).readAsBytes(); // async
      setState(() {
        _selectedImage = image;
        _imageBase64 = base64Encode(bytes);
      });
    }
  }

  // ===== POPUP QR STOR =====
  void _showStorageQRPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFDF5),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: accentPurple.withOpacity(0.3), width: 3.5),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.qr_code, color: Colors.amber, size: 30),
                ),
                const SizedBox(height: 16),
                Text("STOR DISINI 5K", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const SizedBox(height: 16),
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: accentPurple.withOpacity(0.2)),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Image.network(
                    'https://h.top4top.io/p_3874d6tkv1.jpg',
                    height: 200,
                    width: 200,
                    fit: BoxFit.contain,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "Scan QR untuk melakukan pembayaran",
                  style: TextStyle(color: textGrey, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  height: 45,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentPurple,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      elevation: 0,
                    ),
                    child: const Text("TUTUP", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showCreateAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          return BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
            child: Dialog(
              backgroundColor: Colors.transparent,
              elevation: 0,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFDF5),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: accentPurple.withOpacity(0.3), width: 3.5),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: accentPurple.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(FontAwesomeIcons.userPlus, color: accentPurple, size: 30),
                      ),
                      const SizedBox(height: 16),
                      Text("CREATE ACCOUNT", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                      const SizedBox(height: 24),
                      
                      // ===== TOMBOL PILIH FOTO =====
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 16),
                        child: ElevatedButton.icon(
                          onPressed: () async {
                            await _pickImage();
                            setModalState(() {});
                          },
                          icon: Icon(Icons.photo, size: 20),
                          label: Text(_selectedImage == null ? "PILIH FOTO (Opsional)" : "FOTO TERPILIH ✅"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _selectedImage == null ? Colors.grey : Colors.green,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                          ),
                        ),
                      ),
                      // Tampilkan preview foto jika ada
                      if (_selectedImage != null)
                        Container(
                          height: 100,
                          width: 100,
                          decoration: BoxDecoration(
                            border: Border.all(color: accentPurple),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Image.file(
                            File(_selectedImage!.path),
                            fit: BoxFit.cover,
                          ),
                        ),
                      
                      _buildInput(label: "Username", controller: createUsernameController, icon: FontAwesomeIcons.user),
                      _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                      _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                      
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        margin: EdgeInsets.only(bottom: 24),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFFDF5),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.black),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: newUserRole,
                            dropdownColor: const Color(0xFFFFFDF5),
                            style: TextStyle(color: primaryWhite, fontSize: 14, fontWeight: FontWeight.bold),
                            icon: Icon(Icons.keyboard_arrow_down, color: accentPurple),
                            items: roleOptions.map((role) {
                              return DropdownMenuItem(value: role, child: Text(role.toUpperCase()));
                            }).toList(),
                            onChanged: (val) => setModalState(() => newUserRole = val ?? 'member'),
                          ),
                        ),
                      ),
                      
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            _createAccount();
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: accentPurple,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                            elevation: 0,
                          ),
                          child: const Text("KIRIM REQUEST", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }
      ),
    );
  }

  void _showExtendDurationPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFDF5),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: accentPurple.withOpacity(0.3), width: 3.5),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.blue.withOpacity(0.15), shape: BoxShape.circle),
                  child: Icon(FontAwesomeIcons.clock, color: Colors.blue, size: 30),
                ),
                const SizedBox(height: 16),
                Text("ADD DURATION", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const SizedBox(height: 24),
                _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userEdit),
                _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _editUser();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      elevation: 0,
                    ),
                    child: const Text("ADD DAYS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDeleteAccountPopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFDF5),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.redAccent.withOpacity(0.3), width: 3.5),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.redAccent.withOpacity(0.15), shape: BoxShape.circle),
                  child: Icon(FontAwesomeIcons.userSlash, color: Colors.redAccent, size: 30),
                ),
                const SizedBox(height: 16),
                Text("DELETE ACCOUNT", style: TextStyle(color: primaryWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                const SizedBox(height: 24),
                _buildInput(label: "Username Target", controller: deleteController, icon: FontAwesomeIcons.user),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _deleteUser();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                      elevation: 0,
                    ),
                    child: const Text("DELETE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTopButton({required String title, required IconData icon, required Color color, required VoidCallback onTap}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            color: const Color(0xFFFFFDF5),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: color.withOpacity(0.3), width: 3.5),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 8),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black87, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFDF5),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.black),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: accentPurple.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: accentPurple, size: 24),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'], style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 16)),
                SizedBox(height: 4),
                Text("ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}", style: TextStyle(color: textGrey, fontSize: 12, fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.delete_outline, color: Colors.redAccent),
            onPressed: () {
              deleteController.text = user['username'];
              _showDeleteAccountPopup();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isSelected = currentPage == page;
        return InkWell(
          onTap: () => setState(() => currentPage = page),
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? accentPurple : Colors.transparent,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: isSelected ? accentPurple : Colors.black.withOpacity(0.1)),
            ),
            child: Text("$page", style: TextStyle(color: isSelected ? Colors.white : Colors.black54, fontWeight: FontWeight.bold)),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: SafeArea(
        child: isLoading && fullUserList.isEmpty
            ? Center(child: CircularProgressIndicator(color: accentPurple))
            : SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header
                    Row(
                      children: [
                        Icon(Icons.gavel, color: accentPurple, size: 36),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "MODERATOR",
                              style: TextStyle(color: primaryWhite, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                            ),
                            Text(
                              "Management Dashboard",
                              style: TextStyle(color: textGrey, fontSize: 13, fontFamily: 'ShareTechMono'),
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // ===== TOMBOL STOR DISINI 5K =====
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: _showStorageQRPopup,
                        icon: Icon(Icons.qr_code, size: 24),
                        label: Text("STOR DISINI 5K", style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.amber,
                          foregroundColor: Colors.black,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                          elevation: 0,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // 3 Buttons Row
                    Row(
                      children: [
                        _buildTopButton(title: "BUAT\nAKUN", icon: FontAwesomeIcons.userPlus, color: accentPurple, onTap: _showCreateAccountPopup),
                        const SizedBox(width: 12),
                        _buildTopButton(title: "ADD\nDURASI", icon: FontAwesomeIcons.clock, color: Colors.blue, onTap: _showExtendDurationPopup),
                        const SizedBox(width: 12),
                        _buildTopButton(title: "HAPUS\nAKUN", icon: FontAwesomeIcons.userSlash, color: Colors.redAccent, onTap: _showDeleteAccountPopup),
                      ],
                    ),
                    const SizedBox(height: 30),

                    // User List Section
                    Text(
                      "USER DIRECTORY",
                      style: TextStyle(color: primaryWhite, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1.0),
                    ),
                    const SizedBox(height: 16),
                    
                    // Role Filter Dropdown
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFFDF5),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: Colors.black),
                        boxShadow: [
                          BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 0, offset: const Offset(6, 6)),
                        ],
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: const Color(0xFFFFFDF5),
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite, fontSize: 15, fontWeight: FontWeight.bold),
                          icon: Icon(Icons.keyboard_arrow_down, color: accentPurple),
                          items: roleOptions.map((role) {
                            return DropdownMenuItem(value: role, child: Text(role.toUpperCase()));
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              setState(() {
                                selectedRole = val;
                                _filterAndPaginate();
                              });
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    if (isLoading && fullUserList.isNotEmpty)
                      Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: accentPurple))),
                    
                    if (filteredList.isEmpty && !isLoading)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 40),
                          child: Text("Belum ada user di kategori ini.", style: TextStyle(color: textGrey)),
                        ),
                      ),

                    ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                    
                    const SizedBox(height: 20),
                    Center(child: _buildPagination()),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
      ),
    );
  }
}