import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart'; // ⬅️ Tambahkan untuk Clipboard
import 'change_password_page.dart';

class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String? uid; // ⬅️ Tambahkan UID

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    this.uid, // ⬅️ Tambahkan UID
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> with TickerProviderStateMixin {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  // --- TEMA WARNA HITAM PUTIH ---
  final Color bgDark = const Color(0xFFF3E9D2);
  final Color primaryPurple = const Color(0xFFFFD43B);
  final Color accentPurple = const Color(0xFFFFD43B);
  final Color primaryWhite = Colors.black87;

  // Glassmorphism Colors
  final Color cardGlass = const Color(0xFFFFFDF5);
  final Color borderGlass = Colors.black;
  
  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.15, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    _loadProfileImage();
  }

  @override
  void dispose() {
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: cardGlass,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: borderGlass, width: 1),
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 40,
                height: 3,
                decoration: BoxDecoration(
                  color: borderGlass,
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: cardGlass,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: borderGlass),
                  ),
                  child: Icon(Icons.camera_alt, color: primaryPurple, size: 18),
                ),
                title: Text(
                  "Kamera",
                  style: TextStyle(
                    color: primaryWhite,
                    fontFamily: 'ShareTechMono',
                    fontSize: 14,
                    letterSpacing: 1,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: cardGlass,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: borderGlass),
                  ),
                  child: Icon(Icons.photo_library, color: accentPurple, size: 18),
                ),
                title: Text(
                  "Galeri",
                  style: TextStyle(
                    color: primaryWhite,
                    fontFamily: 'ShareTechMono',
                    fontSize: 14,
                    letterSpacing: 1,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );
      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  Widget _buildRoleBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass, width: 3),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: primaryPurple,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
              offset: const Offset(6, 6),color: primaryPurple.withOpacity(0.5), blurRadius: 0),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            widget.role.toUpperCase(),
            style: TextStyle(
              color: primaryPurple,
              fontSize: 11,
              fontWeight: FontWeight.w800,
              fontFamily: 'Orbitron',
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    bool fullWidth = false,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fullWidth ? 18 : 14,
        vertical: 16,
      ),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass, width: 3),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: cardGlass,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: borderGlass, width: 3),
                ),
                child: Icon(icon, color: primaryPurple, size: 15),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: primaryWhite.withOpacity(0.6),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: primaryWhite,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  Widget _buildChangePasswordButton() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          width: double.infinity,
          height: 54,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                cardGlass,
                cardGlass.withOpacity(0.6 + _glowAnimation.value * 0.4),
                cardGlass,
              ],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: borderGlass,
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
              offset: const Offset(6, 6),
                color: primaryPurple.withOpacity(_glowAnimation.value * 0.08),
                blurRadius: 0,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.lock_reset_rounded, color: primaryPurple, size: 20),
                  const SizedBox(width: 12),
                  Text(
                    "CHANGE PASSWORD",
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ⬅️ TAMBAHKAN: Widget untuk menampilkan UID dengan tombol salin
  Widget _buildUidCard() {
    final String uid = widget.uid ?? 'Tidak ada UID';
    final String displayUid = uid.length > 12 ? '${uid.substring(0, 12)}...' : uid;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass, width: 3),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: cardGlass,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: borderGlass, width: 3),
                ),
                child: Icon(Icons.badge_rounded, color: primaryPurple, size: 15),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "UID / ID",
                  style: TextStyle(
                    color: primaryWhite.withOpacity(0.6),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              // ⬅️ TOMBOL SALIN
              GestureDetector(
                onTap: () {
                  Clipboard.setData(ClipboardData(text: uid));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('✅ UID berhasil disalin!'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: primaryPurple.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: primaryPurple.withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.copy_rounded, color: primaryPurple, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        "SALIN",
                        style: TextStyle(
                          color: primaryPurple,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            uid,
            style: TextStyle(
              color: primaryPurple,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 12),
          child: IconButton(
            style: IconButton.styleFrom(
              backgroundColor: cardGlass,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(color: borderGlass),
              ),
            ),
            icon: Icon(Icons.arrow_back_ios_new, color: primaryWhite, size: 16),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: const Text(
          "MY PROFILE",
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w900,
            fontSize: 13,
            letterSpacing: 2.2,
          ),
        ),
        centerTitle: true,
      ),
      body: WintrixUiFrame(
        accent: primaryPurple,
        child: Stack(
        children: [
          Positioned(
            top: -90,
            right: -70,
            child: Container(
              width: 230,
              height: 230,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: primaryPurple.withOpacity(0.06),
              ),
            ),
          ),
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(18, 26, 18, 22),
                  decoration: BoxDecoration(
                    color: cardGlass.withOpacity(0.94),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: borderGlass),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.18),
                        blurRadius: 0,
                        offset: const Offset(6, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: _showImageSourceDialog,
                        child: Stack(
                          alignment: Alignment.bottomRight,
                          children: [
                            AnimatedBuilder(
                              animation: _glowAnimation,
                              builder: (context, _) {
                                return Container(
                                  width: 116,
                                  height: 116,
                                  padding: const EdgeInsets.all(3),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    gradient: LinearGradient(
                                      colors: [
                                        primaryPurple.withOpacity(0.45 + _glowAnimation.value * 0.20),
                                        primaryPurple.withOpacity(0.08),
                                      ],
                                    ),
                                    boxShadow: [
                                      BoxShadow(
              offset: const Offset(6, 6),
                                        color: primaryPurple.withOpacity(_glowAnimation.value * 0.12),
                                        blurRadius: 0,
                                        spreadRadius: 2,
                                      ),
                                    ],
                                  ),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: bgDark,
                                      shape: BoxShape.circle,
                                    ),
                                    child: ClipOval(
                                      child: _profileImage != null
                                          ? Image.file(_profileImage!, fit: BoxFit.cover)
                                          : Icon(
                                              FontAwesomeIcons.userAstronaut,
                                              size: 42,
                                              color: primaryWhite.withOpacity(0.28),
                                            ),
                                    ),
                                  ),
                                );
                              },
                            ),
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: primaryPurple,
                                shape: BoxShape.circle,
                                border: Border.all(color: cardGlass, width: 3),
                              ),
                              child: const Icon(Icons.camera_alt_rounded, size: 14, color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        widget.username,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.black87,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.4,
                        ),
                      ),
                      const SizedBox(height: 9),
                      _buildRoleBadge(),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                _buildSectionTitle("ACCOUNT DATA"),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _buildInfoCard(icon: Icons.person_outline, label: "USERNAME", value: _censorText(widget.username))),
                    const SizedBox(width: 10),
                    Expanded(child: _buildInfoCard(icon: Icons.lock_outline, label: "PASSWORD", value: _censorText(widget.password, isPassword: true))),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: _buildInfoCard(icon: Icons.verified_user_outlined, label: "ROLE", value: widget.role.toUpperCase())),
                    const SizedBox(width: 10),
                    Expanded(child: _buildInfoCard(icon: Icons.calendar_today_outlined, label: "EXPIRED", value: widget.expiredDate)),
                  ],
                ),
                const SizedBox(height: 10),
                _buildInfoCard(
                  icon: Icons.vpn_key_rounded,
                  label: "SESSION KEY",
                  value: "${widget.sessionKey.substring(0, 8)}...",
                  fullWidth: true,
                ),
                const SizedBox(height: 10),
                _buildUidCard(),
                const SizedBox(height: 22),
                _buildChangePasswordButton(),
                const SizedBox(height: 22),
                _buildFooter(),
              ],
            ),
          ),
        ],
      ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 3,
          height: 14,
          decoration: BoxDecoration(
            color: primaryPurple,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
              offset: const Offset(6, 6),color: primaryPurple.withOpacity(0.4), blurRadius: 0),
            ],
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: TextStyle(
            color: primaryWhite.withOpacity(0.6),
            fontSize: 10,
            fontWeight: FontWeight.w900,
            letterSpacing: 3,
            fontFamily: 'Orbitron',
          ),
        ),
      ],
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          height: 1,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.transparent,
                borderGlass,
                Colors.transparent,
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 25,
              height: 1,
              decoration: BoxDecoration(
                color: borderGlass,
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.circle, color: borderGlass, size: 4),
            const SizedBox(width: 8),
            Container(
              width: 25,
              height: 1,
              decoration: BoxDecoration(
                color: borderGlass,
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Text(
          "GLITCHX PROFILE",
          style: TextStyle(
            color: primaryWhite.withOpacity(0.4),
            fontSize: 9,
            fontWeight: FontWeight.w700,
            fontFamily: 'Orbitron',
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }
}


/// Visual-only frame for WINTRIX. It deliberately reuses the app's existing
/// palette and does not alter child state, navigation, networking, or actions.
class WintrixUiFrame extends StatelessWidget {
  final Widget child;
  final Color accent;
  final bool showGrid;
  final EdgeInsetsGeometry padding;

  const WintrixUiFrame({
    super.key,
    required this.child,
    required this.accent,
    this.showGrid = true,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        IgnorePointer(
          child: CustomPaint(
            painter: _WintrixBackdropPainter(accent: accent, showGrid: showGrid),
          ),
        ),
        Padding(padding: padding, child: child),
      ],
    );
  }
}

class _WintrixBackdropPainter extends CustomPainter {
  final Color accent;
  final bool showGrid;

  const _WintrixBackdropPainter({required this.accent, required this.showGrid});

  @override
  void paint(Canvas canvas, Size size) {
    final shortest = (size.width < size.height ? size.width : size.height);

    final glow = Paint()
      ..shader = RadialGradient(
        center: const Alignment(0.88, -0.82),
        radius: 1.05,
        colors: [
          accent.withOpacity(0.11),
          accent.withOpacity(0.035),
          Colors.transparent,
        ],
        stops: const [0.0, 0.38, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow);

    final glow2 = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.95, 0.95),
        radius: 1.15,
        colors: [
          accent.withOpacity(0.075),
          Colors.transparent,
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow2);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = accent.withOpacity(0.075);
    final r = shortest * 0.34;
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r,
      ring,
    );
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r * 0.72,
      ring,
    );

    if (showGrid) {
      final grid = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.55
        ..color = accent.withOpacity(0.025);
      const gap = 28.0;
      for (double x = 0; x <= size.width; x += gap) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
      }
      for (double y = 0; y <= size.height; y += gap) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      }
    }

    final corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withOpacity(0.18);
    const len = 26.0;
    const inset = 18.0;
    canvas.drawLine(Offset(inset, inset), Offset(inset + len, inset), corner);
    canvas.drawLine(Offset(inset, inset), Offset(inset, inset + len), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset - len, size.height - inset), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset, size.height - inset - len), corner);
  }

  @override
  bool shouldRepaint(covariant _WintrixBackdropPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.showGrid != showGrid;
}
