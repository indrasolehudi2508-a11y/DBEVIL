import 'dart:convert';
import 'package:http/http.dart' as http;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:glaze_nav_bar/glaze_nav_bar.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'partner_page.dart';
import 'moderator_page.dart';
import 'public_chat_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'control_panel.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;
  final String? uid;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
    this.uid,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  late String? uid;

  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const Placeholder();
  final GlobalKey<GlazeNavBarState> _navBarKey = GlobalKey();

  int onlineUsers = 0;
  int activeConnections = 0;

  int _quickActionsPage = 0;
  late PageController _quickActionsController;

  // ============ COLOR PALETTE ============
  static const Color bgMain = Color(0xFFF3E9D2);
  static const Color bgSurface = Color(0xFFFFFFFF);
  static const Color bgCard = Color(0xFFFFFDF5);
  static const Color textMain = Colors.black87;
  static const Color textSub = Colors.black54;
  static const Color accentWhite = Color(0xFFFFD43B);
  static const Color borderLight = Color(0xFF111111);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;
    uid = widget.uid;

    _quickActionsController = PageController(viewportFraction: 0.92);

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _selectedPage = _buildDashboardHome();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _initMenuVideo();
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _menuVideoController?.dispose();
    _quickActionsController.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _menuVideoController?.setLooping(true);
        _menuVideoController?.play();
      });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://pterodactyl.cloud:4813'));
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    }, onError: (e) => debugPrint("WS error: $e"));
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0:
          _selectedPage = _buildDashboardHome();
          break;
        case 1:
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
          break;
        case 2:
          _selectedPage = InfoPage(sessionKey: sessionKey);
          break;
        case 3:
          _selectedPage = ToolsPage(
              sessionKey: sessionKey, userRole: role, listDoos: listDoos);
          break;
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) _selectedPage = SellerPage(keyToken: sessionKey);
      else if (index == 2) _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (index == 3) _selectedPage = PartnerPage(sessionKey: sessionKey, username: username);
      else if (index == 4) _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username);
      else if (index == 5) _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
    });
    Navigator.pop(context);
  }

  // ============================================================
  //  MAIN DASHBOARD HOME - NEW LAYOUT
  // ============================================================
  Widget _buildDashboardHome() {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        // Premium Hero Section
        SliverToBoxAdapter(
          child: FadeTransition(
            opacity: _animation,
            child: Column(
              children: [
                const SizedBox(height: 8),
                _buildEnhancedHeroSection(),
                const SizedBox(height: 28),
              ],
            ),
          ),
        ),

        // Content Section dengan padding
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              // System Status Section
              _buildSystemStatusSection(),
              const SizedBox(height: 28),

              // Quick Access Cards
              _buildEnhancedQuickAccess(),
              const SizedBox(height: 28),

              // Performance Metrics
              _buildAdvancedMetrics(),
              const SizedBox(height: 28),

              // News Carousel
              _buildNewsCarousel(),
              const SizedBox(height: 28),

              // Action Cards Grid
              _buildActionCardsGrid(),
              const SizedBox(height: 28),

              // Announcements Card
              _buildAnnouncementsCard(),
              const SizedBox(height: 28),

              // Contact Links
              _buildContactLinks(),
              const SizedBox(height: 40),

              // Footer
              _buildFooter(),
            ]),
          ),
        ),
      ],
    );
  }

  // ============================================================
  //  ENHANCED HERO SECTION - PREMIUM LOOK
  // ============================================================
  Widget _buildEnhancedHeroSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: accentWhite.withOpacity(0.12),
              blurRadius: 0,
              offset: const Offset(6, 6),
              spreadRadius: 2,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            children: [
              // Animated Background Gradient
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      accentWhite.withOpacity(0.96),
                      accentWhite.withOpacity(0.88),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),

              // Decorative Elements
              Positioned(
                right: -80,
                top: -60,
                child: Container(
                  width: 240,
                  height: 240,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.08),
                  ),
                ),
              ),
              Positioned(
                left: -70,
                bottom: -50,
                child: Container(
                  width: 180,
                  height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.06),
                  ),
                ),
              ),

              // Content
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
                child: Row(
                  children: [
                    // Profile Avatar
                    Container(
                      width: 110,
                      height: 110,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white,
                          width: 5,
                        ),
                        boxShadow: [
                          BoxShadow(
              offset: const Offset(6, 6),
                            color: Colors.black.withOpacity(0.18),
                            blurRadius: 0,
                            spreadRadius: 3,
                          ),
                        ],
                      ),
                      child: _profileImage != null
                          ? ClipOval(
                              child: Image.file(
                                _profileImage!,
                                fit: BoxFit.cover,
                              ),
                            )
                          : Container(
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.25),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.person_rounded,
                                color: Colors.white,
                                size: 56,
                              ),
                            ),
                    ),
                    const SizedBox(width: 28),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Status Badge
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.28),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.45),
                                width: 1.2,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
              offset: const Offset(6, 6),
                                        color: const Color(0xFF10B981)
                                            .withOpacity(0.5),
                                        blurRadius: 0,
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  "ONLINE",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),

                          // Username
                          Text(
                            username,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.5,
                              height: 1.1,
                            ),
                          ),
                          const SizedBox(height: 10),

                          // Role & Expiry Row
                          Row(
                            children: [
                              _buildRoleChipEnhanced(role),
                              const SizedBox(width: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 7,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(
                                      Icons.schedule_rounded,
                                      color: Colors.white,
                                      size: 12,
                                    ),
                                    const SizedBox(width: 6),
                                    Text(
                                      expiredDate,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoleChipEnhanced(String role) {
    final roleConfig = _getRoleConfig(role);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: roleConfig['color'].withOpacity(0.22),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: roleConfig['color'].withOpacity(0.35),
          width: 1.2,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: roleConfig['color'],
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 7),
          Text(
            role.toUpperCase(),
            style: TextStyle(
              color: roleConfig['color'],
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.6,
            ),
          ),
        ],
      ),
    );
  }

  Map<String, dynamic> _getRoleConfig(String role) {
    final configs = {
      'admin': {'color': const Color(0xFFEF4444)},
      'moderator': {'color': const Color(0xFFF97316)},
      'user': {'color': const Color(0xFF3B82F6)},
      'owner': {'color': const Color(0xFFFBBF24)},
      'partner': {'color': const Color(0xFF06B6D4)},
      'seller': {'color': const Color(0xFF22C55E)},
      'reseller': {'color': const Color(0xFFA855F7)},
    };
    return configs[role.toLowerCase()] ?? {'color': Colors.grey};
  }

  // ============================================================
  //  SYSTEM STATUS SECTION
  // ============================================================
  Widget _buildSystemStatusSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          title: "System Status",
          subtitle: "Real-time metrics",
          icon: Icons.cloud_done_rounded,
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                value: onlineUsers.toString(),
                label: "Online Users",
                icon: Icons.people_alt_rounded,
                color: const Color(0xFF3B82F6),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildStatCard(
                value: activeConnections.toString(),
                label: "Active Connections",
                icon: Icons.link_rounded,
                color: const Color(0xFF10B981),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required String value,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: color.withOpacity(0.12),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.06),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: color.withOpacity(0.2),
                width: 1.2,
              ),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 14),
          Text(
            value,
            style: TextStyle(
              color: textMain,
              fontSize: 26,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: textSub.withOpacity(0.65),
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.2,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  ENHANCED QUICK ACCESS
  // ============================================================
  Widget _buildEnhancedQuickAccess() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildSectionHeader(
              title: "Quick Access",
              subtitle: "Your shortcuts",
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 6,
              ),
              decoration: BoxDecoration(
                color: accentWhite.withOpacity(0.08),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: accentWhite.withOpacity(0.15),
                  width: 1,
                ),
              ),
              child: Text(
                "${_quickActionsPage + 1}/3",
                style: const TextStyle(
                  color: accentWhite,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView(
            controller: _quickActionsController,
            onPageChanged: (i) => setState(() => _quickActionsPage = i),
            children: [
              _buildQuickAccessCard(
                icon: Icons.public_rounded,
                title: "Global Chat",
                description: "Community conversations",
                gradient: [
                  const Color(0xFF667EEA),
                  const Color(0xFF764BA2),
                ],
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PublicChatPage(
                      username: username,
                      sessionKey: sessionKey,
                      role: role,
                    ),
                  ),
                ),
              ),
              _buildQuickAccessCard(
                icon: Icons.dashboard_customize_rounded,
                title: "Control Panel",
                description: "Manage your systems",
                gradient: [
                  const Color(0xFFF093FB),
                  const Color(0xFFF5576C),
                ],
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ControlPanelPage(),
                  ),
                ),
              ),
              _buildQuickAccessCard(
                icon: Icons.bug_report_rounded,
                title: "Sender Manage",
                description: "Added Connection WhatsApp",
                gradient: [
                  const Color(0xFF4FACFE),
                  const Color(0xFF00F2FE),
                ],
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BugSenderPage(
                      sessionKey: sessionKey,
                      username: username,
                      role: role,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildQuickAccessCard({
    required IconData icon,
    required String title,
    required String description,
    required List<Color> gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: gradient[0].withOpacity(0.35),
              blurRadius: 0,
              offset: const Offset(6, 6),
              spreadRadius: 1,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -40,
              top: -40,
              child: Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.1),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.35),
                        width: 1.2,
                      ),
                    ),
                    child: Icon(
                      icon,
                      color: Colors.white,
                      size: 26,
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.2,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        description,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.88),
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  ADVANCED METRICS
  // ============================================================
  Widget _buildAdvancedMetrics() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: bgSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: accentWhite.withOpacity(0.08),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: accentWhite.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: accentWhite.withOpacity(0.15),
                    width: 1.2,
                  ),
                ),
                child: Icon(
                  Icons.speed_rounded,
                  color: accentWhite,
                  size: 26,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Server Performance",
                      style: TextStyle(
                        color: textMain,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "All systems operational",
                      style: TextStyle(
                        color: textSub.withOpacity(0.55),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: const Color(0xFF10B981).withOpacity(0.25),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      "Active",
                      style: TextStyle(
                        color: Color(0xFF10B981),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: _buildMetricItem(
                  "Ping",
                  "24ms",
                  const Color(0xFF06B6D4),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildMetricItem(
                  "Uptime",
                  "99.9%",
                  const Color(0xFFF97316),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildMetricItem(
                  "Load",
                  "12%",
                  const Color(0xFF22C55E),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMetricItem(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 14,
        horizontal: 12,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: color.withOpacity(0.15),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 18,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: textSub.withOpacity(0.55),
              fontSize: 10,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.2,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  NEWS CAROUSEL
  // ============================================================
  Widget _buildNewsCarousel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          title: "Latest Updates",
          subtitle: "${newsList.length} articles",
          icon: Icons.newspaper_rounded,
        ),
        const SizedBox(height: 14),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 240,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: newsList.length,
              itemBuilder: (ctx, i) {
                final item = newsList[i];
                return Container(
                  width: 280,
                  margin: const EdgeInsets.only(right: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.18),
                        blurRadius: 0,
                        offset: const Offset(6, 6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (item['image'] != null)
                          NewsMedia(url: item['image']),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.black.withOpacity(0.85),
                                Colors.transparent,
                              ],
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 12,
                          right: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: accentWhite,
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [
                                BoxShadow(
              offset: const Offset(6, 6),
                                  color: accentWhite.withOpacity(0.3),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Text(
                              "NEWS",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          left: 0,
                          right: 0,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.black.withOpacity(0.4),
                                  Colors.transparent,
                                ],
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                              ),
                            ),
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['title'] ?? 'No Title',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -0.2,
                                    height: 1.3,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  item['desc'] ?? '',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.85),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  // ============================================================
  //  ACTION CARDS GRID
  // ============================================================
  Widget _buildActionCardsGrid() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          title: "Quick Actions",
          subtitle: "Get things done",
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: _buildActionButton(
                icon: FontAwesomeIcons.telegram,
                title: "Join Community",
                subtitle: "Stay updated",
                color: const Color(0xFF0088CC),
                onTap: () => _openUrl("https://t.me/mizukiszn"),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildActionButton(
                icon: Icons.headset_mic_rounded,
                title: "Support 24/7",
                subtitle: "Get help",
                color: const Color(0xFF10B981),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ContactPage(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: 18,
          horizontal: 16,
        ),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: color.withOpacity(0.18),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.05),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: color.withOpacity(0.25),
                  width: 1,
                ),
              ),
              child: Icon(
                icon,
                color: color,
                size: 22,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                color: textMain,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.1,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                color: textSub.withOpacity(0.55),
                fontSize: 10,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  ANNOUNCEMENTS CARD
  // ============================================================
  Widget _buildAnnouncementsCard() {
    return GestureDetector(
      onTap: _showInfoDialog,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              accentWhite.withOpacity(0.1),
              accentWhite.withOpacity(0.03),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: accentWhite.withOpacity(0.15),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              offset: const Offset(6, 6),
              color: accentWhite.withOpacity(0.04),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: accentWhite.withOpacity(0.12),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: accentWhite.withOpacity(0.2),
                  width: 1.2,
                ),
              ),
              child: Icon(
                Icons.campaign_rounded,
                color: accentWhite,
                size: 26,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "System Announcements",
                    style: TextStyle(
                      color: textMain,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Check latest updates & news",
                    style: TextStyle(
                      color: textSub.withOpacity(0.55),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: accentWhite.withOpacity(0.4),
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  CONTACT LINKS
  // ============================================================
  Widget _buildContactLinks() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          title: "Get in Touch",
          subtitle: "Connect with us",
        ),
        const SizedBox(height: 14),
        _buildContactItem(
          icon: FontAwesomeIcons.telegram,
          name: "Owner/Developer",
          handle: "@mizukisnji",
          color: const Color(0xFF0088CC),
          url: "https://t.me/mizukisnji",
        ),
        const SizedBox(height: 10),
        _buildContactItem(
          icon: FontAwesomeIcons.telegram,
          name: "Official Channel",
          handle: "@mizukiszn",
          color: const Color(0xFF00BCD4),
          url: "https://t.me/mizukiszn",
        ),
        const SizedBox(height: 10),
        _buildContactItem(
          icon: FontAwesomeIcons.tiktok,
          name: "TikTok",
          handle: "@mizukisnji",
          color: Colors.black87,
          url: "https://www.tiktok.com/",
        ),
      ],
    );
  }

  Widget _buildContactItem({
    required IconData icon,
    required String name,
    required String handle,
    required Color color,
    required String url,
  }) {
    return GestureDetector(
      onTap: () => _openUrl(url),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
        decoration: BoxDecoration(
          color: bgSurface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: color.withOpacity(0.12),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: color.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: Icon(
                icon,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      color: textMain,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.1,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    handle,
                    style: TextStyle(
                      color: textSub.withOpacity(0.5),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: color.withOpacity(0.3),
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  HELPER WIDGETS
  // ============================================================
  Widget _buildSectionHeader({
    required String title,
    required String subtitle,
    IconData? icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            if (icon != null) ...[
              Icon(
                icon,
                color: accentWhite,
                size: 20,
              ),
              const SizedBox(width: 8),
            ],
            Text(
              title,
              style: TextStyle(
                color: textMain,
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: TextStyle(
            color: textSub.withOpacity(0.55),
            fontSize: 11,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.2,
          ),
        ),
      ],
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          width: 60,
          height: 1.5,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.transparent,
                textSub.withOpacity(0.15),
                Colors.transparent,
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          "Parapam Dashboard v4.0",
          style: TextStyle(
            color: textSub.withOpacity(0.25),
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          "© 2027 All Rights Reserved",
          style: TextStyle(
            color: textSub.withOpacity(0.15),
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  // ============================================================
  //  CUSTOM DRAWER
  // ============================================================
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgSurface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    accentWhite.withOpacity(0.08),
                    bgSurface,
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: accentWhite,
                        width: 2.5,
                      ),
                      boxShadow: [
                        BoxShadow(
              offset: const Offset(6, 6),
                          color: accentWhite.withOpacity(0.2),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: _profileImage != null
                        ? ClipOval(
                            child: Image.file(
                              _profileImage!,
                              fit: BoxFit.cover,
                            ),
                          )
                        : Icon(
                            Icons.person_rounded,
                            color: accentWhite,
                            size: 32,
                          ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          username,
                          style: TextStyle(
                            color: textMain,
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            letterSpacing: -0.2,
                          ),
                        ),
                        const SizedBox(height: 8),
                        _buildRoleChipEnhanced(role),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 12),
                children: [
                  if (role == 'seller' || role == 'reseller')
                    _buildDrawerItem(
                      icon: Icons.storefront_rounded,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == 'admin')
                    _buildDrawerItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == 'partner')
                    _buildDrawerItem(
                      icon: FontAwesomeIcons.handshake,
                      label: "Partner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  if (role == 'moderator')
                    _buildDrawerItem(
                      icon: FontAwesomeIcons.userShield,
                      label: "Moderator Page",
                      onTap: () => _onSidebarTabSelected(4),
                    ),
                  if (role == 'owner')
                    _buildDrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(5),
                    ),
                  const Divider(height: 24, thickness: 0.8),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: "Activity History",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                            sessionKey: sessionKey,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: "Change Password",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                  const Divider(height: 24, thickness: 0.8),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (_) => const LoginPage(),
                        ),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    final color = isLogout ? const Color(0xFFEF4444) : textMain;
    return Container(
      margin: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: isLogout ? const Color(0xFFEF4444).withOpacity(0.05) : null,
        borderRadius: BorderRadius.circular(18),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Icon(
            icon,
            color: color,
            size: 20,
          ),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: -0.1,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios_rounded,
          color: textSub.withOpacity(0.2),
          size: 14,
        ),
        dense: true,
        onTap: onTap,
      ),
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: bgSurface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        child: Container(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: accentWhite.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: accentWhite.withOpacity(0.2),
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  Icons.campaign_rounded,
                  color: accentWhite,
                  size: 32,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "Latest Updates",
                style: TextStyle(
                  color: textMain,
                  fontWeight: FontWeight.w800,
                  fontSize: 22,
                  letterSpacing: -0.3,
                ),
              ),
              const SizedBox(height: 18),
              Text(
                "📢 System Updates\n\n"
                "• Enhanced Security Features\n"
                "• New Dashboard Design\n"
                "• Performance Improvements\n"
                "• Control Panel Integration\n\n"
                "Thank you for using Parapam!",
                style: TextStyle(
                  color: textSub,
                  height: 1.8,
                  fontSize: 13,
                  letterSpacing: 0.2,
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentWhite,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                    elevation: 2,
                  ),
                  child: const Text(
                    "Close",
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 20,
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: bgSurface.withOpacity(0.88),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: accentWhite.withOpacity(0.12)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.18),
                blurRadius: 0,
                offset: const Offset(6, 6),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: accentWhite,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
              offset: const Offset(6, 6),
                      color: accentWhite.withOpacity(0.45),
                      blurRadius: 0,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                "PARAPAM",
                style: TextStyle(
                  color: textMain,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  letterSpacing: 2.2,
                ),
              ),
              const SizedBox(width: 7),
              Text(
                "",
                style: TextStyle(
                  color: textSub,
                  fontWeight: FontWeight.w600,
                  fontSize: 9,
                  letterSpacing: 1.1,
                ),
              ),
            ],
          ),
        ),
        actions: [
          _dashboardAction(
            icon: Icons.headset_mic_outlined,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ContactPage()),
            ),
          ),
          const SizedBox(width: 8),
          _dashboardAction(
            icon: FontAwesomeIcons.userCircle,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ProfilePage(
                  username: username,
                  password: password,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey,
                  uid: uid,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: WintrixUiFrame(
        accent: accentWhite,
        child: Stack(
        children: [
          Positioned(
            top: -90,
            right: -70,
            child: _dashboardGlow(230),
          ),
          Positioned(
            bottom: 70,
            left: -100,
            child: _dashboardGlow(260),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 8),
              child: FadeTransition(
                opacity: _animation,
                child: _selectedPage,
              ),
            ),
          ),
        ],
      ),
      ),
      extendBody: true,
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.97),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.black),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: GlazeNavBar(
          key: _navBarKey,
          index: _bottomNavIndex,
          backgroundColor: Colors.transparent,
          items: [
            _navItem(Icons.dashboard_rounded, 'Home', 0),
            _navItem(FontAwesomeIcons.whatsapp, 'WhatsApp', 1),
            _navItem(Icons.notifications_rounded, 'Info', 2),
            _navItem(Icons.build_rounded, 'Tools', 3),
          ],
          onTap: _onBottomNavTapped,
        ),
      ),
    );
  }

  Widget _dashboardAction({required IconData icon, required VoidCallback onTap}) {
    return Material(
      color: bgSurface.withOpacity(0.88),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Icon(icon, color: textSub, size: 20),
        ),
      ),
    );
  }

  Widget _dashboardGlow(double size) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: accentWhite.withOpacity(0.055),
        ),
      ),
    );
  }

  GlazeNavBarItem _navItem(IconData icon, String label, int index) {
    final active = _bottomNavIndex == index;
    return GlazeNavBarItem(
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.all(7),
        decoration: BoxDecoration(
          color: active ? accentWhite.withOpacity(0.10) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Icon(
          icon,
          color: active ? accentWhite : textSub,
          size: 23,
        ),
      ),
      label: label,
      labelStyle: TextStyle(
        color: active ? accentWhite : textSub,
        fontSize: 9,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.1,
      ),
    );
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      }
      return const Center(
        child: CircularProgressIndicator(
          color: Color(0xFFFFD43B),
        ),
      );
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.grey.shade200,
        child: const Icon(
          Icons.error,
          color: Colors.grey,
        ),
      ),
    );
  }
}



/// Visual-only frame for WINTRIX. It deliberately reuses the app's existing
/// palette and does not alter child state, navigation, networking, or actions.
class WintrixUiFrame extends StatelessWidget {
  final Widget child;
  final Color accent;
  final bool showGrid;
  final EdgeInsetsGeometry padding;

  const WintrixUiFrame({
    super.key,
    required this.child,
    required this.accent,
    this.showGrid = true,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        IgnorePointer(
          child: CustomPaint(
            painter: _WintrixBackdropPainter(accent: accent, showGrid: showGrid),
          ),
        ),
        Padding(padding: padding, child: child),
      ],
    );
  }
}

class _WintrixBackdropPainter extends CustomPainter {
  final Color accent;
  final bool showGrid;

  const _WintrixBackdropPainter({required this.accent, required this.showGrid});

  @override
  void paint(Canvas canvas, Size size) {
    final shortest = (size.width < size.height ? size.width : size.height);

    final glow = Paint()
      ..shader = RadialGradient(
        center: const Alignment(0.88, -0.82),
        radius: 1.05,
        colors: [
          accent.withOpacity(0.11),
          accent.withOpacity(0.035),
          Colors.transparent,
        ],
        stops: const [0.0, 0.38, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow);

    final glow2 = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.95, 0.95),
        radius: 1.15,
        colors: [
          accent.withOpacity(0.075),
          Colors.transparent,
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow2);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = accent.withOpacity(0.075);
    final r = shortest * 0.34;
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r,
      ring,
    );
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r * 0.72,
      ring,
    );

    if (showGrid) {
      final grid = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.55
        ..color = accent.withOpacity(0.025);
      const gap = 28.0;
      for (double x = 0; x <= size.width; x += gap) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
      }
      for (double y = 0; y <= size.height; y += gap) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      }
    }

    final corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withOpacity(0.18);
    const len = 26.0;
    const inset = 18.0;
    canvas.drawLine(Offset(inset, inset), Offset(inset + len, inset), corner);
    canvas.drawLine(Offset(inset, inset), Offset(inset, inset + len), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset - len, size.height - inset), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset, size.height - inset - len), corner);
  }

  @override
  bool shouldRepaint(covariant _WintrixBackdropPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.showGrid != showGrid;
}
