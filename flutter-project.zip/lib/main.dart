import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'landing_page.dart';
import 'login_page.dart';
import 'loader_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'splash.dart';
import 'control_panel.dart'; // ← Hanya import ini

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  String initialRoute = '/';
  runApp(MyApp(startRoute: initialRoute));
}

class MyApp extends StatelessWidget {
  final String startRoute;
  const MyApp({super.key, required this.startRoute});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NXOB V2',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(
          primary: Colors.redAccent,
          secondary: Colors.purple,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          elevation: 0,
          centerTitle: true,
        ),
      ),
      initialRoute: startRoute,

      onGenerateRoute: (settings) {
        final args = settings.arguments as Map<String, dynamic>?;

        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const LandingPage());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/splash':
            return MaterialPageRoute(
              builder: (_) => SplashPage(
                data: args ?? {},
                uid: args?['uid'] ?? '',
              ),
            );

          case '/loader':
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args?['username'] ?? '',
                password: args?['password'] ?? '',
                role: args?['role'] ?? 'member',
                sessionKey: args?['key'] ?? '',
                expiredDate: args?['expiredDate'] ?? '',
                uid: args?['uid'] ?? '',
                listBug: List<Map<String, dynamic>>.from(args?['listBug'] ?? []),
                listPayload: List<Map<String, dynamic>>.from(args?['listPayload'] ?? []),
                listDDoS: List<Map<String, dynamic>>.from(args?['listDDoS'] ?? []),
                news: List<Map<String, dynamic>>.from(args?['news'] ?? []),
              ),
            );

          case '/seller':
            return MaterialPageRoute(
              builder: (_) => SellerPage(keyToken: args?['keyToken'] ?? ''),
            );

          case '/admin':
            return MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: args?['sessionKey'] ?? ''),
            );

          // ✅ RUTE BARU: ControlPanelPage (ganti device_dashboard)
          case '/control_panel':
  return MaterialPageRoute(
    builder: (_) => ControlPanelPage(device: args?['device']),
  );

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text("404 - PANEL NOT FOUND", style: TextStyle(color: Colors.red))),
              ),
            );
        }
      },
    );
  }
}