import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'widgets/custom_popup.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // --- TEMA WARNA HITAM PUTIH (Diperbaiki agar bisa const) ---
  static const Color bgDark = Color(0xFFF3E9D2);
  static const Color primaryPurple = const Color(0xFFFFD43B);
  static const Color accentPurple = const Color(0xFFFFD43B);

  static const Color cardGlass = Color(0xFFFFFDF5);
  static const Color borderGlass = Colors.black;

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      if (context.mounted) {
        CustomPopup.display(
          context,
          title: "Gagal",
          message: "Tidak dapat membuka tautan ini.",
          icon: Icons.error_outline,
          iconColor: Colors.redAccent,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 14),
          child: IconButton(
            style: IconButton.styleFrom(
              backgroundColor: cardGlass,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(color: borderGlass),
              ),
            ),
            icon: Icon(Icons.arrow_back_ios_new, color: accentPurple, size: 18),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: const Text(
          "CUSTOMER SERVICE",
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.w900,
            fontSize: 14,
            letterSpacing: 1.8,
          ),
        ),
        centerTitle: true,
      ),
      body: WintrixUiFrame(
        accent: primaryPurple,
        child: Stack(
        children: [
          Positioned(
            top: -80,
            right: -70,
            child: Container(
              width: 210,
              height: 210,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: primaryPurple.withOpacity(0.07),
              ),
            ),
          ),
          Positioned(
            bottom: -90,
            left: -80,
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: primaryPurple.withOpacity(0.05),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 30),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(22, 26, 22, 24),
                    decoration: BoxDecoration(
                      color: cardGlass,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: borderGlass),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.18),
                          blurRadius: 0,
                          offset: const Offset(6, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: 82,
                          height: 82,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                primaryPurple.withOpacity(0.18),
                                primaryPurple.withOpacity(0.05),
                              ],
                            ),
                            shape: BoxShape.circle,
                            border: Border.all(color: primaryPurple.withOpacity(0.20)),
                            boxShadow: [
                              BoxShadow(
              offset: const Offset(6, 6),
                                color: primaryPurple.withOpacity(0.16),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Icon(Icons.support_agent_rounded, size: 42, color: accentPurple),
                        ),
                        const SizedBox(height: 18),
                        const Text(
                          "Need a hand?",
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 25,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -0.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "Reach the WINTRIX team through the channels below.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.black54,
                            fontSize: 13,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 24),
                        Container(
                          height: 1,
                          color: Colors.black.withOpacity(0.06),
                        ),
                        const SizedBox(height: 18),
                        Row(
                          children: [
                            Expanded(
                              child: _buildContactButton(
                                context: context,
                                label: "Dev 1",
                                icon: FontAwesomeIcons.telegram,
                                color: Colors.blue,
                                url: "https://t.me/mizukisnji",
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildContactButton(
                                context: context,
                                label: "Dev 2",
                                icon: FontAwesomeIcons.telegram,
                                color: Colors.blue,
                                url: "https://t.me/Xatanicvxii",
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    "SUPPORT • WINTRIX",
                    style: TextStyle(
                      color: Colors.black.withOpacity(0.30),
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      ),
    );
  }

  Widget _buildContactButton({
    required BuildContext context,
    required String label,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(context, url),
      borderRadius: BorderRadius.circular(18),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderGlass),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 0,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: FaIcon(
                icon,
                color: color,
                size: 28,
              ),
            ),
            SizedBox(height: 12),
            Text(
              label,
              style: TextStyle(
                color: Colors.black87,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


/// Visual-only frame for WINTRIX. It deliberately reuses the app's existing
/// palette and does not alter child state, navigation, networking, or actions.
class WintrixUiFrame extends StatelessWidget {
  final Widget child;
  final Color accent;
  final bool showGrid;
  final EdgeInsetsGeometry padding;

  const WintrixUiFrame({
    super.key,
    required this.child,
    required this.accent,
    this.showGrid = true,
    this.padding = EdgeInsets.zero,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        IgnorePointer(
          child: CustomPaint(
            painter: _WintrixBackdropPainter(accent: accent, showGrid: showGrid),
          ),
        ),
        Padding(padding: padding, child: child),
      ],
    );
  }
}

class _WintrixBackdropPainter extends CustomPainter {
  final Color accent;
  final bool showGrid;

  const _WintrixBackdropPainter({required this.accent, required this.showGrid});

  @override
  void paint(Canvas canvas, Size size) {
    final shortest = (size.width < size.height ? size.width : size.height);

    final glow = Paint()
      ..shader = RadialGradient(
        center: const Alignment(0.88, -0.82),
        radius: 1.05,
        colors: [
          accent.withOpacity(0.11),
          accent.withOpacity(0.035),
          Colors.transparent,
        ],
        stops: const [0.0, 0.38, 1.0],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow);

    final glow2 = Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.95, 0.95),
        radius: 1.15,
        colors: [
          accent.withOpacity(0.075),
          Colors.transparent,
        ],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, glow2);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = accent.withOpacity(0.075);
    final r = shortest * 0.34;
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r,
      ring,
    );
    canvas.drawCircle(
      Offset(size.width * 0.98, size.height * 0.08),
      r * 0.72,
      ring,
    );

    if (showGrid) {
      final grid = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.55
        ..color = accent.withOpacity(0.025);
      const gap = 28.0;
      for (double x = 0; x <= size.width; x += gap) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
      }
      for (double y = 0; y <= size.height; y += gap) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
      }
    }

    final corner = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..color = accent.withOpacity(0.18);
    const len = 26.0;
    const inset = 18.0;
    canvas.drawLine(Offset(inset, inset), Offset(inset + len, inset), corner);
    canvas.drawLine(Offset(inset, inset), Offset(inset, inset + len), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset - len, size.height - inset), corner);
    canvas.drawLine(Offset(size.width - inset, size.height - inset),
        Offset(size.width - inset, size.height - inset - len), corner);
  }

  @override
  bool shouldRepaint(covariant _WintrixBackdropPainter oldDelegate) =>
      oldDelegate.accent != accent || oldDelegate.showGrid != showGrid;
}
