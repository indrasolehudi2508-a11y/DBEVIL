import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'widgets/custom_popup.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'FreeFireLagServer.dart';
import 'hentai_page.dart' as hentai;

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage>
    with SingleTickerProviderStateMixin {
  // --- PALETTE WARNA ASLI (TIDAK DIUBAH) ---
  static const Color bgMain = Color(0xFFF3E9D2);
  static const Color bgSurface = Color(0xFFFFFDF5);
  static const Color bgCard = Color(0xFFFFFFFF);
  static const Color accentColor = Color(0xFFFFD43B);
  static const Color textMain = Colors.black87;
  static const Color textSub = Colors.black54;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.2),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // Data kategori (sama seperti sebelumnya, tapi disusun ulang)
  List<_CategoryData> _getCategories() {
    final categories = <_CategoryData>[
      _CategoryData(
        icon: Icons.flash_on,
        title: "DDoS Tools",
        subtitle: "Attack & Server",
        color: const Color(0xFFFF6B6B),
        tools: [
          _ToolItem(
            icon: FontAwesomeIcons.fire,
            label: "Lag Free Fire",
            page: const FreeFireLagServerPage(),
          ),
          _ToolItem(
            icon: Icons.flash_on,
            label: "Attack Panel",
            page: AttackPanel(
              sessionKey: widget.sessionKey,
              listDoos: widget.listDoos,
            ),
          ),
          _ToolItem(
            icon: Icons.dns,
            label: "Manage Server",
            page: ManageServerPage(keyToken: widget.sessionKey),
          ),
        ],
      ),
      _CategoryData(
        icon: Icons.wifi,
        title: "Network",
        subtitle: "WiFi & Ddos",
        color: const Color(0xFF4ECDC4),
        tools: [
          _ToolItem(
            icon: Icons.newspaper_outlined,
            label: "Spam NGL",
            page: const NglPage(),
          ),
          _ToolItem(
            icon: Icons.wifi_off,
            label: "WiFi Killer (Int)",
            page: const WifiKillerPage(),
          ),
          if (widget.userRole == "vip" || widget.userRole == "owner")
            _ToolItem(
              icon: Icons.router,
              label: "WiFi Killer (Ext)",
              page: WifiInternalPage(sessionKey: widget.sessionKey),
            ),
        ],
      ),
      _CategoryData(
        icon: Icons.search,
        title: "OSINT",
        subtitle: "Investigation",
        color: const Color(0xFF45B7D1),
        tools: [
          _ToolItem(
            icon: Icons.badge,
            label: "NIK Detail",
            page: const NikCheckerPage(),
          ),
          _ToolItem(
            icon: Icons.domain,
            label: "Domain OSINT",
            page: const DomainOsintPage(),
          ),
          _ToolItem(
            icon: Icons.person_search,
            label: "Phone Lookup",
            isComingSoon: true,
          ),
          _ToolItem(
            icon: Icons.email,
            label: "Email OSINT",
            isComingSoon: true,
          ),
        ],
      ),
      _CategoryData(
        icon: Icons.download,
        title: "Downloader",
        subtitle: "Social Media",
        color: const Color(0xFF96CEB4),
        tools: [
          _ToolItem(
            icon: Icons.video_library,
            label: "TikTok Downloader",
            page: const TiktokDownloaderPage(),
          ),
          _ToolItem(
            icon: Icons.camera_alt,
            label: "Instagram Downloader",
            page: const InstagramDownloaderPage(),
          ),
        ],
      ),
      _CategoryData(
        icon: Icons.build,
        title: "Utilities",
        subtitle: "Extra Tools",
        color: const Color(0xFFFFEAA7),
        tools: [
          _ToolItem(
            icon: Icons.qr_code,
            label: "QR Generator",
            page: const QrGeneratorPage(),
          ),
          _ToolItem(
            icon: Icons.security,
            label: "IP Scanner",
            isComingSoon: true,
          ),
          _ToolItem(
            icon: Icons.network_check,
            label: "Port Scanner",
            isComingSoon: true,
          ),
        ],
      ),
      _CategoryData(
        icon: Icons.movie_filter,
        title: "Watch",
        subtitle: "Entertainment",
        color: const Color(0xFFDDA0DD),
        tools: [
          _ToolItem(
            icon: Icons.live_tv,
            label: "Anime Streaming",
            page: const HomeAnimePage(),
          ),
          _ToolItem(
            icon: Icons.local_fire_department,
            label: "Hentai Media",
            page: const hentai.HomeScreen(),
          ),
        ],
      ),
      _CategoryData(
        icon: Icons.rocket_launch,
        title: "Quick Access",
        subtitle: "Favorites",
        color: const Color(0xFFA29BFE),
        tools: [
          _ToolItem(
            icon: Icons.star_border,
            label: "Add Quick Access",
            isComingSoon: true,
          ),
        ],
      ),
    ];
    return categories;
  }

  @override
  Widget build(BuildContext context) {
    final categories = _getCategories();

    return Scaffold(
      backgroundColor: bgMain,
      body: Stack(
        children: [
          // --- DECORATIVE BLOBS (BACKGROUND) ---
          Positioned(
            top: -50,
            left: -50,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: accentColor.withOpacity(0.1),
              ),
            ),
          ),
          Positioned(
            bottom: -80,
            right: -60,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: accentColor.withOpacity(0.08),
              ),
            ),
          ),

          // --- MAIN CONTENT ---
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    // --- MODERN HEADER ---
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 20, 20, 14),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    accentColor.withOpacity(0.2),
                                    accentColor.withOpacity(0.05),
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: accentColor.withOpacity(0.2),
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: accentColor.withOpacity(0.15),
                                    blurRadius: 0,
                                    offset: const Offset(6, 6),
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.dashboard_rounded,
                                color: accentColor,
                                size: 32,
                              ),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "TOOLS DASHBOARD",
                                    style: TextStyle(
                                      color: textMain,
                                      fontSize: 20,
                                      fontFamily: 'Orbitron',
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    "Advanced Security & OSINT Tools",
                                    style: TextStyle(
                                      color: textSub.withOpacity(0.7),
                                      fontSize: 13,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // --- GRID KATEGORI ---
                    SliverPadding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      sliver: SliverGrid(
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 20,
                          crossAxisSpacing: 20,
                          childAspectRatio: 0.95,
                        ),
                        delegate: SliverChildListDelegate(
                          categories.map((cat) => _buildCategoryCard(cat)).toList(),
                        ),
                      ),
                    ),

                    // --- FOOTER ---
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(32),
                        child: Center(
                          child: Column(
                            children: [
                              Container(
                                width: 60,
                                height: 2,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.transparent,
                                      textSub.withOpacity(0.2),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                "Parapam V4.0",
                                style: TextStyle(
                                  color: textSub.withOpacity(0.3),
                                  fontSize: 12,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  //  KARTU KATEGORI MODERN
  // ============================================================
  Widget _buildCategoryCard(_CategoryData cat) {
    return GestureDetector(
      onTap: () => _showToolsDialog(cat),
      child: Container(
        decoration: BoxDecoration(
          color: bgSurface.withOpacity(0.95),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: Colors.white.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.18),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
            BoxShadow(
              color: cat.color.withOpacity(0.1),
              blurRadius: 0,
              offset: const Offset(6, 6),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Efek gradient halus di pojok
            Positioned(
              right: -40,
              top: -40,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      cat.color.withOpacity(0.2),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Ikon dengan gradient & glow
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          cat.color.withOpacity(0.25),
                          cat.color.withOpacity(0.05),
                        ],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: cat.color.withOpacity(0.3),
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: cat.color.withOpacity(0.2),
                          blurRadius: 0,
                          offset: const Offset(6, 6),
                        ),
                      ],
                    ),
                    child: Icon(
                      cat.icon,
                      color: cat.color,
                      size: 32,
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // Judul
                  Text(
                    cat.title,
                    style: const TextStyle(
                      color: textMain,
                      fontSize: 16,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 4),
                  
                  // Subtitle
                  Text(
                    cat.subtitle,
                    style: const TextStyle(
                      color: textSub,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 14),
                  
                  // Jumlah tools
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: cat.color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      "${cat.tools.length} tools",
                      style: TextStyle(
                        color: cat.color,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  //  DIALOG DENGAN EFEK GLASSMORPHISM & ANIMASI
  // ============================================================
  void _showToolsDialog(_CategoryData cat) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: "Dismiss",
      barrierColor: Colors.black.withOpacity(0.3),
      transitionDuration: const Duration(milliseconds: 300),
      pageBuilder: (ctx, anim1, anim2) {
        return BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
          child: Dialog(
            backgroundColor: Colors.transparent,
            elevation: 0,
            insetPadding: const EdgeInsets.all(20),
            child: FadeTransition(
              opacity: anim1,
              child: ScaleTransition(
                scale: Tween<double>(begin: 0.9, end: 1).animate(
                  CurvedAnimation(parent: anim1, curve: Curves.easeOutBack),
                ),
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 500),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: bgSurface.withOpacity(0.96),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.4),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.18),
                        blurRadius: 0,
                        offset: const Offset(6, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Header Dialog
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: cat.color.withOpacity(0.15),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: cat.color.withOpacity(0.3),
                                width: 1.5,
                              ),
                            ),
                            child: Icon(cat.icon, color: cat.color, size: 28),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  cat.title,
                                  style: const TextStyle(
                                    color: textMain,
                                    fontSize: 18,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  cat.subtitle,
                                  style: const TextStyle(
                                    color: textSub,
                                    fontSize: 13,
                                    fontFamily: 'ShareTechMono',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close_rounded, color: textSub),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      const Divider(color: Colors.black12),
                      const SizedBox(height: 20),
                      
                      // List Tools
                      ...cat.tools.map((tool) => _buildDialogToolItem(
                        context: context,
                        icon: tool.icon,
                        label: tool.label,
                        page: tool.page,
                        isComingSoon: tool.isComingSoon,
                      )).toList(),
                      
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim1, anim2, child) {
        return FadeTransition(opacity: anim1, child: child);
      },
    );
  }

  // ============================================================
  //  ITEM TOOL DALAM DIALOG
  // ============================================================
  Widget _buildDialogToolItem({
    required BuildContext context,
    required IconData icon,
    required String label,
    Widget? page,
    bool isComingSoon = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: accentColor.withOpacity(0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.18),
            blurRadius: 0,
            offset: const Offset(6, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () {
            Navigator.pop(context);
            if (isComingSoon) {
              _showComingSoon(context);
            } else if (page != null) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => page),
              );
            }
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                // Icon dengan circular background
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    color: isComingSoon ? textSub.withOpacity(0.5) : accentColor,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 14),
                
                // Label
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: isComingSoon ? textSub.withOpacity(0.5) : textMain,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                
                // Status atau arrow
                if (isComingSoon)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: textSub.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(
                      "SOON",
                      style: TextStyle(
                        color: textSub.withOpacity(0.5),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),
                  )
                else
                  Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: accentColor.withOpacity(0.4),
                    size: 14,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    CustomPopup.display(
      context,
      title: "Coming Soon",
      message: "Fitur ini masih dalam tahap pengembangan.",
      icon: Icons.info_outline,
    );
  }
}

// ============================================================
//  DATA KATEGORI DAN TOOL
// ============================================================
class _CategoryData {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final List<_ToolItem> tools;

  _CategoryData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.tools,
  });
}

class _ToolItem {
  final IconData icon;
  final String label;
  final Widget? page;
  final bool isComingSoon;

  _ToolItem({
    required this.icon,
    required this.label,
    this.page,
    this.isComingSoon = false,
  });
}